%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INIT_check checks the boundaries of the starting model M0 in the
% nonlinear gradient-type optimization problem. If any of
% the MO model parameters is outside of the hard-constrained boundaries LB
% and UB, the corresponding M0 parameter is redefined, attaining the
% value defined by the corresponding LB or UB constraint.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Mfinal = INIT_check(M0,LB,UB);

  x=length(M0);
  if x~=length(LB) | x~=length(UB)
    fprintf('INIT_check wrong imput: the input model and the boundaries LB and UB must have the same length \n');
    break;
  end;
  
  for I=1:x
    if M0(I) < LB(I)
      M0(I)=LB(I);
    end;
    if M0(I) > UB(I)
      M0(I)=UB(I);
    end;
  end;

  Mfinal=M0;
  
%%%% END OF FILE %%%%