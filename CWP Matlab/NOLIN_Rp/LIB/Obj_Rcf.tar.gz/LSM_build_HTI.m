%=================================================================
% The routine forms the LSM (Large Group of Models) for HTI media.
%=================================================================

function LSM = LSM_build_HTI(ISO,MEAN,T,M_ev1,T_ev1,M_dv1,T_dv1,M_g1, ...
			T_g1,M_ev2,T_ev2,M_dv2,T_dv2,M_g2,T_g2,n_group);

% the resulting LSM is a matrix of n_group*35 raws whose individual rows
% represent the individual models in the following format: 
% [Drho,Da,Db,b_a,ev_1,deltav_1,gamma_1,ev_2,deltav_2,gamma_2,kappa]
%
  
TR1(1,:)=[M_ev1 M_dv1 M_g1];
TR2(1,:)=[M_ev2 M_dv2 M_g2];
TR1(2,:)=[M_ev1 (M_dv1+T_dv1) M_g1];
TR2(2,:)=[M_ev2 (M_dv2+T_dv2) M_g2];
TR1(3,:)=[M_ev1 (M_dv1-T_dv1) M_g1];
TR2(3,:)=[M_ev2 (M_dv2-T_dv2) M_g2];
TR1(4,:)=[(M_ev1+T_ev1) M_dv1 M_g1];
TR2(4,:)=[(M_ev2+T_ev2) M_dv2 M_g2];
TR1(5,:)=[(M_ev1+T_ev1) (M_dv1+T_dv1) M_g1];
TR2(5,:)=[(M_ev2+T_ev2) (M_dv2+T_dv2) M_g2];
TR1(6,:)=[(M_ev1+T_ev1) (M_dv1-T_dv1) M_g1];
TR2(6,:)=[(M_ev2+T_ev2) (M_dv2-T_dv2) M_g2];
TR1(7,:)=[(M_ev1-T_ev1) M_dv1 M_g1];
TR2(7,:)=[(M_ev2-T_ev2) M_dv2 M_g2];
TR1(8,:)=[(M_ev1-T_ev1) (M_dv1+T_dv1) M_g1];
TR2(8,:)=[(M_ev2-T_ev2) (M_dv2+T_dv2) M_g2];
TR1(9,:)=[(M_ev1-T_ev1) (M_dv1-T_dv1) M_g1];
TR2(9,:)=[(M_ev2-T_ev2) (M_dv2-T_dv2) M_g2];

TR1(10,:)=[M_ev1 M_dv1 (M_g1+T_g1)];
TR2(10,:)=[M_ev2 M_dv2 (M_g2+T_g2)];
TR1(11,:)=[M_ev1 (M_dv1+T_dv1) (M_g1+T_g1)];
TR2(11,:)=[M_ev2 (M_dv2+T_dv2) (M_g2+T_g2)];
TR1(12,:)=[M_ev1 (M_dv1-T_dv1) (M_g1+T_g1)];
TR2(12,:)=[M_ev2 (M_dv2-T_dv2) (M_g2+T_g2)];
TR1(13,:)=[(M_ev1+T_ev1) M_dv1 (M_g1+T_g1)];
TR2(13,:)=[(M_ev2+T_ev2) M_dv2 (M_g2+T_g2)];
TR1(14,:)=[(M_ev1+T_ev1) (M_dv1+T_dv1) (M_g1+T_g1)];
TR2(14,:)=[(M_ev2+T_ev2) (M_dv2+T_dv2) (M_g2+T_g2)];
TR1(15,:)=[(M_ev1+T_ev1) (M_dv1-T_dv1) (M_g1+T_g1)];
TR2(15,:)=[(M_ev2+T_ev2) (M_dv2-T_dv2) (M_g2+T_g2)];
TR1(16,:)=[(M_ev1-T_ev1) M_dv1 (M_g1+T_g1)];
TR2(16,:)=[(M_ev2-T_ev2) M_dv2 (M_g2+T_g2)];
TR1(17,:)=[(M_ev1-T_ev1) (M_dv1+T_dv1) (M_g1+T_g1)];
TR2(17,:)=[(M_ev2-T_ev2) (M_dv2+T_dv2) (M_g2+T_g2)];
TR1(18,:)=[(M_ev1-T_ev1) (M_dv1-T_dv1) (M_g1+T_g1)];
TR2(18,:)=[(M_ev2-T_ev2) (M_dv2-T_dv2) (M_g2+T_g2)];

TR1(19,:)=[M_ev1 M_dv1 (M_g1-T_g1)];
TR2(19,:)=[M_ev2 M_dv2 (M_g2-T_g2)];
TR1(20,:)=[M_ev1 (M_dv1+T_dv1) (M_g1-T_g1)];
TR2(20,:)=[M_ev2 (M_dv2+T_dv2) (M_g2-T_g2)];
TR1(21,:)=[M_ev1 (M_dv1-T_dv1) (M_g1-T_g1)];
TR2(21,:)=[M_ev2 (M_dv2-T_dv2) (M_g2-T_g2)];
TR1(22,:)=[(M_ev1+T_ev1) M_dv1 (M_g1-T_g1)];
TR2(22,:)=[(M_ev2+T_ev2) M_dv2 (M_g2-T_g2)];
TR1(23,:)=[(M_ev1+T_ev1) (M_dv1+T_dv1) (M_g1-T_g1)];
TR2(23,:)=[(M_ev2+T_ev2) (M_dv2+T_dv2) (M_g2-T_g2)];
TR1(24,:)=[(M_ev1+T_ev1) (M_dv1-T_dv1) (M_g1-T_g1)];
TR2(24,:)=[(M_ev2+T_ev2) (M_dv2-T_dv2) (M_g2-T_g2)];
TR1(25,:)=[(M_ev1-T_ev1) M_dv1 (M_g1-T_g1)];
TR2(25,:)=[(M_ev2-T_ev2) M_dv2 (M_g2-T_g2)];
TR1(26,:)=[(M_ev1-T_ev1) (M_dv1+T_dv1) (M_g1-T_g1)];
TR2(26,:)=[(M_ev2-T_ev2) (M_dv2+T_dv2) (M_g2-T_g2)];
TR1(27,:)=[(M_ev1-T_ev1) (M_dv1-T_dv1) (M_g1-T_g1)];
TR2(27,:)=[(M_ev2-T_ev2) (M_dv2-T_dv2) (M_g2-T_g2)];

TR1(28,:)=[(M_ev1+0.5*T_ev1) (M_dv1+0.5*T_dv1) (M_g1+0.5*T_g1)];
TR2(28,:)=[(M_ev2+0.5*T_ev2) (M_dv2+0.5*T_dv2) (M_g2+0.5*T_g2)];
TR1(29,:)=[(M_ev1+0.5*T_ev1) (M_dv1-0.5*T_dv1) (M_g1+0.5*T_g1)];
TR2(29,:)=[(M_ev2+0.5*T_ev2) (M_dv2-0.5*T_dv2) (M_g2+0.5*T_g2)];
TR1(30,:)=[(M_ev1-0.5*T_ev1) (M_dv1+0.5*T_dv1) (M_g1+0.5*T_g1)];
TR2(30,:)=[(M_ev2-0.5*T_ev2) (M_dv2+0.5*T_dv2) (M_g2+0.5*T_g2)];
TR1(31,:)=[(M_ev1-0.5*T_ev1) (M_dv1-0.5*T_dv1) (M_g1+0.5*T_g1)];
TR2(31,:)=[(M_ev2-0.5*T_ev2) (M_dv2-0.5*T_dv2) (M_g2+0.5*T_g2)];

TR1(32,:)=[(M_ev1+0.5*T_ev1) (M_dv1+0.5*T_dv1) (M_g1-0.5*T_g1)];
TR2(32,:)=[(M_ev2+0.5*T_ev2) (M_dv2+0.5*T_dv2) (M_g2-0.5*T_g2)];
TR1(33,:)=[(M_ev1+0.5*T_ev1) (M_dv1-0.5*T_dv1) (M_g1-0.5*T_g1)];
TR2(33,:)=[(M_ev2+0.5*T_ev2) (M_dv2-0.5*T_dv2) (M_g2-0.5*T_g2)];
TR1(34,:)=[(M_ev1-0.5*T_ev1) (M_dv1+0.5*T_dv1) (M_g1-0.5*T_g1)];
TR2(34,:)=[(M_ev2-0.5*T_ev2) (M_dv2+0.5*T_dv2) (M_g2-0.5*T_g2)];
TR1(35,:)=[(M_ev1-0.5*T_ev1) (M_dv1-0.5*T_dv1) (M_g1-0.5*T_g1)];
TR2(35,:)=[(M_ev2-0.5*T_ev2) (M_dv2-0.5*T_dv2) (M_g2-0.5*T_g2)];

rand('state',sum(100*clock));  

for I=0:(n_group-1)

  ORDER=randperm(35);
  LSM(I*35+1,:)=[0.  0.  0.  0.5   TR1(1,:)   TR2(ORDER(1),:)  0.];
  LSM(I*35+2,:)=[0.  0.  0.  0.5   TR1(2,:)   TR2(ORDER(2),:)  0.];
  LSM(I*35+3,:)=[0.  0.  0.  0.5   TR1(3,:)   TR2(ORDER(3),:)  0.];
  LSM(I*35+4,:)=[0.  0.  0.  0.5   TR1(4,:)   TR2(ORDER(4),:)  0.];
  LSM(I*35+5,:)=[0.  0.  0.  0.5   TR1(5,:)   TR2(ORDER(5),:)  0.];
  LSM(I*35+6,:)=[0.  0.  0.  0.5   TR1(6,:)   TR2(ORDER(6),:)  0.];
  LSM(I*35+7,:)=[0.  0.  0.  0.5   TR1(7,:)   TR2(ORDER(7),:)  0.];
  LSM(I*35+8,:)=[0.  0.  0.  0.5   TR1(8,:)   TR2(ORDER(8),:)  0.];
  LSM(I*35+9,:)=[0.  0.  0.  0.5   TR1(9,:)   TR2(ORDER(9),:)  0.];
  LSM(I*35+10,:)=[0.  0.  0.  0.5   TR1(10,:)   TR2(ORDER(10),:)  0.];
  LSM(I*35+11,:)=[0.  0.  0.  0.5   TR1(11,:)   TR2(ORDER(11),:)  0.];
  LSM(I*35+12,:)=[0.  0.  0.  0.5   TR1(12,:)   TR2(ORDER(12),:)  0.];
  LSM(I*35+13,:)=[0.  0.  0.  0.5   TR1(13,:)   TR2(ORDER(13),:)  0.];
  LSM(I*35+14,:)=[0.  0.  0.  0.5   TR1(14,:)   TR2(ORDER(14),:)  0.];
  LSM(I*35+15,:)=[0.  0.  0.  0.5   TR1(15,:)   TR2(ORDER(15),:)  0.];
  LSM(I*35+16,:)=[0.  0.  0.  0.5   TR1(16,:)   TR2(ORDER(16),:)  0.];
  LSM(I*35+17,:)=[0.  0.  0.  0.5   TR1(17,:)   TR2(ORDER(17),:)  0.];
  LSM(I*35+18,:)=[0.  0.  0.  0.5   TR1(18,:)   TR2(ORDER(18),:)  0.];
  LSM(I*35+19,:)=[0.  0.  0.  0.5   TR1(19,:)   TR2(ORDER(19),:)  0.];
  LSM(I*35+20,:)=[0.  0.  0.  0.5   TR1(20,:)   TR2(ORDER(20),:)  0.];
  LSM(I*35+21,:)=[0.  0.  0.  0.5   TR1(21,:)   TR2(ORDER(21),:)  0.];
  LSM(I*35+22,:)=[0.  0.  0.  0.5   TR1(22,:)   TR2(ORDER(22),:)  0.];
  LSM(I*35+23,:)=[0.  0.  0.  0.5   TR1(23,:)   TR2(ORDER(23),:)  0.];
  LSM(I*35+24,:)=[0.  0.  0.  0.5   TR1(24,:)   TR2(ORDER(24),:)  0.];
  LSM(I*35+25,:)=[0.  0.  0.  0.5   TR1(25,:)   TR2(ORDER(25),:)  0.];
  LSM(I*35+26,:)=[0.  0.  0.  0.5   TR1(26,:)   TR2(ORDER(26),:)  0.];
  LSM(I*35+27,:)=[0.  0.  0.  0.5   TR1(27,:)   TR2(ORDER(27),:)  0.];
  LSM(I*35+28,:)=[0.  0.  0.  0.5   TR1(28,:)   TR2(ORDER(28),:)  0.];
  LSM(I*35+29,:)=[0.  0.  0.  0.5   TR1(29,:)   TR2(ORDER(29),:)  0.];
  LSM(I*35+30,:)=[0.  0.  0.  0.5   TR1(30,:)   TR2(ORDER(30),:)  0.];
  LSM(I*35+31,:)=[0.  0.  0.  0.5   TR1(31,:)   TR2(ORDER(31),:)  0.];
  LSM(I*35+32,:)=[0.  0.  0.  0.5   TR1(32,:)   TR2(ORDER(32),:)  0.];
  LSM(I*35+33,:)=[0.  0.  0.  0.5   TR1(33,:)   TR2(ORDER(33),:)  0.];
  LSM(I*35+34,:)=[0.  0.  0.  0.5   TR1(34,:)   TR2(ORDER(34),:)  0.];
  LSM(I*35+35,:)=[0.  0.  0.  0.5   TR1(35,:)   TR2(ORDER(35),:)  0.];
 
end;

for J=1:length(LSM)
  TEMP=2*(0.5-rand(1,8));         % uniformly distributed random numbers <-1;+1>;
  TEMP2=MEAN+2*T.*(0.5-rand(1,7));
  LSM(J,4)=TEMP2(6);
  ISOparam=ISO_build(TEMP2(1),TEMP2(2),ISO,TEMP2(3:6));    % create the iso semi-random parameters
  LSM(J,1:3)=ISOparam;
  LSM(J,11)=TEMP2(7);
end;




