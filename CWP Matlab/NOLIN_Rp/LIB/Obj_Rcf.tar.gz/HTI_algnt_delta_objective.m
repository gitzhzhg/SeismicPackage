%==============================================================================
% Objective function for the recovery of HTI parameters, minimizing the misfit  
% misfit = || data - reflection coefficients ||. The routine assumes
% the alignment of symmetry axes (kappa=0) 
%
% this version assumes also a hard constraint delta1=X
%==============================================================================

function F = HTI_algnt_delta_objective(medium,delta1_0,inc,azim,n_run,WEIGHT);

% medium=[Drho DV33 DV55 b_a ev_1 g_1 
%         ev_2 dv_2 g_2]  
% WEIGHT=0 ... no automatic weighting of data performed  

  
global Pdata
global S1data
global S2data

     PENALTY=2.;                % PENALTY should be >> 1 if you invert
                                % REAL reflection coefficients 
				% (pre-critical reflection), and should be
				% close to 1 otherwise.


% 0) Get the artificial model parameters:

     Drho=medium(1);
     DV33=medium(2);
     DV55=medium(3);
     b_a=medium(4);
     e1=medium(5);
     g1=medium(6);
     e2=medium(7);
     d2=medium(8);
     g2=medium(9);

     kappa=0.;
     d1=delta1_0;
     
     a1=3.5;                     % THIS IS MY CHOICE!!! (should be arbitrary)
     rho1=2.5;                   % THIS IS MY CHOICE!!! (should be arbitrary)
     a2=a1*(1+0.5*DV33)/(1-0.5*DV33);
     b1=b_a*(a2+a1)*(0.5-0.25*DV55);
     b2=b_a*(a2+a1)-b1;
     rho2=rho1*(1+0.5*Drho)/(1-0.5*Drho);

% 1) Compute Cij's for the model:
%    Cij=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66]

     Cij_1=HTI_Cij([a1 b1 e1 d1 g1]);
     Cij_2=HTI_Cij([a2 b2 e2 d2 g2]);
     
% 2) Compute the reflection coefficients for the Cij's above:

     Rcoef=RppRps(rho1,Cij_1,rho2,Cij_2,inc,azim,kappa);
     
% 3) Compute the objective function F:
    
     % Find the data weights:
  
     PM=max(abs(Pdata));
     S1M=max(abs(S1data));
     S2M=max(abs(S2data));
     MM=max([PM S1M S2M]);
     PW=MM/PM;
     S1W=MM/S1M;
     S2W=MM/S2M;

     % Evaluate the objective function:

     Pdim=length(Pdata);
     S1dim=length(S1data);
     S2dim=length(S2data);
     
       % ommit the data corresponding to the (S-wave) singular points where
       % polarizations are not defined
       for ii=1:Pdim
	 if Rcoef(ii,1)==1000.;
	   Rcoef(ii,1)==Pdata(ii);
	 end;
       end;
       for ii=1:S1dim
	 if Rcoef(ii,2)==1000.;
	   Rcoef(ii,2)==S1data(ii);
	 end;
       end;
       for ii=1:S2dim
	 if Rcoef(ii,3)==1000.;
	   Rcoef(ii,3)==S2data(ii);
	 end;
       end;
 
     FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
     FF(Pdim+1:1:Pdim+S1dim)=S1W*(S1data-Rcoef(:,2));
     FF(Pdim+S1dim+1:1:Pdim+S1dim+S2dim)=S2W*(S2data-Rcoef(:,3));
     F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
     Fprint=sum(F.^2);
     if WEIGHT==0
       fprintf('*** automatic weighting disactivated ***\n');
       fprintf('*** misfit with weighting: \t F_objective=%11.7f \n', Fprint);
       PW=1;
       S1W=1;
       S2W=1;
       FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
       FF(Pdim+1:1:Pdim+S1dim)=S1W*(S1data-Rcoef(:,2));
       FF(Pdim+S1dim+1:1:Pdim+S1dim+S2dim)=S2W*(S2data-Rcoef(:,3));
       F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
       Fprint=sum(F.^2);
     end;

     %------------ information printout --------------------
     fprintf('HTIxHTI ERROR REALIZATION #: %i \t F_objective=%11.7f \n', n_run, Fprint);
%     fid10=fopen('RunInfo.out','a');
%     fprintf(fid10,'ERROR REALIZATION #: %i \t F_objective=%11.7f PW=%f S1W= %f S2W= %f \n', n_run, Fprint, PW,S1W,S2W);
%     fprintf(fid10,'Drho_R=%f DV33_R=%f DV55_R=%f b_a_R=%f ev1_R=%f dv1_R=%f g1_R=%f ev2_R=%f d2_R=%f g2_R=%f \n',real(medium));
%     fprintf(fid10,'Drho_I=%f DV33_I=%f DV55_I=%f b_a_I=%f ev1_I=%f dv1_I=%f g1_I=%f ev2_I=%f d2_I=%f g2_I=%f \n \n',imag(medium));
%     fclose(fid10);
     %----------------------------------------
      
%%% END OF FILE %%%%%%%%%%%%%%%     
