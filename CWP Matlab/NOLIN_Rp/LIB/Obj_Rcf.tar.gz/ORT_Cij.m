%==============================================================
% Transformatin of the Tsvankin's medium parameters into Cij's:  
% ORT MEDIUM
%==============================================================

function G = ORT_Cij(medium);

% medium=[v33,v55,eps_1,eps_2,delta_1,delta_2,gamma_1,gamma_2,delta_3]  
% G= [A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66] 
  
% 1) more convenient notation:
 
  v33=medium(1);
  v55=medium(2);
  e1=medium(3);
  e2=medium(4);
  d1=medium(5);
  d2=medium(6);
  g1=medium(7);
  g2=medium(8);
  d3=medium(9);

% 2) Cij's:

  A33=v33^2;
  A55=v55^2;
  A11=A33*(1+2*e2);
  A22=A33*(1+2*e1);
  A66=A55*(1+2*g1);
  A44=A66/(1+2*g2);
  
  A12=sqrt(2*A11*(A11-A66)*d3+(A11-A66)^2)-A66;
  A13=sqrt(2*A33*(A33-A55)*d2+(A33-A55)^2)-A55;
  A23=sqrt(2*A33*(A33-A44)*d1+(A33-A44)^2)-A44;
  A16=0;
  A26=0;
  A36=0;

  
% 3) Form the function G:
 
  G=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66];




