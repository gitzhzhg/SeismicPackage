%=================================================================
% The routine forms the LSM (Large Group of Models) for ISO media.
%=================================================================

function LSM = LSM_build_HTI(ISO,MEAN,T,n_group);

% the resulting LSM is a matrix of n_group raws whose individual rows
% represent the individual models in the following format: 
% [Drho,Da,Db,b_a]
%
  
for J=1:n_group
  TEMP=2*(0.5-rand(1,8));         % uniformly distributed random numbers <-1;+1>;
  TEMP2=MEAN+2*T.*(0.5-rand(1,7));
  ISOparam=ISO_build(TEMP2(1),TEMP2(2),ISO,TEMP2(3:6));    % create the iso semi-random parameters
  LSM(J,1:3)=ISOparam;
  LSM(J,4)=TEMP2(6);
end;




