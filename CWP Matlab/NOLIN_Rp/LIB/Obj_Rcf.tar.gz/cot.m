function y = cot(z)
%COT    Cotangent.
%   COT(X) is the cotangent of the elements of X.

%   Copyright 1984-2001 The MathWorks, Inc. 
%   $Revision: 5.6 $  $Date: 2001/04/15 12:02:50 $

y = 1./tan(z);
