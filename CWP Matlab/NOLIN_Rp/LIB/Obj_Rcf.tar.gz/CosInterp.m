%=============================================================================
% Cosine-interpolation    
%=============================================================================

function fint = CosInterp(t, f, tn);

dd = (length(tn)-1)/(length(t)-1);

index = 0;
for i=1:length(t)-1
   for ii=1:dd
      index = index + 1;
      fint(index) = f(i) + (f(i+1)-f(i))*(1 - cos(pi*(1/dd)*(ii-1)))/2;
   end;
end;
fint(index+1) = f(length(t));

