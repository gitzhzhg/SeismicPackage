%==============================================================================
% Objective function for the recovery of HTI parameters, minimizing the misfit  
% misfit = || data - reflection coefficients ||. The routine assumes
% the alignment of symmetry axes (kappa=0) 
%==============================================================================

function F = HTI_align_objective(medium,inc,azim,n_run,WEIGHT);

% medium=[Drho DV33 DV55 b_a ev_1 dv_1 g_1 
%         ev_2 dv_2 g_2]  
% WEIGHT=0 ... no automatic weighting of data performed  

  
global Pdata
global S1data
global S2data
global RECORD

     PENALTY=2.;                % PENALTY should be >> 1 if you invert
                                % REAL reflection coefficients 
				% (pre-critical reflection), and should be
				% close to 1 otherwise.
     PERIOD=11;

     if n_run<0
       name='EVOLUTION_S.out';
       n_run=-n_run;
     else
       name='EVOLUTION.out';
     end;

% 0) Get the artificial model parameters:

     Drho=medium(1);
     DV33=medium(2);
     DV55=medium(3);
     b_a=medium(4);
     e1=medium(5);
     d1=medium(6);
     g1=medium(7);
     e2=medium(8);
     d2=medium(9);
     g2=medium(10);
     kappa=0.;
     
     a1=3.5;                     % THIS IS MY CHOICE!!! (can be arbitrary)
     rho1=2.5;                   % THIS IS MY CHOICE!!! (can be arbitrary)
     a2=a1*(1+0.5*DV33)/(1-0.5*DV33);
     b1=b_a*(a2+a1)*(0.5-0.25*DV55);
     b2=b_a*(a2+a1)-b1;
     rho2=rho1*(1+0.5*Drho)/(1-0.5*Drho);

% 1) Compute Cij's for the model:
%    Cij=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66]

     Cij_1=HTI_Cij([a1 b1 e1 d1 g1]);
     Cij_2=HTI_Cij([a2 b2 e2 d2 g2]);
     
% 2) Compute the reflection coefficients for the Cij's above:

     Rcoef=RppRps(rho1,Cij_1,rho2,Cij_2,inc,azim,kappa);
     
% 3) Compute the objective function F:
    
     % Find the data weights:
  
     PM=max(abs(Pdata));
     S1M=max(abs(S1data));
     S2M=max(abs(S2data));
     MM=max([PM S1M S2M]);
     PW=MM/PM;
     S1W=MM/S1M;
     S2W=MM/S2M;

     % Evaluate the objective function:

     Pdim=length(Pdata);
     S1dim=length(S1data);
     S2dim=length(S2data);

       % ommit the data corresponding to the (S-wave) singular points where
       % polarizations are not defined
       for ii=1:Pdim
	 if Rcoef(ii,1)==1000.;
	   Rcoef(ii,1)==Pdata(ii);
	 end;
       end;
       for ii=1:S1dim
	 if Rcoef(ii,2)==1000.;
	   Rcoef(ii,2)==S1data(ii);
	 end;
       end;
       for ii=1:S2dim
	 if Rcoef(ii,3)==1000.;
	   Rcoef(ii,3)==S2data(ii);
	 end;
       end;
      
     FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
     FF(Pdim+1:1:Pdim+S1dim)=S1W*(S1data-Rcoef(:,2));
     FF(Pdim+S1dim+1:1:Pdim+S1dim+S2dim)=S2W*(S2data-Rcoef(:,3));
     F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
     Fprint=sum(F.^2);
     if WEIGHT==0
       fprintf('*** automatic weighting disactivated ***\n');
       fprintf('*** misfit with weighting: \t F_objective=%11.7f \n', Fprint);
       PW=1;
       S1W=1;
       S2W=1;
       FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
       FF(Pdim+1:1:Pdim+S1dim)=S1W*(S1data-Rcoef(:,2));
       FF(Pdim+S1dim+1:1:Pdim+S1dim+S2dim)=S2W*(S2data-Rcoef(:,3));
       F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
       Fprint=sum(F.^2);
     end;       
% 4) Print out and store some semi-results:

     fprintf('HTI || HTI REALIZATION #: %i \t F_objective=%11.7f \n', n_run, Fprint);

     if rem((RECORD-1),PERIOD) == 0
       if n_run==1 & RECORD==1
	 fid10=fopen(name,'w');
       else
	 fid10=fopen(name,'a');
       end;   
       ITER=1+(RECORD-1)/PERIOD;
       fprintf(fid10,'%i \t %i \t %11.5f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \n',[n_run,ITER,Fprint,real(medium)]);
       fclose(fid10);
     end;
     RECORD=RECORD+1;
     
     if sum(abs(imag(medium))) > 1e-3
       fprintf('\n!WARNING!\n occurence of an imaginary medium parameter \n');
       fprintf('Drho_I=%f DV33_I=%f DV55_I=%f b_a_I=%f ev_1_I=%f dv_1_I=%f g_1_I=%f ev_2_I=%f dv_2_I=%f g_2_I=%f \n',imag(medium));
     end;
     
% some remainings which may be sometimes useful:       
%
%     fprintf('HTI || HTI REALIZATION #: %i \t F_objective=%11.7f \n', n_run, Fprint);
%     fid10=fopen('RunInfo.out','a');
%     fprintf(fid10,'ERROR REALIZATION #: %i \t F_objective=%11.7f PW=%f S1W= %f S2W= %f \n', n_run, Fprint, PW,S1W,S2W);
%     fprintf(fid10,'Drho_R=%f DV33_R=%f DV55_R=%f b_a_R=%f ev1_R=%f dv1_R=%f g1_R=%f ev2_R=%f d2_R=%f g2_R=%f \n',real(medium));
%     fprintf(fid10,'Drho_I=%f DV33_I=%f DV55_I=%f b_a_I=%f ev1_I=%f dv1_I=%f g1_I=%f ev2_I=%f d2_I=%f g2_I=%f \n \n',imag(medium));
%     fclose(fid10);
     %----------------------------------------
      
%%% END OF FILE %%%%%%%%%%%%%%%     
