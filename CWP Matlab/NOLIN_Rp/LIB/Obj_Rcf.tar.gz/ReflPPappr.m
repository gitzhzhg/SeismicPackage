%=============================================================================
% Weak anisotoropy, weak contrast, small incidence angle approximation
% of P-wave reflection coefficient (after Vavrycuk and Psencik, 1997)
%=============================================================================

function [Rapp, R11, R12, R22] = ReflPPappr(ro1, C1, ro2, C2, p1, p2, p3)

%=============================================================================

% Calculate P-wave incidence angle and azimuth
sp = p1^2 + p2^2;   spp = sp + p3(1)^2;   s2in = sp/spp;
if sp > eps
   cazi = p1/sqrt(sp);   sazi = p2/sqrt(sp);
   else
   cazi = 1;   sazi = 0;
end

%=============================================================================

% Quantities for isotropic reflection coefficient 
alf1 = sqrt(C1(3,3));   alf2 = sqrt(C2(3,3));   
aalf = (alf1+alf2)/2;   dalf = alf2-alf1;
bet1 = sqrt(C1(5,5));   bet2 = sqrt(C2(5,5));
abet = (bet1+bet2)/2;   dbet = bet2-bet1;
Z1 = ro1*alf1;     Z2 = ro2*alf2;     aZ = (Z1+Z2)/2;   dZ = Z2-Z1;
G1 = ro1*bet1^2;   G2 = ro2*bet2^2;   aG = (G1+G2)/2;   dG = G2-G1;

% Isotropic reflection coefficient: small incidence angle approximation
R0 = (dZ/aZ)/2;
RisoG = dalf/aalf - 4*(abet/aalf)^2*dG/aG;

% Quantities for anisotropic reflection coefficient
d1 = (C2(1,3) + 2*C2(5,5) - C2(3,3))/C2(3,3) - ...
     (C1(1,3) + 2*C1(5,5) - C1(3,3))/C1(3,3);
d2 = (C2(2,3) + 2*C2(4,4) - C2(3,3))/C2(3,3) - ...
     (C1(2,3) + 2*C1(4,4) - C1(3,3))/C1(3,3);
d3 = (C2(4,4) - C2(5,5))/C2(3,3) - (C1(4,4) - C1(5,5))/C1(3,3);
d4 = (C2(3,6) + 2*C2(4,5))/C2(3,3) - (C1(3,6) + 2*C1(4,5))/C1(3,3);
d5 = C2(4,5)/C2(3,3) - C1(4,5)/C1(3,3);

% Anisotropic reflection coefficient: small incidence angle approximation
R11 = RisoG + d1;
R12 = d4 - 4*d5;
R22 = RisoG + d2 - 4*d3;

Rapp = R0 + (R11*cazi^2 + 2*R12*sazi*cazi + R22*sazi^2)*s2in/2;

% Rij is the gradients as functions of p1 and p2
%!!! Note, this is an ISOTROPIC approximation assuming spp does not depend 
%!!! on p. Without this assumption, I'd have to compute d^2[p^2/(2*spp)]/d p^2
%!!! i.e. derivative q" is needed
R11 = R11/spp;
R12 = R12/spp;
R22 = R22/spp;

%=============================================================================

