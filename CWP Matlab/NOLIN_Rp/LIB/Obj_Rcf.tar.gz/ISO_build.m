%=================================================================
% The routine forms the LSM (Large Group of Models) for ORT media.
%=================================================================

function ISOparam = ISO_build(R0,RP,ISO,ISOmean);

%  
% Generates a semi-random values of Drho Dv33 and Dv55, giving b_a ratio.
%
  rho=ISOmean(1);
  v33=ISOmean(2);
  v55=ISOmean(3);
  b_a=ISOmean(4);
  
  if ISO==1
    ISOparam=[rho v33 v55];
  end;
  
  if ISO(1)==1 & ISO(2)==1 & ISO(3)==0
    ISOparam(1)=rho;
    ISOparam(2)=v33;
    ISOparam(3)=-(2*RP-ISOparam(2)+(2*b_a)^2*ISOparam(1))/(2*(2*b_a)^2);
  end;
  if ISO(1)==1 & ISO(2)==0 & ISO(3)==1
    ISOparam(1)=rho;
    ISOparam(2)=2*R0-ISOparam(1);
    ISOparam(3)=v55;
  end;
  if ISO(1)==0 & ISO(2)==1 & ISO(3)==1
    ISOparam(2)=v33;
    ISOparam(1)=2*R0-ISOparam(2);
    ISOparam(3)=v55;
  end;
  
  if ISO(1)==1 & ISO(2)==0 & ISO(3)==0
    ISOparam(1)=rho;
    ISOparam(2)=2*R0-ISOparam(1);
    ISOparam(3)=-(2*RP-ISOparam(2)+(2*b_a)^2*ISOparam(1))/(2*(2*b_a)^2);
  elseif ISO(1)==0 & ISO(2)==1 & ISO(3)==0 
    ISOparam(2)=v33;
    ISOparam(1)=2*R0-ISOparam(2);
    ISOparam(3)=-(2*RP-ISOparam(2)+(2*b_a)^2*ISOparam(1))/(2*(2*b_a)^2);
  elseif ISO(1)==0 & ISO(2)==0 & ISO(3)==1
    D=[2*R0 2*RP+2*(2*b_a)^2*v55]';
    A=[1 1;
       -(2*b_a)^2 1];
    TEMP=pinv(A)*D;
    ISOparam=[TEMP(1) TEMP(2) v55];
  end;
    
  if ISO==0
    ISOparam(2)=v33;
    ISOparam(1)=2*R0-ISOparam(2);
    ISOparam(3)=-(2*RP-ISOparam(2)+(2*b_a)^2*ISOparam(1))/(2*(2*b_a)^2);
  end;
  
%%%%%%%% END OF FILE %%%%%%%%%%%%%%%%%