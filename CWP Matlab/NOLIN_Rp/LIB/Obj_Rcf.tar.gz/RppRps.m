%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rpp and Rps exact reflection coefficients computed for a model with
% incidence and reflecting halfspaces characterized by Cij_1 and Cij_2,
% respectively (up to MNC with the horizontal symmetry plane), and 
% the incidence angle "inc_angle" and azimuth "azimuth" (in rad). The angles are
% vectors, both having the same length, so the reflection coefficients
% are evaluated for each pair [inc_angle(i),azimuth(i)].
%
% Simplified version of the Azim_ReflCoef.m, specified for just one
% single interface.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function COEF=RppRps(rho1,Cij_1,rho2,Cij_2,inc_angle,azimuth,kappa);

  err_flag0=0.;
  err_flag1=0;
  err_flag2=0;
  err_flag3=0.;
  err_flag4=0;
  
 k=length(inc_angle); 
 if k~=length(azimuth)
   fprintf('*** RppRps: Incidence and azimuthal angle vectors must have the same length *** ')
   fprintf('\n *** RppRps: program terminated *** \n')
   break;
 end;

 % Loop over frequences of incident wave:
 
 for iHz=1:1
   f = iHz-1;   
   w = 2*pi*f;

   % Loop over incident angles (ang) and azimuths (azim):

   for ii=1:k
     ang=inc_angle(ii);
     azim=azimuth(ii);
     n_dir = PropDirection(ang,azim);
     n1 = n_dir(1);
     n2 = n_dir(2);
     n3 = n_dir(3);

     Nlayer = 0;  % this sets the single interface (no layering)
     %----------------------------------------
     %fprintf('inc=%f azim=%f \n', ang*180/pi,azim*180/pi);
     %----------------------------------------

     % The main loop over the model: INCIDENCE HALFSPACE:
     
     ro1 = rho1;
     cij = Cij_1;   [C,err_flag0]  = FormCij(cij,1);
    
     if err_flag0<0.   
     
       % if err_flag0<0, the medium is not physical and the
       % reflection coefficients are penalized:       
       COEF(ii,1:3)=[100+err_flag0*i 100+err_flag0*i 100+err_flag0*i];

       % However, a failure of the check above (with err_flag0) for a physical medium can
       % happen in the case of attenuative media with complex Cij, when
       % the complex determinants of Cij matrix cannot be properly
       % evaluated by the used Matlab routine. The complex (attenuative)
       % medium is also not allowed in this inversion, therefore if the
       % complex Cij occur, the objective function is strongly penalized. 
       % In the case this happens, here is the pathetic medium, and the
       % penalization (another unlikely possibility of the check failure
       % is the existance of a numerical error, which is ignored if small
       % within the machine preccission):
      
     elseif norm(imag(C),1) > 0.

%       fid10=fopen('Problems.out','a');
%       fprintf(fid10,'PATHETHIC INCIDENCE MEDIUM real: \n c11_R=%f c12_R=%f c13_R=%f c14_R=%f c15_R=%f c16_R=%f \n c21_R=%f c22_R=%f c23_R=%f c24_R=%f c25_R=%f c26_R=%f \n c31_R=%f c32_R=%f c33_R=%f c34_R=%f c35_R=%f c36_R=%f \n c41_R=%f c42_R=%f c43_R=%f c44_R=%f c45_R=%f c46_R=%f \n  c51_R=%f c52_R=%f c53_R=%f c54_R=%f c55_R=%f c56_R=%f \n c61_R=%f c62_R=%f c63_R=%f c64_R=%f c65_R=%f c66_R=%f \n',real(C(1,1)),real(C(1,2)),real(C(1,3)),real(C(1,4)),real(C(1,5)),real(C(1,6)),real(C(2,1)),real(C(2,2)),real(C(2,3)),real(C(2,4)),real(C(2,5)),real(C(2,6)),real(C(3,1)),real(C(3,2)),real(C(3,3)),real(C(3,4)),real(C(3,5)),real(C(3,6)),real(C(4,1)),real(C(4,2)),real(C(4,3)),real(C(4,4)),real(C(4,5)),real(C(4,6)),real(C(5,1)),real(C(5,2)),real(C(5,3)),real(C(5,4)),real(C(5,5)),real(C(5,6)),real(C(6,1)),real(C(6,2)),real(C(6,3)),real(C(6,4)),real(C(6,5)),real(C(6,6)));
%       fprintf(fid10,'PATHETHIC INCIDENCE MEDIUM imag: \n c11_I=%f c12_I=%f c13_I=%f c14_I=%f c15_I=%f c16_I=%f \n c21_I=%f c22_I=%f c23_I=%f c24_I=%f c25_I=%f c26_I=%f \n c31_I=%f c32_I=%f c33_I=%f c34_I=%f c35_I=%f c36_I=%f \n c41_I=%f c42_I=%f c43_I=%f c44_I=%f c45_I=%f c46_I=%f \n  c51_I=%f c52_I=%f c53_I=%f c54_I=%f c55_I=%f c56_I=%f \n c61_I=%f c62_I=%f c63_I=%f c64_I=%f c65_I=%f c66_I=%f \n',imag(C(1,1)),imag(C(1,2)),imag(C(1,3)),imag(C(1,4)),imag(C(1,5)),imag(C(1,6)),imag(C(2,1)),imag(C(2,2)),imag(C(2,3)),imag(C(2,4)),imag(C(2,5)),imag(C(2,6)),imag(C(3,1)),imag(C(3,2)),imag(C(3,3)),imag(C(3,4)),imag(C(3,5)),imag(C(3,6)),imag(C(4,1)),imag(C(4,2)),imag(C(4,3)),imag(C(4,4)),imag(C(4,5)),imag(C(4,6)),imag(C(5,1)),imag(C(5,2)),imag(C(5,3)),imag(C(5,4)),imag(C(5,5)),imag(C(5,6)),imag(C(6,1)),imag(C(6,2)),imag(C(6,3)),imag(C(6,4)),imag(C(6,5)),imag(C(6,6)));
%       fclose(fid10);
       COEF(ii,1:3)=[100+100*i 100+100*i 100+100*i];
	 
     else

       azm = 0.;    C1 = RotateCij(C, azm);
       [Vel,err_flag1] = Azim_ChristEq(C1, n1, n2, n3);
       % err_flag=1 should never occur at this point; if err_flag1=1, the medium is not physical and the
       % reflection coefficients are treated above with err_flag0<0 already;
       % err_flag1=1 is less general, related to a particular direction of the propagation only.
       % Just in case:
       if err_flag1==1
	 fid10=fopen('Problems.out','a');
	 fprintf(fid10,'\n *** RppRps and Azim_ChristEq: program terminated *** \n');
	 fclose(fid10);
	 fprintf('\n *** RppRps and Azim_ChristEq: program terminated *** \n')
	 break 
       end;
       
       
       p1 = n1/Vel(1);
       p2 = n2/Vel(1);
       p3 = ChristEq(C1, p1, p2, 1);
       
       [B1, B1inv,err_flag2] = InterMatrix(w, ro1, C1, p1, p2, p3,1);
     
       if err_flag2==1

	 % if err_flag2=1, you probably just hit the S-wave singularity in the
         % incidence medium - congratulations! Polarizations are messed up;
	 % this particular reflection coefficient is artificial:
	 COEF(ii,1:3)=[1000 1000 1000];
       
       else

	 B=PPolar(C1, p1, p2, p3);
	 Slns_3=p3;
       
	 % Calculate wavelength and some other stuff for incident P wave
	 if f > eps
	   wavelength = 1/( f*sqrt(p1^2 + p2^2 + p3(1)^2) );
	 else
	   wavelength = 99.999;
	 end;
	 incangle   = atan2( (sqrt(p1^2 + p2^2)), p3(1) )*180/pi;
	 if incangle < 1.e-4
	   incazim = 0;
	 else
	   incazim = atan2(p2, p1)*180/pi;
	 end;
       
	 % REFLECTING HALFSPACE:
	 
	 ro2 = rho2;
	 cij = Cij_2;   [C, err_flag3]  = FormCij(cij,2);
	 azm = kappa;    C2 = RotateCij(C, azm);
	 p3 = ChristEq(C2, p1, p2, 2);
	
	 if err_flag3<0

	   % if err_flag3<0, the medium is not physical and the
	   % reflection coefficients are penalized :       
	   COEF(ii,1:3)=[100+err_flag3*i 100+err_flag3*i 100+err_flag3*i];

	   % Here is the check for the complex Cij's as above for the
           % reflecting medium:
	 
	 elseif norm(imag(C2),1) > 0.

%	   fid10=fopen('Problems.out','a');
%	   fprintf(fid10,'PATHETHIC REFLECTING MEDIUM real: \n c11_R=%f c12_R=%f c13_R=%f c14_R=%f c15_R=%f c16_R=%f \n c21_R=%f c22_R=%f c23_R=%f c24_R=%f c25_R=%f c26_R=%f \n c31_R=%f c32_R=%f c33_R=%f c34_R=%f c35_R=%f c36_R=%f \n c41_R=%f c42_R=%f c43_R=%f c44_R=%f c45_R=%f c46_R=%f \n  c51_R=%f c52_R=%f c53_R=%f c54_R=%f c55_R=%f c56_R=%f \n c61_R=%f c62_R=%f c63_R=%f c64_R=%f c65_R=%f c66_R=%f \n',real(C2(1,1)),real(C2(1,2)),real(C2(1,3)),real(C2(1,4)),real(C2(1,5)),real(C2(1,6)),real(C2(2,1)),real(C2(2,2)),real(C2(2,3)),real(C2(2,4)),real(C2(2,5)),real(C2(2,6)),real(C2(3,1)),real(C2(3,2)),real(C2(3,3)),real(C2(3,4)),real(C2(3,5)),real(C2(3,6)),real(C2(4,1)),real(C2(4,2)),real(C2(4,3)),real(C2(4,4)),real(C2(4,5)),real(C2(4,6)),real(C2(5,1)),real(C2(5,2)),real(C2(5,3)),real(C2(5,4)),real(C2(5,5)),real(C2(5,6)),real(C2(6,1)),real(C2(6,2)),real(C2(6,3)),real(C2(6,4)),real(C2(6,5)),real(C2(6,6)));
%	   fprintf(fid10,'PATHETHIC REFLECTING MEDIUM imag: \n c11_I=%f c12_I=%f c13_I=%f c14_I=%f c15_I=%f c16_I=%f \n c21_I=%f c22_I=%f c23_I=%f c24_I=%f c25_I=%f c26_I=%f \n c31_I=%f c32_I=%f c33_I=%f c34_I=%f c35_I=%f c36_I=%f \n c41_I=%f c42_I=%f c43_I=%f c44_I=%f c45_I=%f c46_I=%f \n  c51_I=%f c52_I=%f c53_I=%f c54_I=%f c55_I=%f c56_I=%f \n c61_I=%f c62_I=%f c63_I=%f c64_I=%f c65_I=%f c66_I=%f \n',imag(C2(1,1)),imag(C2(1,2)),imag(C2(1,3)),imag(C2(1,4)),imag(C2(1,5)),imag(C2(1,6)),imag(C2(2,1)),imag(C2(2,2)),imag(C2(2,3)),imag(C2(2,4)),imag(C2(2,5)),imag(C2(2,6)),imag(C2(3,1)),imag(C2(3,2)),imag(C2(3,3)),imag(C2(3,4)),imag(C2(3,5)),imag(C2(3,6)),imag(C2(4,1)),imag(C2(4,2)),imag(C2(4,3)),imag(C2(4,4)),imag(C2(4,5)),imag(C2(4,6)),imag(C2(5,1)),imag(C2(5,2)),imag(C2(5,3)),imag(C2(5,4)),imag(C2(5,5)),imag(C2(5,6)),imag(C2(6,1)),imag(C2(6,2)),imag(C2(6,3)),imag(C2(6,4)),imag(C2(6,5)),imag(C2(6,6)));
%	   fclose(fid10);
	   COEF(ii,1:3)=[100+100*i 100+100*i 100+100*i];
	   	   
	 else
   	 
	   % Take into account the first interface
	   [B2, B2inv, err_flag4] = InterMatrix(w, ro2, C2, p1, p2, p3, 2);

	   if err_flag4==1

	     % if err_flag4=1, you probably just hit the S-wave singularity in the
	     % reflecting medium - congratulations! Polarizations are
             % messed up; this particulat reflection coefficient is artificial:
	     COEF(ii,1:3)=[1000 1000 1000];
	   
	   else;

	     MM = B2inv*B1;
	   
	     %-------------------------------------------------------
	     % Here I deactivate the computation over a layered medium
	     % (Nlayrs = 0 here)
	     %if Nlayer ~= -1
	     %..Loop over plane layers
	     %   tau = 0;   Vnmosum2 = 0;
	     %   for ilayer=1:Nlayer
	     %      z = fscanf(fin, '%g', 1);
	     %      L = LayerMatrix(w, z, p3);
	     %      B1 = B2;   B1inv = B2inv;   ro1 = ro2;   C1 = C2;   
	     %      ro2 = fscanf(fin, '%g', 1);
	     %      cij = fscanf(fin, '%g', 12);   C  = FormCij(cij);
	     %      azm = fscanf(fin, '%g', 1);    C2 = RotateCij(C, azm);
	     
	     %      p3 = ChristEq(C2, p1, p2);
	     %      [B2, B2inv] = InterMatrix(w, ro2, C2, p1, p2, p3);
	     %      MM = B2inv*B1*L*MM;
	     %   end;
	     %end;
	     %status = fclose(fin);
	     %-------------------------------------------------------
	     
	     % Here is the valuable result:
	     
	     R = ReflPP(MM);   
	     COEF(ii,1:3)=R';
       
	   end;      % end of err_flag4
	 end;      % end of err_flag3
       end;      % end of err_flag2
     end;      % end of err_flag0 and err_flag1
     
     % the computed quantities are:
     % R(1)=Rpp;
     % R(2)=Rps1;
     % R(3)=Rps2;
     % p1,p2 ... horizontal slowness components;
     % p3(1:3)=Slns_3(1:3) ... vertical slowness components of PP,PS1 and
     %                         PS2 incident waves (The sign is
     %                         non-uniquely determined. Since this
     %                         is for the z-plane symmetric anisotropy only,
     %                         - sign should correspond to the
     %                         upgoing (against down-pointing z-axis), 
     %                         + to the downgoing waves in the inc. halfspace.
     % B ... 3x3 matrix whose 1st, 2nd and 3rd column represent (x,y,x)
     %       coordinates of the PP-, PS1- and PS2 polarization vectors
     %       of the upgoing (p3<0) or downgoing (p3>0) waves in the 
     %       incidence halfspace;
     
   end; % End of the loop over inc. angles and azimuths
 end;   % End the loop over frequences

%%%%% END OF FILE %%%%%%%%%%%%%%%%%%%%

 




