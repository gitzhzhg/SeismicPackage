%==============================================================================
% Objective function for the recovery of ISO parameters, minimizing the misfit  
% misfit = || data - reflection coefficients ||
%==============================================================================

function F = ISO_objective(medium,inc,azim,n_run,WEIGHT);

% medium=[Drho DV33 DV55 b_a]  
% WEIGHT=0 ... no automatic weighting of data performed  

  
global Pdata
global Sdata
global RECORD

     PENALTY=2.;                % PENALTY should be >> 1 if you invert
                                % REAL reflection coefficients 
				% (pre-critical reflection), and should be
				% close to 1 otherwise.
     PERIOD=5;

     if n_run<0
       name='EVOLUTION_S.out';
       n_run=-n_run;
     else
       name='EVOLUTION.out';
     end;
     
% 0) Get the artificial model parameters:

     Drho=medium(1);
     DV33=medium(2);
     DV55=medium(3);
     b_a=medium(4);
     kappa=0.;
     
     a1=3.0;                     % THIS IS MY CHOICE!!! (should be arbitrary)
     rho1=2.5;                   % THIS IS MY CHOICE!!! (should be arbitrary)
     a2=a1*(1+0.5*DV33)/(1-0.5*DV33);
     b1=b_a*(a2+a1)*(0.5-0.25*DV55);
     b2=b_a*(a2+a1)-b1;
     rho2=rho1*(1+0.5*Drho)/(1-0.5*Drho);

% 1) Compute Cij's for the model:
%    Cij=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66]

     A11=a1^2; A22=A11; A33=A11; 
     A44=b1^2; A55=A44; A66=A44;
     A12=A11-2*A66; A13=A12; A23=A12;
     A16=0; A26=0; A36=0;
     Cij_1=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66];
     
     A11=a2^2; A22=A11; A33=A11; 
     A44=b2^2; A55=A44; A66=A44;
     A12=A11-2*A66; A13=A12; A23=A12;
     A16=0; A26=0; A36=0;
     Cij_2=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66];
         
% 2) Compute the reflection coefficients for the Cij's above:

     Rcoef=RppRps(rho1,Cij_1,rho2,Cij_2,inc,azim,kappa);
     
% 3) Compute the objective function F:
    
     % Find the data weights:
  
     PM=max(abs(Pdata));
     SM=max(abs(Sdata));
     MM=max([PM SM]);
     PW=MM/PM;
     SW=MM/SM;
     
     % Evaluate the objective function:

     Pdim=length(Pdata);
     Sdim=length(Sdata);
     
     FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
     FF(Pdim+1:1:Pdim+Sdim)=SW*(Sdata-sqrt(Rcoef(:,2).^2+Rcoef(:,3).^2));
     F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
     Fprint=sum(F.^2);
     if WEIGHT==0
       fprintf('*** automatic weighting disactivated ***\n');
       fprintf('*** misfit with weighting: \t F_objective=%11.7f \n', Fprint);
       PW=1;
       SW=1;
       FF(1:1:Pdim)=PW*(Pdata-Rcoef(:,1));
       FF(Pdim+1:1:Pdim+Sdim)=SW*(Sdata-sqrt(Rcoef(:,2).^2+Rcoef(:,3).^2));
       F=real(FF) + PENALTY*sign(real(FF)).*abs(imag(FF));
       Fprint=sum(F.^2);
     end;      
     
% 4) Print out and store some semi-results:

     fprintf('ISO REALIZATION #: %i \t F_objective=%11.7f \n', n_run, Fprint);

     if rem((RECORD-1),PERIOD) == 0
       if n_run==1 & RECORD==1
	 fid10=fopen(name,'w');
       else
	 fid10=fopen(name,'a');
       end;   
       ITER=1+(RECORD-1)/PERIOD;
       fprintf(fid10,'%i \t %i \t %11.5f \t %f \t %f \t %f \t %f \n',[n_run,ITER,Fprint,real(medium)]);
       fclose(fid10);
     end;
     RECORD=RECORD+1;
     
     if sum(abs(imag(medium))) > 1e-3
       fprintf('\n!WARNING!\n occurence of an imaginary medium parameter \n');
       fprintf('Drho_I=%f DV33_I=%f DV55_I=%f b_a_I=%f \n',imag(medium));
     end;

% some remainings which may be sometimes useful     
%     fprintf('ISO REALIZATION #: %i \t F_objective=%11.7f \n', n_run, Fprint);
%     fid10=fopen('RunInfo.out','a');
%     fprintf(fid10,'ERROR REALIZATION #: %i \t F_objective=%11.7f PW=%f SW=%f \n', n_run, Fprint,PW,SW);
%     fprintf(fid10,'Drho_R=%f DV33_R=%f DV55_R=%f b_a_R=%f \n',real(medium));
%     fprintf(fid10,'Drho_I=%f DV33_I=%f DV55_I=%f b_a_I=%f \n',imag(medium));
%     fclose(fid10);
     %----------------------------------------
     
     %------------
%%% END OF FILE %%%%%%%%%%%%%%%     



