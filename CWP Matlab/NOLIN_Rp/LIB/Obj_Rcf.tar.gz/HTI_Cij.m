%==============================================================
% Transformatin of the Tsvankin's medium parameters into Cij's:  
% HTI MEDIUM
%==============================================================

function G = HTI_Cij(medium);

% medium=[v33,v55,eps_v,delta_v,gamma]  
% G= [A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66] 
  
% 1) more convenient notation:
 
  v33=medium(1);
  v55=medium(2);
  e=medium(3);
  d=medium(4);
  g=medium(5);

% 2) Cij's:

  A33=v33^2;
  A55=v55^2;
  A11=A33*(1+2*e);
  A22=A33;
  A44=A55*(1+2*g);
  A66=A55;
  
  A13=sqrt(2*A33*(A33-A55)*d+(A33-A55)^2)-A55;
  A12=A13;
  A23=A33-2*A44;
  A16=0;
  A26=0;
  A36=0;

  
% 3) Form the function G:
 
  G=[A11 A12 A13 A16 A22 A23 A26 A33 A36 A44 A55 A66];
