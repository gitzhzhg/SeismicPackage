function p = randperm(n);
%RANDPERM Random permutation.
%   RANDPERM(n) is a random permutation of the integers from 1 to n.
%   For example, RANDPERM(6) might be [2 4 5 6 1 3].
%   
%   Note that RANDPERM calls RAND and therefore changes RAND's state.
%
%   See also PERMUTE.

%   Copyright 1984-2001 The MathWorks, Inc.
%   $Revision: 5.9 $  $Date: 2001/04/15 12:00:18 $

[ignore,p] = sort(rand(1,n));
