%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ORT_GraphIt is the subroutine used in the main GraphIt routine to graph
% Fobj, inverted medium parameters, and their combinations for ORT and
% ORTxORT models. All user made changes should be done below the lines
% denoted "USER CHANGES-PARAMETERS:" and "USER CHANGES-COMBINATIONS:".
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function   [F1,AF1,F2,AF2]=ORT_GraphIt(model_ID,EVOLUTION,CR,CE,SW)

% SW..switch=1 only primary set of plots, =2 secondary plots, =3 both

F1=[];
AF1=[];
F2=[];
AF2=[];
M=length(find(EVOLUTION(:,1)==-100));
fprintf('\n Number of models being analysed: %i \n',M);
[x y]=size(EVOLUTION);


if SW==1 | SW==3
  F1=figure(1);
  K=1;
  for J=1:M
    graph=[];
    L=1;
    while EVOLUTION(K,:)~=[-100]
      graph(L,1:y)=EVOLUTION(K,:);
      L=L+1;
      K=K+1;
    end;

% USER CHANGES-PARAMETERS:
    G1=subplot(7,3,1);
    plot(graph(:,2),graph(:,3),'Color',CR);
    ylabel('F_{obj}','FontSize', 14,'FontWeight','bold','Position',[-8.0 1.5 0]);
    set(gca,'YLim',[0 3]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.65];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G2=subplot(7,3,2);
    plot(graph(:,2),graph(:,4),'Color',CR);
    ylabel('\Delta\rho/\rho','FontSize', 14,'Position',[-8.0 0.175 0]);
    set(gca,'YLim',[0.10 0.25]);                                                               
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.182];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G3=subplot(7,3,3);
    plot(graph(:,2),graph(:,5),'Color',CR);
    ylabel('\Delta\alpha/\alpha','FontSize', 14.,'Position',[-8.0 0.28 0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.286];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G4=subplot(7,3,4);
    plot(graph(:,2),graph(:,6),'Color',CR);
    ylabel('\Delta\beta/\beta','FontSize', 14.,'Position',[-8.0 0.5 0]);
    set(gca,'YLim',[0.0 1.0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.462];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G5=subplot(7,3,5);
    plot(graph(:,2),graph(:,7),'Color',CR);
    ylabel('\beta/\alpha','FontSize', 14.,'Position',[-8.0 0.55 0]);
    set(gca,'YLim',[0.5 0.6]);  
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.56];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G6=subplot(7,3,6);
    plot(graph(:,2),graph(:,8),'Color',CR);
    ylabel('\epsilon_{1}^{(1)}','FontSize', 14.,'Position',[-6.0 -0.15 0]);
    set(gca,'YLim',[-0.25 -0.05]);    
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G7=subplot(7,3,7);
    plot(graph(:,2),graph(:,9),'Color',CR);
    ylabel('\epsilon_{1}^{(2)}','FontSize', 14.,'Position',[-6.0 0.15 0]);
    set(gca,'YLim',[0.05 0.25]);      
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G8=subplot(7,3,8);
    plot(graph(:,2),graph(:,10),'Color',CR);
    ylabel('\delta_{1}^{(1)}','FontSize', 14.,'Position',[-8.0 -0.215 0]);
    set(gca,'YLim',[-0.25 -0.15]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.2];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G9=subplot(7,3,9);
    plot(graph(:,2),graph(:,11),'Color',CR);
    ylabel('\delta_{1}^{(2)}','FontSize', 14.,'Position',[-8.0 0.1 0]);
    set(gca,'YLim',[0.05 0.15]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.1];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G10=subplot(7,3,10);
    plot(graph(:,2),graph(:,12),'Color',CR);
    ylabel('\gamma_{1}^{(1)}','FontSize', 14.,'Position',[-8.0 0.14 0]);
    set(gca,'YLim',[0.1 0.2]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G11=subplot(7,3,11);
    plot(graph(:,2),graph(:,13),'Color',CR);
    ylabel('\gamma_{1}^{(2)}','FontSize', 14.,'Position',[-8.0 0.04 0]);
    set(gca,'YLim',[0.0 0.1]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.05];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G12=subplot(7,3,12);
    plot(graph(:,2),graph(:,14),'Color',CR);
    ylabel('\delta_{1}^{(3)}','FontSize', 14.,'Position',[-8.0 0.1 0]);
    set(gca,'YLim',[-0.05 0.25]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G13=subplot(7,3,13);
    plot(graph(:,2),graph(:,15),'Color',CR);
    ylabel('\epsilon_{2}^{(1)}','FontSize', 14.,'Position',[-7.0 -0.03 0]);
    set(gca,'YLim',[-0.25 0.20]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);

    G14=subplot(7,3,14);
    plot(graph(:,2),graph(:,16),'Color',CR);
    ylabel('\epsilon_{2}^{(2)}','FontSize', 14.,'Position',[-7.0 -0.05 0]);
    set(gca,'YLim',[-0.3 0.2]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.25];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G15=subplot(7,3,15);
    plot(graph(:,2),graph(:,17),'Color',CR);
    ylabel('\delta_{2}^{(1)}','FontSize', 14.,'Position',[-7.0 0.0 0]);
    set(gca,'YLim',[-0.3 0.3]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.1];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G16=subplot(7,3,16);
    plot(graph(:,2),graph(:,18),'Color',CR);
    ylabel('\delta_{2}^{(2)}','FontSize', 14.,'Position',[-8.0 -0.1 0]);
    set(gca,'YLim',[-0.5 0.2]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.2];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G17=subplot(7,3,17);
    plot(graph(:,2),graph(:,19),'Color',CR);
    ylabel('\gamma_{2}^{(1)}','FontSize', 14.,'Position',[-6.0 -0.0 0]);
    set(gca,'YLim',[-0.3 0.3]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.08];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G18=subplot(7,3,18);
    plot(graph(:,2),graph(:,20),'Color',CR);
    ylabel('\gamma_{2}^{(2)}','FontSize', 14.,'Position',[-6.0 -0.0 0]);
    set(gca,'YLim',[-0.3 0.3]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.07];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G19=subplot(7,3,19);
    plot(graph(:,2),graph(:,21),'Color',CR);
    ylabel('\delta_{2}^{(3)}','FontSize', 14.,'Position',[-8.0 -0.0 0]);
    set(gca,'YLim',[-0.4 0.4]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.1];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    AF1=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17 G18 G19];
    if model_ID==6
      G20=subplot(7,3,20);
      plot(graph(:,2),graph(:,22),'Color',CR);
      ylabel('\kappa','FontSize', 14.,'Position',[-6.0 45.0 0]);
      set(gca,'YLim',[0.0 90],'YTick',[0 30 60 90]);        
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[30];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      AF1=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17 G18 G19 G20];
    end;
    %(graph(:,2));
    K=K+1;
  end;
  set(F1,'Position',[200    86   830   700]);
  set(AF1,'XLim',[1 10]);
end;

if SW==2 | SW==3
  F2=figure(2);
  K=1;
  for J=1:M
    graph=[];
    L=1;
    while EVOLUTION(K,:)~=[-100]
      graph(L,1:y)=EVOLUTION(K,:);
      L=L+1;
      K=K+1;
    end;
    r=graph(:,4); a=graph(:,5); b=graph(:,6); b_a=graph(:,7);
    e11=graph(:,8); e21=graph(:,9); d11=graph(:,10); d21=graph(:,11);
    g11=graph(:,12); g21=graph(:,13); d31=graph(:,14);
    e12=graph(:,15); e22=graph(:,16); d12=graph(:,17); d22=graph(:,18);
    g12=graph(:,19); g22=graph(:,20); d32=graph(:,21);
    kap=graph(:,22);
    G=(r+2*b+0.25*r.*b.^2)./(1+0.25*b.^2+0.5*r.*b);
    gs_1=(g11-g21)./(1+2*g21);
    gs_2=(g12-g22)./(1+2*g22);
    
% USER CHANGES-COMBINATIONS:    
    G1=subplot(7,3,1);
    plot(graph(:,2),graph(:,3),'Color',CR);
    ylabel('F_{obj}','FontSize',14,'FontWeight','bold','Position',[-8.0 1.5 0]);
    set(gca,'YLim',[0 3]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.65];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G2=subplot(7,3,2);
    plot(graph(:,2),r+a,'Color',CR);
    ylabel('(\Delta\rho/\rho)+(\Delta\alpha/\alpha)','FontSize',12,'Position',[-9.0 0.45 0]);
    set(gca,'YLim',[0.41 0.48]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.468];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G3=subplot(7,3,3);
    plot(graph(:,2),G,'Color',CR);
    ylabel('\DeltaG/G','FontSize',14,'Position',[-6.0 1.10 0]);
    set(gca,'YLim',[0.75 1.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[1.018];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G4=subplot(7,3,4);
    plot(graph(:,2),e11-e21,'Color',CR);
    ylabel('\epsilon_{1}^{(1)}-\epsilon_{1}^{(2)}','FontSize',14,'Position',[-8.0 -0.30 0]);
    set(gca,'YLim',[-0.4 -0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.3];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G5=subplot(7,3,5);
    plot(graph(:,2),d11-d21,'Color',CR);
    ylabel('\delta_{1}^{(1)}-\delta_{1}^{(2)}','FontSize',14,'Position',[-8.0 -0.3 0]);
    set(gca,'YLim',[-0.4 -0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.3];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G6=subplot(7,3,6);
    plot(graph(:,2),gs_1,'Color',CR);
    ylabel('\gamma_{1}^{(S)}','FontSize',14,'Position',[-8.0 0.1 0]);
    set(gca,'YLim',[-0.0 0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.091];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G7=subplot(7,3,7);
    plot(graph(:,2),d31+e21-e11,'Color',CR);
    ylabel('\delta^{(3)}_{1}+\epsilon^{(2)}_{1}-\epsilon^{(1)}_{1}','FontSize',14,'Position',[-8.0 0.3 0]);
    set(gca,'YLim',[0.0 0.7]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.45];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G8=subplot(7,3,8);
    plot(graph(:,2),e12-e22,'Color',CR);
    ylabel('\epsilon_{2}^{(1)}-\epsilon_{2}^{(2)}','FontSize',14,'Position',[-7.0 0.0 0]);
    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.1];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G9=subplot(7,3,9);
    plot(graph(:,2),d12-d22,'Color',CR);
    ylabel('\delta_{2}^{(1)}-\delta_{2}^{(2)}','FontSize',14,'Position',[-7.0 0.0 0]);
    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.1];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G10=subplot(7,3,10);
    plot(graph(:,2),gs_2,'Color',CR);
    ylabel('\gamma_{2}^{(S)}','FontSize',14,'Position',[-8.0 -0.0 0]);
    set(gca,'YLim',[-0.3 0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.132];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G11=subplot(7,3,11);
    plot(graph(:,2),d32+e22-e12,'Color',CR);
    ylabel('\delta^{(3)}_{2}+\epsilon^{(2)}_{2}-\epsilon^{(1)}_{2}','FontSize',14,'Position',[-8.0 -0.08 0]);
    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.0];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G12=subplot(7,3,12);
    plot(graph(:,2),e22-e21,'Color',CR);
    ylabel('\epsilon_{2}^{(2)}-\epsilon_{1}^{(2)}','FontSize',14,'Position',[-8.0 -0.2 0]);
    set(gca,'YLim',[-0.5 0.05]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.4];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G13=subplot(7,3,13);
    plot(graph(:,2),d22-d21,'Color',CR);
    ylabel('\delta_{2}^{(2)}-\delta_{1}^{(2)}','FontSize',14,'Position',[-8.0 -0.15 0]);
    set(gca,'YLim',[-0.5 0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.3];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    if model_ID==6
      PP=d22-d12+8*(b_a).^2.*gs_2;
      PS=(1./(2*(1+b_a))).*(d22-d12)+2*(b_a).*gs_2;
      G14=subplot(7,3,14);
      plot(graph(:,2),PP,'Color',CR);
      ylabel('PP','FontSize',14,'Position',[-6.0 -0.0 0]);
      set(gca,'YLim',[-0.8 0.5]);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[-0.423];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G15=subplot(7,3,15);
      plot(graph(:,2),PS,'Color',CR);
      ylabel('PS','FontSize',14,'Position',[-6.0 -0.00 0]);
      set(gca,'YLim',[-0.3 0.2]);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[-0.179];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
%      G16=subplot(7,3,16);
%      plot(graph(:,2),PP.*cos(2*kap*pi/180),'Color',CR);
%      ylabel('PPcos','FontSize',14,'Position',[-2.2 -0.25 0]);
%      set(gca,'YLim',[-1.0 0.5]);
%      hold on;
%      yy=[];
%      yy(1:length(graph(:,2)))=[-0.213];
%      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
%      
%      G17=subplot(7,3,17);
%      plot(graph(:,2),PP.*sin(2*kap*pi/180),'Color',CR);
%      ylabel('PPsin','FontSize',14,'Position',[-2.2 -0.25 0]);
%      set(gca,'YLim',[-1.0 0.5]);
%      hold on;
%      yy=[];
%      yy(1:length(graph(:,2)))=[-0.370];
%      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
%      
%      G18=subplot(7,3,18);
%      plot(graph(:,2),PS.*cos(2*kap*pi/180),'Color',CR);
%      ylabel('PScos','FontSize',14,'Position',[-2.2 -0.1 0]);
%      set(gca,'YLim',[-0.4 0.2]);
%      hold on;
%      yy=[];
%      yy(1:length(graph(:,2)))=[-0.089];
%      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
%      
%      G19=subplot(7,3,19);
%      plot(graph(:,2),PS.*sin(2*kap*pi/180),'Color',CR);
%      ylabel('PSsin','FontSize',14,'Position',[-2.2 -0.05 0]);
%      set(gca,'YLim',[-0.3 0.2]);
%      hold on;
%      yy=[];
%      yy(1:length(graph(:,2)))=[-0.155];
%      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
%      
%      AF2=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17 G18 G19];          
      AF2=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15];
    end;
    
    K=K+1;
  end;

  set(F2,'Position',[200    86   830   700]);
  set(AF2,'XLim',[1 10]);
end;

%%%%%%%%% END OF FILE %%%%%%%%%%



