%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HTI_GraphIt is the subroutine used in the main GraphIt routine to graph
% Fobj, inverted medium parameters, and their combinations for HTI and
% HTIxHTI models. All user made changes should be done below the lines
% denoted "USER CHANGES-PARAMETERS:" and "USER CHANGES-COMBINATIONS:".
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function   [F1,AF1,F2,AF2]=HTI_GraphIt(model_ID,EVOLUTION,CR,CE,SW)

% SW..switch=1 only primary set of plots, =2 secondary plots, =3 both

F1=[];
AF1=[];
F2=[];
AF2=[];
M=length(find(EVOLUTION(:,1)==-100));
fprintf('\n Number of models being analysed: %i \n',M);
[x y]=size(EVOLUTION);


if SW==1 | SW==3
  F1=figure(1);
  K=1;
  for J=1:M
    graph=[];
    L=1;
    while EVOLUTION(K,:)~=[-100]
      graph(L,1:y)=EVOLUTION(K,:);
      L=L+1;
      K=K+1;
    end;
    
% USER CHANGES-PARAMETERS:    
    G1=subplot(4,3,1);
    plot(graph(:,2),graph(:,3),'Color',CR);
    ylabel('F_{obj}','FontSize', 14,'FontWeight','bold','Position',[-6 2.5 0]);
    set(gca,'YLim',[0 5.0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.55];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G2=subplot(4,3,2);
    plot(graph(:,2),graph(:,4),'Color',CR);
    ylabel('\Delta\rho/\rho','FontSize', 14,'Position',[-6 0.2 0]);
%    set(gca,'YLim',[-1.0 1.0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.1132];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G3=subplot(4,3,3);
    plot(graph(:,2),graph(:,5),'Color',CR);
    ylabel('\Delta\alpha/\alpha','FontSize', 14.,'Position',[-6 0 0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.182];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G4=subplot(4,3,4);
    plot(graph(:,2),graph(:,6),'Color',CR);
    ylabel('\Delta\beta/\beta','FontSize', 14.,'Position',[-6 -0.2 0]);
%    set(gca,'YLim',[-0.5 1.0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.182];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G5=subplot(4,3,5);
    plot(graph(:,2),graph(:,7),'Color',CR);
    ylabel('\beta/\alpha','FontSize', 14.,'Position',[-6 0.5 0]);
%    set(gca,'YLim',[0.2 0.6]);  
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.357];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G6=subplot(4,3,6);
    plot(graph(:,2),graph(:,8),'Color',CR);
    ylabel('\epsilon_{1}^{(V)}','FontSize', 14.,'Position',[-6 0. 0]);
%    set(gca,'YLim',[-0.4 0.1]);    
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.05];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G7=subplot(4,3,7);
    plot(graph(:,2),graph(:,9),'Color',CR);
    ylabel('\delta_{1}^{(V)}','FontSize', 14.,'Position',[-6 0. 0]);
%    set(gca,'YLim',[-0.1 0.4]);      
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.10];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G8=subplot(4,3,8);
    plot(graph(:,2),graph(:,10),'Color',CR);
    ylabel('\gamma_{1}','FontSize', 14.,'Position',[-6 0.1 0]);
%    set(gca,'YLim',[-0.1 0.4]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.125];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G9=subplot(4,3,9);
    plot(graph(:,2),graph(:,11),'Color',CR);
    ylabel('\epsilon_{2}^{(V)}','FontSize', 14.,'Position',[-6 0.25 0]);
%    set(gca,'YLim',[-0.2 0.2]);        
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.05];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G10=subplot(4,3,10);
    plot(graph(:,2),graph(:,12),'Color',CR);
    ylabel('\delta_{2}^{(V)}','FontSize', 14.,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.3 0.3]);        
    xlabel('number of iterations','FontSize', 14.);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.06];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G11=subplot(4,3,11);
    plot(graph(:,2),graph(:,13),'Color',CR);
    ylabel('\gamma_{2}','FontSize', 14.,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.25 0.25]);        
    xlabel('number of iterations','FontSize', 14.);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.125];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    AF1=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10];
    if model_ID==4
      G12=subplot(4,3,12);
      plot(graph(:,2),graph(:,14),'Color',CR);
      ylabel('\kappa','FontSize', 14.,'Position',[-6 50.0 0]);
%      set(gca,'YLim',[0.0 90],'YTick',[0 30 60 90]);        
      xlabel('number of iterations','FontSize', 14.);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[30];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      AF1=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12];
    end;
    %(graph(:,2));
    K=K+1;
  end;
  set(F1,'Position',[200    86   830   700]);
  set(AF1,'XLim',[1 10]);
end;

if SW==2 | SW==3
  F2=figure(2);
  K=1;
  for J=1:M
    graph=[];
    L=1;
    while EVOLUTION(K,:)~=[-100]
      graph(L,1:y)=EVOLUTION(K,:);
      L=L+1;
      K=K+1;
    end;
    r=graph(:,4); a=graph(:,5); b=graph(:,6); b_a=graph(:,7);
    ev1=graph(:,8); dv1=graph(:,9); g1=graph(:,10); ev2=graph(:,11);
    dv2=graph(:,12); g2=graph(:,13); 
    if model_ID==4
      kap=graph(:,14);
    end;
    G=(r+2*b+0.25*r.*b.^2)./(1+0.25*b.^2+0.5*r.*b);

% USER CHANGES-COMBINATIONS:    
    
%    G1=subplot(7,3,1);
%    plot(graph(:,2),graph(:,3),'Color',CR);
%    ylabel('F_{obj}','FontSize',14,'FontWeight','bold','Position',[-6 1.5 0]);
%    set(gca,'YLim',[0 3]);
%    hold on;
%    yy=[];
%    yy(1:length(graph(:,2)))=[0.55];
%    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G2=subplot(7,3,1);
    plot(graph(:,2),r+a,'Color',CR);
    ylabel('(\Delta\rho/\rho)+(\Delta\alpha/\alpha)','FontSize',12,'Position',[-6 0.45 0]);
%    set(gca,'YLim',[0.41 0.48]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.295];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G3=subplot(7,3,2);
    plot(graph(:,2),G,'Color',CR);
    ylabel('\DeltaG/G','FontSize',14,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[0.0 2.0]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.4691];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G4=subplot(7,3,3);
    plot(graph(:,2),ev1-ev2.*cos(2*kap*pi/180),'Color',CR);
    ylabel('\epsilon_{1}^{(V)}-\epsilon_{2}^{(V)}cos(2\kappa)','FontSize',12,'Position',[-6 0.15 0]);
%    set(gca,'YLim',[-0.5 0.3]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.025];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G5=subplot(7,3,4);
    plot(graph(:,2),dv1-dv2.*cos(2*kap*pi/180),'Color',CR);
    ylabel('\delta_{1}^{(V)}-\delta_{2}^{(V)}cos(2\kappa)','FontSize',12,'Position',[-6 -0.10 0]);
%    set(gca,'YLim',[-0.5 0.3]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.13];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G6=subplot(7,3,5);
    plot(graph(:,2),g1-g2.*cos(2*kap*pi/180),'Color',CR);
    ylabel('\gamma_{1}-\gamma_{2}cos(2\kappa)','FontSize',12,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.1 0.4]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.0625];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G7=subplot(7,3,6);
    plot(graph(:,2),ev2.*sin(2*kap*pi/180),'Color',CR);
    ylabel('\epsilon^{(V)}_{2}sin(2\kappa)','FontSize',12,'Position',[-6 -0.30 0]);
%    set(gca,'YLim',[-0.5 0.7]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.043];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G8=subplot(7,3,7);
    plot(graph(:,2),dv2.*sin(2*kap*pi/180),'Color',CR);
    ylabel('\delta_{2}^{(V)}sin(2\kappa)','FontSize',12,'Position',[-6 -0.20 0]);
%    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.052];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G9=subplot(7,3,8);
    plot(graph(:,2),g2.*sin(2*kap*pi/180),'Color',CR);
    ylabel('\gamma_{2}sin(2\kappa)','FontSize',12,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.108];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G10=subplot(7,3,9);
    plot(graph(:,2),ev2-ev1,'Color',CR);
    ylabel('\epsilon^{(V)}_{2}-\epsilon^{(V)}_{1}','FontSize',12,'Position',[-6 -0.0 0]);
%    set(gca,'YLim',[-0.6 0.6]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.0];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);

    G11=subplot(7,3,10);
    plot(graph(:,2),dv2-dv1,'Color',CR);
    ylabel('\delta_{2}^{(V)}-\delta_{1}^{(V)}','FontSize',12,'Position',[-6 -0.2 0]);
%    set(gca,'YLim',[-0.4 0.2]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.16];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G12=subplot(7,3,11);
    plot(graph(:,2),dv1-ev1,'Color',CR);
    ylabel('\delta^{(V)}_{1}-\epsilon^{(V)}_{1}','FontSize',12,'Position',[-6 -0.0 0]);
%    set(gca,'YLim',[-0.6 0.6]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[0.15];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    G13=subplot(7,3,12);
    plot(graph(:,2),dv2-ev2,'Color',CR);
    ylabel('\delta_{2}^{(V)}-\epsilon_{2}^{(V)}','FontSize',12,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.5 0.5]);
    hold on;
    yy=[];
    yy(1:length(graph(:,2)))=[-0.01];
    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
%    G14=subplot(7,3,13);
%    plot(graph(:,2),dv1-ev1-(dv2-ev2).*cos(4*kap*pi/180),'Color',CR);
%    ylabel('F(\delta_{2}^{(2)},\epsilon_{1}^{(2)},4\kappa)','FontSize',12,'Position',[-6 0.0 0]);
%    set(gca,'YLim',[-0.5 0.3]);
%    hold on;
%    yy=[];
%    yy(1:length(graph(:,2)))=[0.145];
%    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
    
    if model_ID==4
      PP=dv2+8*(b_a).^2.*g2;
      PS=(1./(2*(1+b_a))).*(dv2)+2*(b_a).*g2;
      G15=subplot(7,3,13);
      plot(graph(:,2),PP,'Color',CR);
      ylabel('PP','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-1.0 0.5]);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.068];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G16=subplot(7,3,14);
      plot(graph(:,2),PS,'Color',CR);
      ylabel('PS','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-0.5 0.2]);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.0674];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G17=subplot(7,3,15);
      plot(graph(:,2),PP.*cos(2*kap*pi/180),'Color',CR);
      ylabel('PPcos','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-1.0 0.5]);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.034];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G18=subplot(7,3,16);
      plot(graph(:,2),PP.*sin(2*kap*pi/180),'Color',CR);
      ylabel('PPsin','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-1.0 0.5]);
      xlabel('number of iterations','FontSize',12);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.0589];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G19=subplot(7,3,17);
      plot(graph(:,2),PS.*cos(2*kap*pi/180),'Color',CR);
      ylabel('PScos','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-0.4 0.2]);
      xlabel('number of iterations','FontSize',12);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.0337];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
      G20=subplot(7,3,18);
      plot(graph(:,2),PS.*sin(2*kap*pi/180),'Color',CR);
      ylabel('PSsin','FontSize',12,'Position',[-6 -0.0 0]);
%      set(gca,'YLim',[-0.3 0.2]);
      xlabel('number of iterations','FontSize',12);
      hold on;
      yy=[];
      yy(1:length(graph(:,2)))=[0.0583];
      plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
      
%      AF2=[G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17 G18 ...
%	   G19 G20];
      AF2=[G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G15 G16 G17 G18 ...
	   G19 G20];
    end;
    
    K=K+1;
  end;

  set(F2,'Position',[200    86   830   700]);
  set(AF2,'XLim',[1 10]);
end;

%%%%%%%%% END OF FILE %%%%%%%%%%



