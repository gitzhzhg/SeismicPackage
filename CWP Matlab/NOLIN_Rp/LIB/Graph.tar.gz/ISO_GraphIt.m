%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ISO_GraphIt is the subroutine used in the main GraphIt routine to graph
% Fobj and inverted medium parameters for ISO models. All user made
% changes should be done below the line denoted "USER CHANGES:".
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function   [F1,AF1]=ISO_GraphIt(EVOLUTION,CR,CE)

F1=[];
AF1=[];
F2=[];
AF2=[];
M=length(find(EVOLUTION(:,1)==-100));
fprintf('\n Number of models being analysed: %i \n',M);
[x y]=size(EVOLUTION);


F1=figure(1);
K=1;
for J=1:M
  graph=[];
  L=1;
  while EVOLUTION(K,:)~=[-100]
    graph(L,1:y)=EVOLUTION(K,:);
    L=L+1;
    K=K+1;
  end;
  
% USER CHANGES:

  G1=subplot(3,2,1);
  plot(graph(:,2),graph(:,3),'Color',CR);
  ylabel('F_{obj}','FontSize', 18,'FontWeight','bold','Position',[-6 1.0 0]);
  xlabel('number of iterations','FontSize', 16,'FontWeight','bold');
  set(gca,'YLim',[0 2.0],'FontSize',12);
  hold on;
  yy=[];
  %    yy(1:length(graph(:,2)))=[0.20];
  %    plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
  
  G2=subplot(3,2,2);
  plot(graph(:,2),graph(:,4),'Color',CR);
  ylabel('\Delta\rho/\rho','FontSize', 18,'Position',[-6 0.2 0]);
  xlabel('number of iterations','FontSize', 16,'FontWeight','bold');
  set(gca,'YLim',[0.0 0.3],'FontSize',12);
  hold on;
  yy=[];
  yy(1:length(graph(:,2)))=[0.1132];
  plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
  
  G3=subplot(3,2,3);
  plot(graph(:,2),graph(:,5),'Color',CR);
  ylabel('\Delta\alpha/\alpha','FontSize', 18.,'Position',[-6 0 0]);
  xlabel('number of iterations','FontSize', 16,'FontWeight','bold');
  hold on;
  yy=[];
  set(gca,'FontSize',12);
  yy(1:length(graph(:,2)))=[0.1818];
  plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
  
  G4=subplot(3,2,4);
  plot(graph(:,2),graph(:,6),'Color',CR);
  ylabel('\Delta\beta/\beta','FontSize', 18.,'Position',[-6 -0.2 0]);
  %    set(gca,'YLim',[-0.5 1.0]);
  set(gca,'FontSize',12);
  xlabel('number of iterations','FontSize', 16,'FontWeight','bold');
  hold on;
  yy=[];
  yy(1:length(graph(:,2)))=[0.1818];
  plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
  
  G5=subplot(3,2,5);
  plot(graph(:,2),graph(:,7),'Color',CR);
  ylabel('\beta/\alpha','FontSize', 18.,'Position',[-6 0.5 0]);
  set(gca,'YLim',[0.2 0.6],'FontSize',12);  
  xlabel('number of iterations','FontSize', 16,'FontWeight','bold');
  hold on;
  yy=[];
  yy(1:length(graph(:,2)))=[0.40];
  plot(graph(:,2),yy,'Color',CE,'LineWidth',2);
  
  AF1=[G1 G2 G3 G4 G5];
  K=K+1;
end;

set(F1,'Position',[200    86   830   700]);
set(AF1,'XLim',[1 10]);

%%%%%%%%% END OF FILE %%%%%%%%%%



