function args = formula(fun)
%FORMULA Function formula.
%   FORMULA(FUN) returns the formula for the INLINE object FUN.
%
%   See also INLINE/ARGNAMES, INLINE/CHAR.

%   Copyright 1984-2001 The MathWorks, Inc. 
%   $Revision: 1.7 $  $Date: 2001/04/15 11:59:18 $

args = fun.expr;
