function fig = gcbf
%GCBF Get handle to current callback figure.
%   FIG = GCBF returns the handle of the figure that contains the object
%   whose callback is currently executing.  If the current callback object
%   is the figure, the figure is returned.
%
%   When no callbacks are executing, GCBF returns [].  If the current figure
%   gets deleted during callback execution, GCBF returns [].
%
%   The return value of GCBF is identical to the FIGURE output argument of
%   GCBO.
%
%   See also GCBO, GCO, GCF, GCA.

%   Copyright 1984-2001 The MathWorks, Inc. 
%   $Revision: 1.9 $  $Date: 2001/04/15 11:59:49 $

[obj, fig] = gcbo;
