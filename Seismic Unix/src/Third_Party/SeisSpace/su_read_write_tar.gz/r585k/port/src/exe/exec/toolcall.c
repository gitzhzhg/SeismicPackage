#include <string.h>
/* RCS: ProMAX $Id: flowcall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/* N.B. The toolcall.c module name is hardwired below */
#ifndef RCS_C_H_
#define RCS_C_H_
#include "sccsinc/silent_running.h"
static const char* rcsid = " $RCSfile$ toolcall.c $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $";
#include "sccsinc/normal_running.h"
#endif/*RCS_C_H_*/

void flow_tcaller( char *ctool, float *trace, int *ithdr );

FCALLSCSUB3(flow_tcaller,FLOW_TCALLER,flow_tcaller,STRING,PFLOAT,PINT)

void flow_tcaller( char *ctool, float *trace, int *ithdr )
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("FLOW_ELSE")) && !strncasecmp(ctool,"FLOW_ELSE",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_ELSE,exec_flow_else,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_ELSE,exec_flow_else,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_ELSEIF")) && !strncasecmp(ctool,"FLOW_ELSEIF",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_ELSEIF,exec_flow_elseif,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_ELSEIF,exec_flow_elseif,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_ENDIF")) && !strncasecmp(ctool,"FLOW_ENDIF",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_ENDIF,exec_flow_endif,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_ENDIF,exec_flow_endif,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_IF")) && !strncasecmp(ctool,"FLOW_IF",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_IF,exec_flow_if,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_IF,exec_flow_if,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_STOP")) && !strncasecmp(ctool,"FLOW_STOP",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_STOP,exec_flow_stop,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_STOP,exec_flow_stop,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SPLIT")) && !strncasecmp(ctool,"SPLIT",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_IF,exec_flow_if,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_IF,exec_flow_if,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
/* RCS:   ProMAX $Id: flowcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in flow_tcaller", 34);
    }
}

/* RCS: ProMAX $Id: panelcall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       ens_panel_tcaller
 *******************************************************************************
 *
 *       description:
 *               calls the current ensemble or panel tool, passing along the
 *               2-d array of traces and trace headers.
 *
 *       input arguments:
 *               ctool     - the name of the tool that needs to be called
 *
 *       input/output arguments:
 *               traces    - the 2-d array of traces
 *               ithdrs    - the 2-d array of trace headers
 *               nstored   - number of traces stored and returned
 *
 *       original code by d.e. diller, march 30, 1989
 *
 ******************************************************************************/

void ens_panel_tcaller( char *ctool, float *traces, int *ithdrs, int *nstored );

FCALLSCSUB4(ens_panel_tcaller,ENS_PANEL_TCALLER,ens_panel_tcaller,STRING,PFLOAT,PINT,PINT)

void ens_panel_tcaller( char *ctool, float *traces, int *ithdrs, int *nstored )
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("ADD_NOISE")) && !strncasecmp(ctool,"ADD_NOISE",len)) {
	PROTOCCALLSFSUB4(EXEC_ADD_NOISE,exec_add_noise,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ADD_NOISE,exec_add_noise,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ARRAY_COMP")) && !strncasecmp(ctool,"ARRAY_COMP",len)) {
	PROTOCCALLSFSUB4(EXEC_ARRAY_COMP,exec_array_comp,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ARRAY_COMP,exec_array_comp,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ASCII_ATTR_OUT")) && !strncasecmp(ctool,"ASCII_ATTR_OUT",len)) {
	PROTOCCALLSFSUB4(EXEC_ASCII_ATTR_OUT,exec_ascii_attr_out,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ASCII_ATTR_OUT,exec_ascii_attr_out,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("AVO_GATHER")) && !strncasecmp(ctool,"AVO_GATHER",len)) {
	PROTOCCALLSFSUB4(EXEC_AVO_GATHER,exec_avo_gather,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_AVO_GATHER,exec_avo_gather,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("A_CN3D")) && !strncasecmp(ctool,"A_CN3D",len)) {
	PROTOCCALLSFSUB4(EXEC_A_CN3D,exec_a_cn3d,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_A_CN3D,exec_a_cn3d,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("A_FF3D")) && !strncasecmp(ctool,"A_FF3D",len)) {
	PROTOCCALLSFSUB4(EXEC_A_FF3D,exec_a_ff3d,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_A_FF3D,exec_a_ff3d,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("COH_FILT")) && !strncasecmp(ctool,"COH_FILT",len)) {
	PROTOCCALLSFSUB4(EXEC_COH_FILT,exec_coh_filt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_COH_FILT,exec_coh_filt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("DEBUG1")) && !strncasecmp(ctool,"DEBUG1",len)) {
	PROTOCCALLSFSUB4(EXEC_DEBUG1,exec_debug1,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_DEBUG1,exec_debug1,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("DESIG")) && !strncasecmp(ctool,"DESIG",len)) {
	PROTOCCALLSFSUB4(EXEC_DESIG,exec_desig,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_DESIG,exec_desig,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("DIPVELS")) && !strncasecmp(ctool,"DIPVELS",len)) {
	PROTOCCALLSFSUB4(EXEC_DIPVELS,exec_dipvels,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_DIPVELS,exec_dipvels,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("DMOFK_PANEL")) && !strncasecmp(ctool,"DMOFK_PANEL",len)) {
	PROTOCCALLSFSUB4(EXEC_DMOFK_PANEL,exec_dmofk_panel,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_DMOFK_PANEL,exec_dmofk_panel,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("DMOTX_PANEL")) && !strncasecmp(ctool,"DMOTX_PANEL",len)) {
	PROTOCCALLSFSUB4(EXEC_DMOTX_PANEL,exec_dmotx_panel,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_DMOTX_PANEL,exec_dmotx_panel,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("EDITAPPLY")) && !strncasecmp(ctool,"EDITAPPLY",len)) {
	PROTOCCALLSFSUB4(EXEC_EDITAPPLY,exec_editapply,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_EDITAPPLY,exec_editapply,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("EDITTRAIN")) && !strncasecmp(ctool,"EDITTRAIN",len)) {
	PROTOCCALLSFSUB4(EXEC_EDITTRAIN,exec_edittrain,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_EDITTRAIN,exec_edittrain,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("EIGFILT")) && !strncasecmp(ctool,"EIGFILT",len)) {
	PROTOCCALLSFSUB4(EXEC_EIGFILT,exec_eigfilt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_EIGFILT,exec_eigfilt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_BALANCE")) && !strncasecmp(ctool,"ENS_BALANCE",len)) {
	PROTOCCALLSFSUB4(EXEC_ENS_BALANCE,exec_ens_balance,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ENS_BALANCE,exec_ens_balance,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_DECON")) && !strncasecmp(ctool,"ENS_DECON",len)) {
	PROTOCCALLSFSUB4(EXEC_ENS_DECON,exec_ens_decon,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ENS_DECON,exec_ens_decon,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_SLICE")) && !strncasecmp(ctool,"ENS_SLICE",len)) {
	PROTOCCALLSFSUB4(EXEC_ENS_SLICE,exec_ens_slice,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ENS_SLICE,exec_ens_slice,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_VALUE")) && !strncasecmp(ctool,"ENS_VALUE",len)) {
	PROTOCCALLSFSUB4(EXEC_ENS_VALUE,exec_ens_value,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ENS_VALUE,exec_ens_value,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("ESSD_DEPHASE")) && !strncasecmp(ctool,"ESSD_DEPHASE",len)) {
	PROTOCCALLSFSUB4(EXEC_ESSD_DEPHASE,exec_essd_dephase,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ESSD_DEPHASE,exec_essd_dephase,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FBAPPLY")) && !strncasecmp(ctool,"FBAPPLY",len)) {
	PROTOCCALLSFSUB4(EXEC_FBAPPLY,exec_fbapply,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FBAPPLY,exec_fbapply,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FBTRAIN")) && !strncasecmp(ctool,"FBTRAIN",len)) {
	PROTOCCALLSFSUB4(EXEC_FBTRAIN,exec_fbtrain,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FBTRAIN,exec_fbtrain,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FB_PREDICT")) && !strncasecmp(ctool,"FB_PREDICT",len)) {
	PROTOCCALLSFSUB4(EXEC_FB_PREDICT,exec_fb_predict,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FB_PREDICT,exec_fb_predict,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FILT_2D")) && !strncasecmp(ctool,"FILT_2D",len)) {
	PROTOCCALLSFSUB4(EXEC_FILT_2D,exec_filt_2d,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FILT_2D,exec_filt_2d,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FKFILT")) && !strncasecmp(ctool,"FKFILT",len)) {
	PROTOCCALLSFSUB4(EXEC_FKFILT,exec_fkfilt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FKFILT,exec_fkfilt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FK_FILT")) && !strncasecmp(ctool,"FK_FILT",len)) {
	PROTOCCALLSFSUB4(EXEC_FK_FILT,exec_fk_filt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FK_FILT,exec_fk_filt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("FXDECON")) && !strncasecmp(ctool,"FXDECON",len)) {
	PROTOCCALLSFSUB4(EXEC_FXDECON,exec_fxdecon,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_FXDECON,exec_fxdecon,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("IMP2F2")) && !strncasecmp(ctool,"IMP2F2",len)) {
	PROTOCCALLSFSUB4(EXEC_IMP2F2,exec_imp2f2,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_IMP2F2,exec_imp2f2,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("KLT_CANCL")) && !strncasecmp(ctool,"KLT_CANCL",len)) {
	PROTOCCALLSFSUB4(EXEC_KLT_CANCL,exec_klt_cancl,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_KLT_CANCL,exec_klt_cancl,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("LFAF")) && !strncasecmp(ctool,"LFAF",len)) {
	PROTOCCALLSFSUB4(EXEC_LFAF,exec_lfaf,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_LFAF,exec_lfaf,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("MB_TRANS")) && !strncasecmp(ctool,"MB_TRANS",len)) {
	PROTOCCALLSFSUB4(EXEC_MB_TRANS,exec_mb_trans,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_MB_TRANS,exec_mb_trans,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTK_PANEL")) && !strncasecmp(ctool,"MIGTK_PANEL",len)) {
	PROTOCCALLSFSUB4(EXEC_MIGTK_PANEL,exec_migtk_panel,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_MIGTK_PANEL,exec_migtk_panel,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("NAFLTR")) && !strncasecmp(ctool,"NAFLTR",len)) {
	PROTOCCALLSFSUB4(EXEC_NAFLTR,exec_nafltr,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_NAFLTR,exec_nafltr,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("NEWSTOLT")) && !strncasecmp(ctool,"NEWSTOLT",len)) {
	PROTOCCALLSFSUB4(EXEC_NEWSTOLT,exec_newstolt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_NEWSTOLT,exec_newstolt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("NMO_INFILL")) && !strncasecmp(ctool,"NMO_INFILL",len)) {
	PROTOCCALLSFSUB4(EXEC_NMO_INFILL,exec_nmo_infill,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_NMO_INFILL,exec_nmo_infill,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("NNHPTRAIN")) && !strncasecmp(ctool,"NNHPTRAIN",len)) {
	PROTOCCALLSFSUB4(EXEC_NNHPTRAIN,exec_nnhptrain,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_NNHPTRAIN,exec_nnhptrain,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("NOISE_EDIT")) && !strncasecmp(ctool,"NOISE_EDIT",len)) {
	PROTOCCALLSFSUB4(EXEC_NOISE_EDIT,exec_noise_edit,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_NOISE_EDIT,exec_noise_edit,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("PHASE")) && !strncasecmp(ctool,"PHASE",len)) {
	PROTOCCALLSFSUB4(EXEC_PHASE,exec_phase,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_PHASE,exec_phase,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PRECOM70")) && !strncasecmp(ctool,"PRECOM70",len)) {
	PROTOCCALLSFSUB4(EXEC_PRECOM70,exec_precom70,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_PRECOM70,exec_precom70,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("PSMIG")) && !strncasecmp(ctool,"PSMIG",len)) {
	PROTOCCALLSFSUB4(EXEC_PSMIG,exec_psmig,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_PSMIG,exec_psmig,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("REVAPPLY")) && !strncasecmp(ctool,"REVAPPLY",len)) {
	PROTOCCALLSFSUB4(EXEC_REVAPPLY,exec_revapply,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_REVAPPLY,exec_revapply,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("REVTRAIN")) && !strncasecmp(ctool,"REVTRAIN",len)) {
	PROTOCCALLSFSUB4(EXEC_REVTRAIN,exec_revtrain,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_REVTRAIN,exec_revtrain,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("SG_CDP")) && !strncasecmp(ctool,"SG_CDP",len)) {
	PROTOCCALLSFSUB4(EXEC_SG_CDP,exec_sg_cdp,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_SG_CDP,exec_sg_cdp,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("TX_SWTGAIN")) && !strncasecmp(ctool,"TX_SWTGAIN",len)) {
	PROTOCCALLSFSUB4(EXEC_TX_SWTGAIN,exec_tx_swtgain,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_TX_SWTGAIN,exec_tx_swtgain,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("VABATCH")) && !strncasecmp(ctool,"VABATCH",len)) {
	PROTOCCALLSFSUB4(EXEC_VABATCH,exec_vabatch,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_VABATCH,exec_vabatch,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VAPRECOM")) && !strncasecmp(ctool,"VAPRECOM",len)) {
	PROTOCCALLSFSUB4(EXEC_VAPRECOM,exec_vaprecom,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_VAPRECOM,exec_vaprecom,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("VSPCDP")) && !strncasecmp(ctool,"VSPCDP",len)) {
	PROTOCCALLSFSUB4(EXEC_VSPCDP,exec_vspcdp,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_VSPCDP,exec_vspcdp,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
    } else if ((((size_t) len+1) == sizeof("WEMR")) && !strncasecmp(ctool,"WEMR",len)) {
	PROTOCCALLSFSUB4(EXEC_WEMR,exec_wemr,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_WEMR,exec_wemr,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0]);
/* RCS:   ProMAX $Id: panelcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in ens_panel_tcaller", 40);
    }
}

/* RCS: ProMAX $Id: bufcall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       buff_flow_tcaller
 *******************************************************************************
 *
 *       description:
 *               calls the flow routine for single or double buffered tools.
 *
 *       input arguments:
 *               ctool      - the name of the tool that needs to be called
 *               traces     - the 2-d array of traces
 *               ithdrs     - the 2-d array of trace headers
 *               nstored    - number of traces currently stored
 *               ifound_eoj - flag to indicate if the eoj trace has been
 *                            encountered (1=true)
 *       output arguments:
 *              noutput     - number of traces that the tool is ready to output
 *                            (0=more traces are needed)
 *              noverlap    - number of input traces to include in the next
 *                            buffer that is accumulated
 *
 *       original code by d.e. diller, may 11, 1992
 *
 ******************************************************************************/

void buff_flow_tcaller(char *ctool, float *traces, int * ithdrs, int *nstored,
				int *ifound_eoj, int *noutput, int *noverlap);

FCALLSCSUB7(buff_flow_tcaller,BUFF_FLOW_TCALLER,buff_flow_tcaller,STRING,PFLOAT,PINT,PINT,PINT,PINT,PINT)

void buff_flow_tcaller(char *ctool, float *traces, int * ithdrs, int *nstored,
				int *ifound_eoj, int *noutput, int *noverlap)
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("COMPARE")) && !strncasecmp(ctool,"COMPARE",len)) {
	PROTOCCALLSFSUB7(FLOW_COMPARE,flow_compare,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_COMPARE,flow_compare,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("LEVEL_STATS")) && !strncasecmp(ctool,"LEVEL_STATS",len)) {
	PROTOCCALLSFSUB7(FLOW_LEVEL_STATS,flow_level_stats,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_LEVEL_STATS,flow_level_stats,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("ORNT_COMP")) && !strncasecmp(ctool,"ORNT_COMP",len)) {
	PROTOCCALLSFSUB7(FLOW_ORNT_COMP,flow_ornt_comp,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_ORNT_COMP,flow_ornt_comp,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("PART_MOTION")) && !strncasecmp(ctool,"PART_MOTION",len)) {
	PROTOCCALLSFSUB7(FLOW_PART_MOTION,flow_part_motion,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_PART_MOTION,flow_part_motion,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("POPSTAK")) && !strncasecmp(ctool,"POPSTAK",len)) {
	PROTOCCALLSFSUB7(FLOW_POPSTAK,flow_popstak,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_POPSTAK,flow_popstak,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("RE_ORNT")) && !strncasecmp(ctool,"RE_ORNT",len)) {
	PROTOCCALLSFSUB7(FLOW_RE_ORNT,flow_re_ornt,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_RE_ORNT,flow_re_ornt,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("SEMBLANCE")) && !strncasecmp(ctool,"SEMBLANCE",len)) {
	PROTOCCALLSFSUB7(FLOW_SEMBLANCE,flow_semblance,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_SEMBLANCE,flow_semblance,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("SPLC_DSET")) && !strncasecmp(ctool,"SPLC_DSET",len)) {
	PROTOCCALLSFSUB7(FLOW_SPLC_DSET,flow_splc_dset,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_SPLC_DSET,flow_splc_dset,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("TRANS_3C")) && !strncasecmp(ctool,"TRANS_3C",len)) {
	PROTOCCALLSFSUB7(FLOW_TRANS_3C,flow_trans_3c,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_TRANS_3C,flow_trans_3c,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_INTERP")) && !strncasecmp(ctool,"TRC_INTERP",len)) {
	PROTOCCALLSFSUB7(FLOW_TRC_INTERP,flow_trc_interp,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT)
	CCALLSFSUB7(FLOW_TRC_INTERP,flow_trc_interp,PFLOAT,PINT,PINT,PINT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],nstored[0],ifound_eoj[0],noutput[0],noverlap[0]);
/* RCS:   ProMAX $Id: bufcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in buff_flow_tcaller", 40 );
    }
}

/* RCS: ProMAX $Id: sbufcall.hdr 37031 2005-05-21 21:00:18Z salevin $ $Revision: 37031 $ $Date: 2005-05-21 15:00:18 -0600 (Sat, 21 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       call snl_buff_tcaller
 *******************************************************************************
 *
 *       description:
 *               calls the current single buffered tool, passing along the
 *               2-d array of traces and trace headers.
 *
 *       input arguments:
 *               ctool     - the name of the tool that needs to be called
 *               ntr_buff  - size (in traces) of the trace buffer (equal to
 *                           max(nstored, noutput) from buff_flow_tcaller)
 *
 *       input/output arguments:
 *               traces    - the 2-d array of traces
 *               ithdrs    - the 2-d array of trace headers
 *
 *       original code by d.e. diller, march 30, 1989
 *
 ******************************************************************************/

void snl_buff_tcaller( char *ctool, float *traces, int *ithdrs, int *ntr_buff );

FCALLSCSUB4(snl_buff_tcaller,SNL_BUFF_TCALLER,snl_buff_tcaller,STRING,PFLOAT,PINT,PINT)

void snl_buff_tcaller( char *ctool, float *traces, int *ithdrs, int *ntr_buff )
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("COMPARE")) && !strncasecmp(ctool,"COMPARE",len)) {
	PROTOCCALLSFSUB4(EXEC_COMPARE,exec_compare,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_COMPARE,exec_compare,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("LEVEL_STATS")) && !strncasecmp(ctool,"LEVEL_STATS",len)) {
	PROTOCCALLSFSUB4(EXEC_LEVEL_STATS,exec_level_stats,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_LEVEL_STATS,exec_level_stats,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("ORNT_COMP")) && !strncasecmp(ctool,"ORNT_COMP",len)) {
	PROTOCCALLSFSUB4(EXEC_ORNT_COMP,exec_ornt_comp,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_ORNT_COMP,exec_ornt_comp,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("PART_MOTION")) && !strncasecmp(ctool,"PART_MOTION",len)) {
	PROTOCCALLSFSUB4(EXEC_PART_MOTION,exec_part_motion,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_PART_MOTION,exec_part_motion,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("POPSTAK")) && !strncasecmp(ctool,"POPSTAK",len)) {
	PROTOCCALLSFSUB4(EXEC_POPSTAK,exec_popstak,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_POPSTAK,exec_popstak,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("RE_ORNT")) && !strncasecmp(ctool,"RE_ORNT",len)) {
	PROTOCCALLSFSUB4(EXEC_RE_ORNT,exec_re_ornt,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_RE_ORNT,exec_re_ornt,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
    } else if ((((size_t) len+1) == sizeof("TRANS_3C")) && !strncasecmp(ctool,"TRANS_3C",len)) {
	PROTOCCALLSFSUB4(EXEC_TRANS_3C,exec_trans_3c,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB4(EXEC_TRANS_3C,exec_trans_3c,PFLOAT,PINT,PINT,PINT,traces[0],ithdrs[0],ithdrs[0],ntr_buff[0]);
/* RCS:   ProMAX $Id: sbufcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in snl_buff_tcaller", 40);
    }
}

/* RCS: ProMAX $Id: dbufcall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       dbl_buff_tcaller
 *******************************************************************************
 *
 *       description:
 *               calls the current double buffered tool, passing along the
 *               2-d arrays of traces and trace headers.
 *
 *       input arguments:
 *               ctool      - the name of the tool that needs to be called
 *               traces_in  - the 2-d array of input traces
 *               ithdrs_in  - the 2-d array of input trace headers
 *               ntr_buff_in  - the size (in traces) of the input trace
 *                              buffer (equal to nstored from buff_flow_tcaller)
 *               ntr_buff_out - the size (in traces) of the output trace
 *                              buffer (equal to noutput from buff_flow_tcaller)
 *
 *       output arguments:
 *               traces_out - the 2-d array of output traces
 *               ithdrs_out - the 2-d array of output trace headers
 *
 *       original code by d.e. diller, march 30, 1989
 *
 ******************************************************************************/

void dbl_buff_tcaller( char *ctool, float *traces_in, int *ithdrs_in,
		int *ntr_buff_in,
		float *traces_out, int * ithdrs_out,
		int *ntr_buff_out );

FCALLSCSUB7(dbl_buff_tcaller,DBL_BUFF_TCALLER,dbl_buff_tcaller,STRING,PFLOAT,PINT,PINT,PFLOAT,PINT,PINT)

void dbl_buff_tcaller( char *ctool, float *traces_in, int *ithdrs_in,
		int *ntr_buff_in, float *traces_out, int * ithdrs_out, int *ntr_buff_out )
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("SEMBLANCE")) && !strncasecmp(ctool,"SEMBLANCE",len)) {
	PROTOCCALLSFSUB8(EXEC_SEMBLANCE,exec_semblance,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB8(EXEC_SEMBLANCE,exec_semblance,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT,traces_in[0],ithdrs_in[0],ithdrs_in[0],ntr_buff_in[0],traces_out[0],ithdrs_out[0],ithdrs_out[0],ntr_buff_out[0]);
    } else if ((((size_t) len+1) == sizeof("SPLC_DSET")) && !strncasecmp(ctool,"SPLC_DSET",len)) {
	PROTOCCALLSFSUB8(EXEC_SPLC_DSET,exec_splc_dset,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB8(EXEC_SPLC_DSET,exec_splc_dset,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT,traces_in[0],ithdrs_in[0],ithdrs_in[0],ntr_buff_in[0],traces_out[0],ithdrs_out[0],ithdrs_out[0],ntr_buff_out[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_INTERP")) && !strncasecmp(ctool,"TRC_INTERP",len)) {
	PROTOCCALLSFSUB8(EXEC_TRC_INTERP,exec_trc_interp,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT)
	CCALLSFSUB8(EXEC_TRC_INTERP,exec_trc_interp,PFLOAT,PINT,PINT,PINT,PFLOAT,PINT,PINT,PINT,traces_in[0],ithdrs_in[0],ithdrs_in[0],ntr_buff_in[0],traces_out[0],ithdrs_out[0],ithdrs_out[0],ntr_buff_out[0]);
/* RCS:   ProMAX $Id: dbufcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in dbl_buff_tcaller", 40);
    }
}

/* RCS: ProMAX $Id: simplecall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       simple_toolcall
 *******************************************************************************
 *
 *       description:
 *               calls the current tool, passing along the trace and the trace
 *               header.  this routine calls those tools that need no buffering,
 *               i.e. they are simple pipes.
 *
 *       input arguments:
 *               ctool - the name of the tool that needs to be called
 *
 *       input/output arguments:
 *               trace - the trace
 *               ithdr - the trace header
 *
 *       original code by d.e. diller, march 30, 1989
 *
 ******************************************************************************/

void simple_toolcall( char *ctool, float *trace, int *ithdr );

FCALLSCSUB3(simple_toolcall,SIMPLE_TOOLCALL,simple_toolcall,STRING,PFLOAT,PINT)

void simple_toolcall( char *ctool, float *trace, int *ithdr )
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("SUWRITE")) && !strncasecmp(ctool,"SUWRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_SUWRITE,exec_suwrite,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SUWRITE,exec_suwrite,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ADAPT_DECON")) && !strncasecmp(ctool,"ADAPT_DECON",len)) {
	PROTOCCALLSFSUB3(EXEC_ADAPT_DECON,exec_adapt_decon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ADAPT_DECON,exec_adapt_decon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AGC")) && !strncasecmp(ctool,"AGC",len)) {
	PROTOCCALLSFSUB3(EXEC_AGC,exec_agc,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AGC,exec_agc,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AIRBLAST")) && !strncasecmp(ctool,"AIRBLAST",len)) {
	PROTOCCALLSFSUB3(EXEC_AIRBLAST,exec_airblast,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AIRBLAST,exec_airblast,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AMPSCAN")) && !strncasecmp(ctool,"AMPSCAN",len)) {
	PROTOCCALLSFSUB3(EXEC_AMPSCAN,exec_ampscan,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AMPSCAN,exec_ampscan,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AMP_CLIP")) && !strncasecmp(ctool,"AMP_CLIP",len)) {
	PROTOCCALLSFSUB3(EXEC_AMP_CLIP,exec_amp_clip,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AMP_CLIP,exec_amp_clip,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ASCIISPREADSHEET")) && !strncasecmp(ctool,"ASCIISPREADSHEET",len)) {
	PROTOCCALLSFSUB3(EXEC_ASCIISPREADSHEET,exec_asciispreadsheet,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ASCIISPREADSHEET,exec_asciispreadsheet,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AUTO_CORR")) && !strncasecmp(ctool,"AUTO_CORR",len)) {
	PROTOCCALLSFSUB3(EXEC_AUTO_CORR,exec_auto_corr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AUTO_CORR,exec_auto_corr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("BINNER")) && !strncasecmp(ctool,"BINNER",len)) {
	PROTOCCALLSFSUB3(EXEC_BINNER,exec_binner,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_BINNER,exec_binner,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("BLEND_OPEN")) && !strncasecmp(ctool,"BLEND_OPEN",len)) {
	PROTOCCALLSFSUB3(EXEC_BLEND_OPEN,exec_blend_open,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_BLEND_OPEN,exec_blend_open,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("CDP_TAPER")) && !strncasecmp(ctool,"CDP_TAPER",len)) {
	PROTOCCALLSFSUB3(EXEC_CDP_TAPER,exec_cdp_taper,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CDP_TAPER,exec_cdp_taper,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("CONVERT_MUTES")) && !strncasecmp(ctool,"CONVERT_MUTES",len)) {
	PROTOCCALLSFSUB3(EXEC_CONVERT_MUTES,exec_convert_mutes,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CONVERT_MUTES,exec_convert_mutes,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DATUM_STAT_APPLY")) && !strncasecmp(ctool,"DATUM_STAT_APPLY",len)) {
	PROTOCCALLSFSUB3(EXEC_DATUM_STAT_APPLY,exec_datum_stat_apply,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DATUM_STAT_APPLY,exec_datum_stat_apply,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DB_HDR_LOAD")) && !strncasecmp(ctool,"DB_HDR_LOAD",len)) {
	PROTOCCALLSFSUB3(EXEC_DB_HDR_LOAD,exec_db_hdr_load,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DB_HDR_LOAD,exec_db_hdr_load,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DEBIAS")) && !strncasecmp(ctool,"DEBIAS",len)) {
	PROTOCCALLSFSUB3(EXEC_DEBIAS,exec_debias,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DEBIAS,exec_debias,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DECON")) && !strncasecmp(ctool,"DECON",len)) {
	PROTOCCALLSFSUB3(EXEC_DECON,exec_decon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DECON,exec_decon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DEITY")) && !strncasecmp(ctool,"DEITY",len)) {
	PROTOCCALLSFSUB3(EXEC_DEITY,exec_deity,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DEITY,exec_deity,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DEPTH")) && !strncasecmp(ctool,"DEPTH",len)) {
	PROTOCCALLSFSUB3(EXEC_DEPTH,exec_depth,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DEPTH,exec_depth,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DEPTH2")) && !strncasecmp(ctool,"DEPTH2",len)) {
	PROTOCCALLSFSUB3(EXEC_DEPTH2,exec_depth2,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DEPTH2,exec_depth2,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DISKWRITE")) && !strncasecmp(ctool,"DISKWRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_DISKWRITE,exec_diskwrite,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DISKWRITE,exec_diskwrite,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DMOBIN")) && !strncasecmp(ctool,"DMOBIN",len)) {
	PROTOCCALLSFSUB3(EXEC_DMOBIN,exec_dmobin,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DMOBIN,exec_dmobin,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DS2ASCII")) && !strncasecmp(ctool,"DS2ASCII",len)) {
	PROTOCCALLSFSUB3(EXEC_DS2ASCII,exec_ds2ascii,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DS2ASCII,exec_ds2ascii,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ELEV_STAT")) && !strncasecmp(ctool,"ELEV_STAT",len)) {
	PROTOCCALLSFSUB3(EXEC_ELEV_STAT,exec_elev_stat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ELEV_STAT,exec_elev_stat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_XC_SUM")) && !strncasecmp(ctool,"EMCA_XC_SUM",len)) {
	PROTOCCALLSFSUB3(EXEC_EMCA_XC_SUM,exec_emca_xc_sum,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EMCA_XC_SUM,exec_emca_xc_sum,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EM_XCOR")) && !strncasecmp(ctool,"EM_XCOR",len)) {
	PROTOCCALLSFSUB3(EXEC_EM_XCOR,exec_em_xcor,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EM_XCOR,exec_em_xcor,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EM_XCOR_STAT")) && !strncasecmp(ctool,"EM_XCOR_STAT",len)) {
	PROTOCCALLSFSUB3(EXEC_EM_XCOR_STAT,exec_em_xcor_stat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EM_XCOR_STAT,exec_em_xcor_stat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ENVN")) && !strncasecmp(ctool,"ENVN",len)) {
	PROTOCCALLSFSUB3(EXEC_ENVN,exec_envn,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ENVN,exec_envn,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_GAIN")) && !strncasecmp(ctool,"ESI_GAIN",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_GAIN,exec_esi_gain,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_GAIN,exec_esi_gain,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_GAIN_CHECK")) && !strncasecmp(ctool,"ESI_GAIN_CHECK",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_GAIN,exec_esi_gain,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_GAIN,exec_esi_gain,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_WRITE")) && !strncasecmp(ctool,"ESI_WRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_WRITE,exec_esi_write,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_WRITE,exec_esi_write,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FBPICK")) && !strncasecmp(ctool,"FBPICK",len)) {
	PROTOCCALLSFSUB3(EXEC_FBPICK,exec_fbpick,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FBPICK,exec_fbpick,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FILTER")) && !strncasecmp(ctool,"FILTER",len)) {
	PROTOCCALLSFSUB3(EXEC_FILTER,exec_filter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FILTER,exec_filter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_COMMENT")) && !strncasecmp(ctool,"FLOW_COMMENT",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_COMMENT,exec_flow_comment,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_COMMENT,exec_flow_comment,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FRACSTAT")) && !strncasecmp(ctool,"FRACSTAT",len)) {
	PROTOCCALLSFSUB3(EXEC_FRACSTAT,exec_fracstat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FRACSTAT,exec_fracstat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HANDSTAT")) && !strncasecmp(ctool,"HANDSTAT",len)) {
	PROTOCCALLSFSUB3(EXEC_HANDSTAT,exec_handstat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HANDSTAT,exec_handstat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDR2HOR")) && !strncasecmp(ctool,"HDR2HOR",len)) {
	PROTOCCALLSFSUB3(EXEC_HDR2HOR,exec_hdr2hor,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDR2HOR,exec_hdr2hor,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDR2KIL")) && !strncasecmp(ctool,"HDR2KIL",len)) {
	PROTOCCALLSFSUB3(EXEC_HDR2KIL,exec_hdr2kil,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDR2KIL,exec_hdr2kil,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDRSTAT")) && !strncasecmp(ctool,"HDRSTAT",len)) {
	PROTOCCALLSFSUB3(EXEC_HDRSTAT,exec_hdrstat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDRSTAT,exec_hdrstat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDRWEIGHT")) && !strncasecmp(ctool,"HDRWEIGHT",len)) {
	PROTOCCALLSFSUB3(EXEC_HDRWEIGHT,exec_hdrweight,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDRWEIGHT,exec_hdrweight,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDR_DELETE")) && !strncasecmp(ctool,"HDR_DELETE",len)) {
	PROTOCCALLSFSUB3(EXEC_HDR_DELETE,exec_hdr_delete,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDR_DELETE,exec_hdr_delete,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HDR_RANGE")) && !strncasecmp(ctool,"HDR_RANGE",len)) {
	PROTOCCALLSFSUB3(EXEC_HDR_RANGE,exec_hdr_range,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HDR_RANGE,exec_hdr_range,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HEADER_RENUM")) && !strncasecmp(ctool,"HEADER_RENUM",len)) {
	PROTOCCALLSFSUB3(EXEC_HEADER_RENUM,exec_header_renum,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HEADER_RENUM,exec_header_renum,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HEADER_VALUES")) && !strncasecmp(ctool,"HEADER_VALUES",len)) {
	PROTOCCALLSFSUB3(EXEC_HEADER_VALUES,exec_header_values,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HEADER_VALUES,exec_header_values,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("HRZ_FLATTEN")) && !strncasecmp(ctool,"HRZ_FLATTEN",len)) {
	PROTOCCALLSFSUB3(EXEC_HRZ_FLATTEN,exec_hrz_flatten,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_HRZ_FLATTEN,exec_hrz_flatten,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("IES_WRITE")) && !strncasecmp(ctool,"IES_WRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_IES_WRITE,exec_ies_write,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_IES_WRITE,exec_ies_write,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("IMP")) && !strncasecmp(ctool,"IMP",len)) {
	PROTOCCALLSFSUB3(EXEC_IMP,exec_imp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_IMP,exec_imp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("INLINE_CDPBIN")) && !strncasecmp(ctool,"INLINE_CDPBIN",len)) {
	PROTOCCALLSFSUB3(EXEC_INLINE_CDPBIN,exec_inline_cdpbin,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_INLINE_CDPBIN,exec_inline_cdpbin,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("INVERT")) && !strncasecmp(ctool,"INVERT",len)) {
	PROTOCCALLSFSUB3(EXEC_INVERT,exec_invert,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_INVERT,exec_invert,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("JTOOL_TRC")) && !strncasecmp(ctool,"JTOOL_TRC",len)) {
	PROTOCCALLSFSUB3(EXEC_JTOOL_TRC,exec_jtool_trc,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_JTOOL_TRC,exec_jtool_trc,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("LMO")) && !strncasecmp(ctool,"LMO",len)) {
	PROTOCCALLSFSUB3(EXEC_LMO,exec_lmo,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_LMO,exec_lmo,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MON_SHIFT")) && !strncasecmp(ctool,"MON_SHIFT",len)) {
	PROTOCCALLSFSUB3(EXEC_MON_SHIFT,exec_mon_shift,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MON_SHIFT,exec_mon_shift,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MON_TBL_LOAD")) && !strncasecmp(ctool,"MON_TBL_LOAD",len)) {
	PROTOCCALLSFSUB3(EXEC_MON_TBL_LOAD,exec_mon_tbl_load,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MON_TBL_LOAD,exec_mon_tbl_load,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MUTE")) && !strncasecmp(ctool,"MUTE",len)) {
	PROTOCCALLSFSUB3(EXEC_MUTE,exec_mute,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MUTE,exec_mute,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("NMO")) && !strncasecmp(ctool,"NMO",len)) {
	PROTOCCALLSFSUB3(EXEC_NMO,exec_nmo,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_NMO,exec_nmo,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("NOISE_MONITOR")) && !strncasecmp(ctool,"NOISE_MONITOR",len)) {
	PROTOCCALLSFSUB3(EXEC_NOISE_MONITOR,exec_noise_monitor,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_NOISE_MONITOR,exec_noise_monitor,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("OPF_EXTRACT")) && !strncasecmp(ctool,"OPF_EXTRACT",len)) {
	PROTOCCALLSFSUB3(EXEC_OPF_EXTRACT,exec_opf_extract,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_OPF_EXTRACT,exec_opf_extract,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PHFILTER")) && !strncasecmp(ctool,"PHFILTER",len)) {
	PROTOCCALLSFSUB3(EXEC_PHFILTER,exec_phfilter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PHFILTER,exec_phfilter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("QCOMP")) && !strncasecmp(ctool,"QCOMP",len)) {
	PROTOCCALLSFSUB3(EXEC_QCOMP,exec_qcomp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_QCOMP,exec_qcomp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("QPHS")) && !strncasecmp(ctool,"QPHS",len)) {
	PROTOCCALLSFSUB3(EXEC_QPHS,exec_qphs,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_QPHS,exec_qphs,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("QSTL")) && !strncasecmp(ctool,"QSTL",len)) {
	PROTOCCALLSFSUB3(EXEC_QSTL,exec_qstl,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_QSTL,exec_qstl,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("REFLSTAT3D")) && !strncasecmp(ctool,"REFLSTAT3D",len)) {
	PROTOCCALLSFSUB3(EXEC_REFLSTAT3D,exec_reflstat3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_REFLSTAT3D,exec_reflstat3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("RESAMP")) && !strncasecmp(ctool,"RESAMP",len)) {
	PROTOCCALLSFSUB3(EXEC_RESAMP,exec_resamp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RESAMP,exec_resamp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("RESAMPLE_LOG")) && !strncasecmp(ctool,"RESAMPLE_LOG",len)) {
	PROTOCCALLSFSUB3(EXEC_RESAMPLE_LOG,exec_resample_log,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RESAMPLE_LOG,exec_resample_log,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("REVIVE_TRC")) && !strncasecmp(ctool,"REVIVE_TRC",len)) {
	PROTOCCALLSFSUB3(EXEC_REVIVE_TRC,exec_revive_trc,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_REVIVE_TRC,exec_revive_trc,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ROTATE")) && !strncasecmp(ctool,"ROTATE",len)) {
	PROTOCCALLSFSUB3(EXEC_ROTATE,exec_rotate,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ROTATE,exec_rotate,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SAMPLE_VALUES")) && !strncasecmp(ctool,"SAMPLE_VALUES",len)) {
	PROTOCCALLSFSUB3(EXEC_SAMPLE_VALUES,exec_sample_values,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SAMPLE_VALUES,exec_sample_values,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP")) && !strncasecmp(ctool,"SCAMP",len)) {
	PROTOCCALLSFSUB3(EXEC_SCAMP,exec_scamp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCAMP,exec_scamp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECONM")) && !strncasecmp(ctool,"SCDECONM",len)) {
	PROTOCCALLSFSUB3(EXEC_SCDECONM,exec_scdeconm,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCDECONM,exec_scdeconm,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SEGP1_LOAD")) && !strncasecmp(ctool,"SEGP1_LOAD",len)) {
	PROTOCCALLSFSUB3(EXEC_SEGP1_LOAD,exec_segp1_load,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SEGP1_LOAD,exec_segp1_load,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SEG_WRITE")) && !strncasecmp(ctool,"SEG_WRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_SEG_WRITE,exec_seg_write,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SEG_WRITE,exec_seg_write,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SLOC_ASSIGN")) && !strncasecmp(ctool,"SLOC_ASSIGN",len)) {
	PROTOCCALLSFSUB3(EXEC_SLOC_ASSIGN,exec_sloc_assign,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SLOC_ASSIGN,exec_sloc_assign,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SMPTOHDR")) && !strncasecmp(ctool,"SMPTOHDR",len)) {
	PROTOCCALLSFSUB3(EXEC_SMPTOHDR,exec_smptohdr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SMPTOHDR,exec_smptohdr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SPIKE")) && !strncasecmp(ctool,"SPIKE",len)) {
	PROTOCCALLSFSUB3(EXEC_SPIKE,exec_spike,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SPIKE,exec_spike,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SSD_DEPHASE")) && !strncasecmp(ctool,"SSD_DEPHASE",len)) {
	PROTOCCALLSFSUB3(EXEC_SSD_DEPHASE,exec_ssd_dephase,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SSD_DEPHASE,exec_ssd_dephase,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SYNLVXZ")) && !strncasecmp(ctool,"SYNLVXZ",len)) {
	PROTOCCALLSFSUB3(EXEC_SYNLVXZ,exec_synlvxz,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SYNLVXZ,exec_synlvxz,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAPEWRITE")) && !strncasecmp(ctool,"TAPEWRITE",len)) {
	PROTOCCALLSFSUB3(EXEC_TAPEWRITE,exec_tapewrite,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TAPEWRITE,exec_tapewrite,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAR")) && !strncasecmp(ctool,"TAR",len)) {
	PROTOCCALLSFSUB3(EXEC_TAR,exec_tar,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TAR,exec_tar,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TBL_HDR_LOAD")) && !strncasecmp(ctool,"TBL_HDR_LOAD",len)) {
	PROTOCCALLSFSUB3(EXEC_TBL_HDR_LOAD,exec_tbl_hdr_load,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TBL_HDR_LOAD,exec_tbl_hdr_load,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TE")) && !strncasecmp(ctool,"TE",len)) {
	PROTOCCALLSFSUB3(EXEC_TE,exec_te,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TE,exec_te,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TEQ")) && !strncasecmp(ctool,"TEQ",len)) {
	PROTOCCALLSFSUB3(EXEC_TEQ,exec_teq,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TEQ,exec_teq,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TEST_FAIL")) && !strncasecmp(ctool,"TEST_FAIL",len)) {
	PROTOCCALLSFSUB3(EXEC_TEST_FAIL,exec_test_fail,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TEST_FAIL,exec_test_fail,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("THDRMATH")) && !strncasecmp(ctool,"THDRMATH",len)) {
	PROTOCCALLSFSUB3(EXEC_THDRMATH,exec_thdrmath,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_THDRMATH,exec_thdrmath,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("THRESH")) && !strncasecmp(ctool,"THRESH",len)) {
	PROTOCCALLSFSUB3(EXEC_THRESH,exec_thresh,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_THRESH,exec_thresh,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_LEN")) && !strncasecmp(ctool,"TRACE_LEN",len)) {
	PROTOCCALLSFSUB3(EXEC_TRACE_LEN,exec_trace_len,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TRACE_LEN,exec_trace_len,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_STATS")) && !strncasecmp(ctool,"TRACE_STATS",len)) {
	PROTOCCALLSFSUB3(EXEC_TRACE_STATS,exec_trace_stats,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TRACE_STATS,exec_trace_stats,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_STATS")) && !strncasecmp(ctool,"TRACE_STATS",len)) {
	PROTOCCALLSFSUB3(EXEC_TRACE_STATS,exec_trace_stats,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TRACE_STATS,exec_trace_stats,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_EDIT")) && !strncasecmp(ctool,"TRC_EDIT",len)) {
	PROTOCCALLSFSUB3(EXEC_TRC_EDIT,exec_trc_edit,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TRC_EDIT,exec_trc_edit,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TSMPMATH")) && !strncasecmp(ctool,"TSMPMATH",len)) {
	PROTOCCALLSFSUB3(EXEC_TSMPMATH,exec_tsmpmath,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TSMPMATH,exec_tsmpmath,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TT3HDMAP")) && !strncasecmp(ctool,"TT3HDMAP",len)) {
	PROTOCCALLSFSUB3(EXEC_TT3HDMAP,exec_tt3hdmap,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TT3HDMAP,exec_tt3hdmap,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TVS")) && !strncasecmp(ctool,"TVS",len)) {
	PROTOCCALLSFSUB3(EXEC_TVS,exec_tvs,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TVS,exec_tvs,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TVW")) && !strncasecmp(ctool,"TVW",len)) {
	PROTOCCALLSFSUB3(EXEC_TVW,exec_tvw,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TVW,exec_tvw,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("UPHOLE_CORR")) && !strncasecmp(ctool,"UPHOLE_CORR",len)) {
	PROTOCCALLSFSUB3(EXEC_UPHOLE_CORR,exec_uphole_corr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_UPHOLE_CORR,exec_uphole_corr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("UP_DCON")) && !strncasecmp(ctool,"UP_DCON",len)) {
	PROTOCCALLSFSUB3(EXEC_UP_DCON,exec_up_dcon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_UP_DCON,exec_up_dcon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("USR_FILTER")) && !strncasecmp(ctool,"USR_FILTER",len)) {
	PROTOCCALLSFSUB3(EXEC_USR_FILTER,exec_usr_filter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_USR_FILTER,exec_usr_filter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VELOCITY_CORR")) && !strncasecmp(ctool,"VELOCITY_CORR",len)) {
	PROTOCCALLSFSUB3(EXEC_VELOCITY_CORR,exec_velocity_corr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_VELOCITY_CORR,exec_velocity_corr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VIBTEST")) && !strncasecmp(ctool,"VIBTEST",len)) {
	PROTOCCALLSFSUB3(EXEC_VIBTEST,exec_vibtest,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_VIBTEST,exec_vibtest,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("VOID")) && !strncasecmp(ctool,"VOID",len)) {
	PROTOCCALLSFSUB3(EXEC_VOID,exec_void,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_VOID,exec_void,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("V_TRANSFER")) && !strncasecmp(ctool,"V_TRANSFER",len)) {
	PROTOCCALLSFSUB3(EXEC_V_TRANSFER,exec_v_transfer,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_V_TRANSFER,exec_v_transfer,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WHITESH")) && !strncasecmp(ctool,"WHITESH",len)) {
	PROTOCCALLSFSUB3(EXEC_WHITESH,exec_whitesh,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WHITESH,exec_whitesh,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WP_APPLY")) && !strncasecmp(ctool,"WP_APPLY",len)) {
	PROTOCCALLSFSUB3(EXEC_WP_APPLY,exec_wp_apply,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WP_APPLY,exec_wp_apply,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WP_FILT")) && !strncasecmp(ctool,"WP_FILT",len)) {
	PROTOCCALLSFSUB3(EXEC_WP_FILT,exec_wp_filt,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WP_FILT,exec_wp_filt,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("W_HDRSTACK")) && !strncasecmp(ctool,"W_HDRSTACK",len)) {
	PROTOCCALLSFSUB3(EXEC_W_HDRSTACK,exec_w_hdrstack,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_W_HDRSTACK,exec_w_hdrstack,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("W_IHDRHIST")) && !strncasecmp(ctool,"W_IHDRHIST",len)) {
	PROTOCCALLSFSUB3(EXEC_W_IHDRHIST,exec_w_ihdrhist,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_W_IHDRHIST,exec_w_ihdrhist,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("W_PROCESS")) && !strncasecmp(ctool,"W_PROCESS",len)) {
	PROTOCCALLSFSUB3(EXEC_W_PROCESS,exec_w_process,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_W_PROCESS,exec_w_process,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("XTAR")) && !strncasecmp(ctool,"XTAR",len)) {
	PROTOCCALLSFSUB3(EXEC_XTAR,exec_xtar,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_XTAR,exec_xtar,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PROWESS_STUB")) && !strncasecmp(ctool,"PROWESS_STUB",len)) {
	PROTOCCALLSFSUB3(EXEC_PROWESS_STUB,exec_prowess_stub,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROWESS_STUB,exec_prowess_stub,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
/* RCS:   ProMAX $Id: simplecall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else {
	ex_err_fatal_("tool not recognized in simple_toolcall", 40);
    }
}

/* RCS: ProMAX $Id: cmplxcall.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       complex_toolcall
 *******************************************************************************
 *
 *       description:
 *               calls the current tool, passing along the trace and
 *               the trace header.  tools called by this routine are
 *               those that do their own buffering.
 *
 *       input arguments:
 *               ctool - the name of the tool that needs to be called
 *
 *       input/output arguments:
 *               trace - the trace
 *               ithdr - the trace header
 *
 *       original code by d.e. diller, march 30, 1989
 *
 ******************************************************************************/

void complex_toolcall( char *ctool, float *trace, int *ithdr );

FCALLSCSUB3(complex_toolcall,COMPLEX_TOOLCALL,complex_toolcall,STRING,PFLOAT,PINT)

void complex_toolcall( char *ctool, float *trace, int *ithdr ) 
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("SUREAD")) && !strncasecmp(ctool,"SUREAD",len)) {
	PROTOCCALLSFSUB3(EXEC_SUREAD,exec_suread,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SUREAD,exec_suread,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("END_SPLIT")) && !strncasecmp(ctool,"END_SPLIT",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOW_ENDIF,exec_flow_endif,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOW_ENDIF,exec_flow_endif,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SUPER2D")) && !strncasecmp(ctool,"SUPER2D",len)) {
	PROTOCCALLSFSUB3(EXEC_SUPER2D,exec_super2d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SUPER2D,exec_super2d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SUPER3D")) && !strncasecmp(ctool,"SUPER3D",len)) {
	PROTOCCALLSFSUB3(EXEC_SUPER3D,exec_super3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SUPER3D,exec_super3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("ACOUSTIC_FD")) && !strncasecmp(ctool,"ACOUSTIC_FD",len)) {
	PROTOCCALLSFSUB3(EXEC_ACOUSTIC_FD,exec_acoustic_fd,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ACOUSTIC_FD,exec_acoustic_fd,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("ACOUSTIC_IMP")) && !strncasecmp(ctool,"ACOUSTIC_IMP",len)) {
	PROTOCCALLSFSUB3(EXEC_ACOUSTIC_IMP,exec_acoustic_imp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ACOUSTIC_IMP,exec_acoustic_imp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("AVO")) && !strncasecmp(ctool,"AVO",len)) {
	PROTOCCALLSFSUB3(EXEC_AVO,exec_avo,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AVO,exec_avo,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("AVO_ATTCOMP")) && !strncasecmp(ctool,"AVO_ATTCOMP",len)) {
	PROTOCCALLSFSUB3(EXEC_AVO_ATTCOMP,exec_avo_attcomp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_AVO_ATTCOMP,exec_avo_attcomp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("BLEND_CLOSE")) && !strncasecmp(ctool,"BLEND_CLOSE",len)) {
	PROTOCCALLSFSUB3(EXEC_BLEND_CLOSE,exec_blend_close,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_BLEND_CLOSE,exec_blend_close,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("CHECK_SHOT")) && !strncasecmp(ctool,"CHECK_SHOT",len)) {
	PROTOCCALLSFSUB3(EXEC_CHECK_SHOT,exec_check_shot,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CHECK_SHOT,exec_check_shot,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("CHEV_HEADER")) && !strncasecmp(ctool,"CHEV_HEADER",len)) {
	PROTOCCALLSFSUB3(EXEC_CHEV_HEADER,exec_chev_header,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CHEV_HEADER,exec_chev_header,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("CROSS_CORR")) && !strncasecmp(ctool,"CROSS_CORR",len)) {
	PROTOCCALLSFSUB3(EXEC_CROSS_CORR,exec_cross_corr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CROSS_CORR,exec_cross_corr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("CVS")) && !strncasecmp(ctool,"CVS",len)) {
	PROTOCCALLSFSUB3(EXEC_CVS,exec_cvs,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_CVS,exec_cvs,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("DEPTH_TIME")) && !strncasecmp(ctool,"DEPTH_TIME",len)) {
	PROTOCCALLSFSUB3(EXEC_DEPTH_TIME,exec_depth_time,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DEPTH_TIME,exec_depth_time,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("DISKREAD")) && !strncasecmp(ctool,"DISKREAD",len)) {
	PROTOCCALLSFSUB3(EXEC_DISKREAD,exec_diskread,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DISKREAD,exec_diskread,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DISKREAD2")) && !strncasecmp(ctool,"DISKREAD2",len)) {
	PROTOCCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DISK_INSERT")) && !strncasecmp(ctool,"DISK_INSERT",len)) {
	PROTOCCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DISP_3D")) && !strncasecmp(ctool,"DISP_3D",len)) {
	PROTOCCALLSFSUB3(EXEC_DISP_3D,exec_disp_3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DISP_3D,exec_disp_3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DMOCOFF")) && !strncasecmp(ctool,"DMOCOFF",len)) {
	PROTOCCALLSFSUB3(EXEC_DMOCOFF,exec_dmocoff,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DMOCOFF,exec_dmocoff,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DMOJ")) && !strncasecmp(ctool,"DMOJ",len)) {
	PROTOCCALLSFSUB3(EXEC_DMOJ,exec_dmoj,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DMOJ,exec_dmoj,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DMOTX")) && !strncasecmp(ctool,"DMOTX",len)) {
	PROTOCCALLSFSUB3(EXEC_DMOTX,exec_dmotx,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DMOTX,exec_dmotx,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("DSMB")) && !strncasecmp(ctool,"DSMB",len)) {
	PROTOCCALLSFSUB3(EXEC_DSMB,exec_dsmb,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_DSMB,exec_dsmb,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EIGEN_STACK")) && !strncasecmp(ctool,"EIGEN_STACK",len)) {
	PROTOCCALLSFSUB3(EXEC_EIGEN_STACK,exec_eigen_stack,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EIGEN_STACK,exec_eigen_stack,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_DB")) && !strncasecmp(ctool,"EMCA_DB",len)) {
	PROTOCCALLSFSUB3(EXEC_EMCA_DB,exec_emca_db,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EMCA_DB,exec_emca_db,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_GS")) && !strncasecmp(ctool,"EMCA_GS",len)) {
	PROTOCCALLSFSUB3(EXEC_EMCA_GS,exec_emca_gs,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_EMCA_GS,exec_emca_gs,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_COMBINE")) && !strncasecmp(ctool,"ENS_COMBINE",len)) {
	PROTOCCALLSFSUB3(EXEC_ENS_COMBINE,exec_ens_combine,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ENS_COMBINE,exec_ens_combine,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_DEFINE")) && !strncasecmp(ctool,"ENS_DEFINE",len)) {
	PROTOCCALLSFSUB3(EXEC_ENS_DEFINE,exec_ens_define,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ENS_DEFINE,exec_ens_define,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_SPLIT")) && !strncasecmp(ctool,"ENS_SPLIT",len)) {
	PROTOCCALLSFSUB3(EXEC_ENS_SPLIT,exec_ens_split,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ENS_SPLIT,exec_ens_split,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_STATISTICS")) && !strncasecmp(ctool,"ENS_STATISTICS",len)) {
	PROTOCCALLSFSUB3(EXEC_ENS_STATISTICS,exec_ens_statistics,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ENS_STATISTICS,exec_ens_statistics,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_INSERT")) && !strncasecmp(ctool,"ESI_INSERT",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_READ,exec_esi_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_READ,exec_esi_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_READ")) && !strncasecmp(ctool,"ESI_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_READ,exec_esi_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_READ,exec_esi_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_TEST")) && !strncasecmp(ctool,"ESI_TEST",len)) {
	PROTOCCALLSFSUB3(EXEC_ESI_TEST,exec_esi_test,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ESI_TEST,exec_esi_test,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FDMIG")) && !strncasecmp(ctool,"FDMIG",len)) {
	PROTOCCALLSFSUB3(EXEC_FDMIG,exec_fdmig,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FDMIG,exec_fdmig,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FD_DEPTH_MIG")) && !strncasecmp(ctool,"FD_DEPTH_MIG",len)) {
	PROTOCCALLSFSUB3(EXEC_FD_DEPTH_MIG,exec_fd_depth_mig,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FD_DEPTH_MIG,exec_fd_depth_mig,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FFT_INTERP")) && !strncasecmp(ctool,"FFT_INTERP",len)) {
	PROTOCCALLSFSUB3(EXEC_FFT_INTERP,exec_fft_interp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FFT_INTERP,exec_fft_interp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FKITER")) && !strncasecmp(ctool,"FKITER",len)) {
	PROTOCCALLSFSUB3(EXEC_FKITER,exec_fkiter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FKITER,exec_fkiter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FKMIG3D")) && !strncasecmp(ctool,"FKMIG3D",len)) {
	PROTOCCALLSFSUB3(EXEC_FKMIG3D,exec_fkmig3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FKMIG3D,exec_fkmig3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FK_GEN")) && !strncasecmp(ctool,"FK_GEN",len)) {
	PROTOCCALLSFSUB3(EXEC_FK_GEN,exec_fk_gen,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FK_GEN,exec_fk_gen,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FLOPPY_READ")) && !strncasecmp(ctool,"FLOPPY_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_FLOPPY_READ,exec_floppy_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FLOPPY_READ,exec_floppy_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FT_GEN")) && !strncasecmp(ctool,"FT_GEN",len)) {
	PROTOCCALLSFSUB3(EXEC_FT_GEN,exec_ft_gen,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FT_GEN,exec_ft_gen,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FXYDECON")) && !strncasecmp(ctool,"FXYDECON",len)) {
	PROTOCCALLSFSUB3(EXEC_FXYDECON,exec_fxydecon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FXYDECON,exec_fxydecon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("FX_INTERP")) && !strncasecmp(ctool,"FX_INTERP",len)) {
	PROTOCCALLSFSUB3(EXEC_FX_INTERP,exec_fx_interp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FX_INTERP,exec_fx_interp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("GEOM_LOAD")) && !strncasecmp(ctool,"GEOM_LOAD",len)) {
	PROTOCCALLSFSUB3(EXEC_GEOM_LOAD,exec_geom_load,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_GEOM_LOAD,exec_geom_load,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("IES_READ")) && !strncasecmp(ctool,"IES_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_IES_READ,exec_ies_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_IES_READ,exec_ies_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("INLINE_SORT")) && !strncasecmp(ctool,"INLINE_SORT",len)) {
	PROTOCCALLSFSUB3(EXEC_INLINE_SORT,exec_inline_sort,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_INLINE_SORT,exec_inline_sort,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("JTOOL_READ")) && !strncasecmp(ctool,"JTOOL_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_JTOOL_READ,exec_jtool_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_JTOOL_READ,exec_jtool_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("KIR_P_TOOL")) && !strncasecmp(ctool,"KIR_P_TOOL",len)) {
	PROTOCCALLSFSUB3(EXEC_KIR_P_TOOL,exec_kir_p_tool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_KIR_P_TOOL,exec_kir_p_tool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LDISPLAY")) && !strncasecmp(ctool,"LDISPLAY",len)) {
	PROTOCCALLSFSUB3(EXEC_LDISPLAY,exec_ldisplay,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_LDISPLAY,exec_ldisplay,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_BLOCK")) && !strncasecmp(ctool,"LOG_BLOCK",len)) {
	PROTOCCALLSFSUB3(EXEC_LOG_BLOCK,exec_log_block,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_LOG_BLOCK,exec_log_block,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_MFILTER")) && !strncasecmp(ctool,"LOG_MFILTER",len)) {
	PROTOCCALLSFSUB3(EXEC_LOG_MFILTER,exec_log_mfilter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_LOG_MFILTER,exec_log_mfilter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_READ")) && !strncasecmp(ctool,"LOG_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_LOG_READ,exec_log_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_LOG_READ,exec_log_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("MARINE_QC")) && !strncasecmp(ctool,"MARINE_QC",len)) {
	PROTOCCALLSFSUB3(EXEC_MARINE_QC,exec_marine_qc,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MARINE_QC,exec_marine_qc,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MATCH")) && !strncasecmp(ctool,"MATCH",len)) {
	PROTOCCALLSFSUB3(EXEC_MATCH,exec_match,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MATCH,exec_match,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MATCH3D")) && !strncasecmp(ctool,"MATCH3D",len)) {
	PROTOCCALLSFSUB3(EXEC_MATCH3D,exec_match3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MATCH3D,exec_match3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTAPER")) && !strncasecmp(ctool,"MIGTAPER",len)) {
	PROTOCCALLSFSUB3(EXEC_MIGTAPER,exec_migtaper,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MIGTAPER,exec_migtaper,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTK")) && !strncasecmp(ctool,"MIGTK",len)) {
	PROTOCCALLSFSUB3(EXEC_MIGTK,exec_migtk,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MIGTK,exec_migtk,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MTD")) && !strncasecmp(ctool,"MTD",len)) {
	PROTOCCALLSFSUB3(EXEC_MTD,exec_mtd,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MTD,exec_mtd,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MUTE_TEST")) && !strncasecmp(ctool,"MUTE_TEST",len)) {
	PROTOCCALLSFSUB3(EXEC_MUTE_TEST,exec_mute_test,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MUTE_TEST,exec_mute_test,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MWMATCH")) && !strncasecmp(ctool,"MWMATCH",len)) {
	PROTOCCALLSFSUB3(EXEC_MWMATCH,exec_mwmatch,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MWMATCH,exec_mwmatch,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("NNHPAPPLY")) && !strncasecmp(ctool,"NNHPAPPLY",len)) {
	PROTOCCALLSFSUB3(EXEC_NNHPAPPLY,exec_nnhpapply,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_NNHPAPPLY,exec_nnhpapply,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PAD_TRACES")) && !strncasecmp(ctool,"PAD_TRACES",len)) {
	PROTOCCALLSFSUB3(EXEC_PAD_TRACES,exec_pad_traces,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PAD_TRACES,exec_pad_traces,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PARALLEL_TOOL")) && !strncasecmp(ctool,"PARALLEL_TOOL",len)) {
	PROTOCCALLSFSUB3(EXEC_PARALLEL_TOOL,exec_parallel_tool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PARALLEL_TOOL,exec_parallel_tool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PM_HYBRID_TOOL")) && !strncasecmp(ctool,"PM_HYBRID_TOOL",len)) {
	PROTOCCALLSFSUB3(EXEC_PM_HYBRID_TOOL,exec_pm_hybrid_tool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PM_HYBRID_TOOL,exec_pm_hybrid_tool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("POSTSTACK_3D")) && !strncasecmp(ctool,"POSTSTACK_3D",len)) {
	PROTOCCALLSFSUB3(EXEC_POSTSTACK_3D,exec_poststack_3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_POSTSTACK_3D,exec_poststack_3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PSEUDO_DENSITY")) && !strncasecmp(ctool,"PSEUDO_DENSITY",len)) {
	PROTOCCALLSFSUB3(EXEC_PSEUDO_DENSITY,exec_pseudo_density,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSEUDO_DENSITY,exec_pseudo_density,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PSEUDO_SONIC")) && !strncasecmp(ctool,"PSEUDO_SONIC",len)) {
	PROTOCCALLSFSUB3(EXEC_PSEUDO_SONIC,exec_pseudo_sonic,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSEUDO_SONIC,exec_pseudo_sonic,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("PSI2DN")) && !strncasecmp(ctool,"PSI2DN",len)) {
	PROTOCCALLSFSUB3(EXEC_PSI2DN,exec_psi2dn,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSI2DN,exec_psi2dn,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PSI3D")) && !strncasecmp(ctool,"PSI3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PSI3D,exec_psi3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSI3D,exec_psi3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PSMIG3D")) && !strncasecmp(ctool,"PSMIG3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PSMIG3D,exec_psmig3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSMIG3D,exec_psmig3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_DMO3D")) && !strncasecmp(ctool,"PT_DMO3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_DMO3DG")) && !strncasecmp(ctool,"PT_DMO3DG",len)) {
	PROTOCCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FKMIG3D")) && !strncasecmp(ctool,"PT_FKMIG3D",len)) {
	PROTOCCALLSFSUB3(EXEC_FKMIG3D,exec_fkmig3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FKMIG3D,exec_fkmig3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FXY3DMIG")) && !strncasecmp(ctool,"PT_FXY3DMIG",len)) {
	PROTOCCALLSFSUB3(EXEC_PT_FXY3DMIG,exec_pt_fxy3dmig,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PT_FXY3DMIG,exec_pt_fxy3dmig,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FXYDECON")) && !strncasecmp(ctool,"PT_FXYDECON",len)) {
	PROTOCCALLSFSUB3(EXEC_FXYDECON,exec_fxydecon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_FXYDECON,exec_fxydecon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_MPFXY3DMIG")) && !strncasecmp(ctool,"PT_MPFXY3DMIG",len)) {
	PROTOCCALLSFSUB3(EXEC_PT_MPFXY3DMIG,exec_pt_mpfxy3dmig,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PT_MPFXY3DMIG,exec_pt_mpfxy3dmig,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_PSMIG3D")) && !strncasecmp(ctool,"PT_PSMIG3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PSMIG3D,exec_psmig3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PSMIG3D,exec_psmig3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_PXBEGEND")) && !strncasecmp(ctool,"PT_PXBEGEND",len)) {
	PROTOCCALLSFSUB3(EXEC_PXBEGEND,exec_pxbegend,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PXBEGEND,exec_pxbegend,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STACK3D")) && !strncasecmp(ctool,"PT_STACK3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STKMRG3D")) && !strncasecmp(ctool,"PT_STKMRG3D",len)) {
	PROTOCCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STOLT3D")) && !strncasecmp(ctool,"PT_STOLT3D",len)) {
	PROTOCCALLSFSUB3(EXEC_STOLT3D,exec_stolt3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STOLT3D,exec_stolt3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PVMTOOL")) && !strncasecmp(ctool,"PVMTOOL",len)) {
	PROTOCCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PVMTOOL,exec_pvmtool,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PXBEGEND")) && !strncasecmp(ctool,"PXBEGEND",len)) {
	PROTOCCALLSFSUB3(EXEC_PXBEGEND,exec_pxbegend,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PXBEGEND,exec_pxbegend,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PXIN")) && !strncasecmp(ctool,"PXIN",len)) {
	PROTOCCALLSFSUB3(EXEC_PXIN,exec_pxin,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PXIN,exec_pxin,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PXOUT")) && !strncasecmp(ctool,"PXOUT",len)) {
	PROTOCCALLSFSUB3(EXEC_PXOUT,exec_pxout,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PXOUT,exec_pxout,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("RADON_FILTER")) && !strncasecmp(ctool,"RADON_FILTER",len)) {
	PROTOCCALLSFSUB3(EXEC_RADON_FILTER,exec_radon_filter,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RADON_FILTER,exec_radon_filter,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("RADON_TRANS")) && !strncasecmp(ctool,"RADON_TRANS",len)) {
	PROTOCCALLSFSUB3(EXEC_RADON_TRANS,exec_radon_trans,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RADON_TRANS,exec_radon_trans,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("REFL_LOG")) && !strncasecmp(ctool,"REFL_LOG",len)) {
	PROTOCCALLSFSUB3(EXEC_REFL_LOG,exec_refl_log,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_REFL_LOG,exec_refl_log,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("REPEAT")) && !strncasecmp(ctool,"REPEAT",len)) {
	PROTOCCALLSFSUB3(EXEC_REPEAT,exec_repeat,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_REPEAT,exec_repeat,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("RGEOM")) && !strncasecmp(ctool,"RGEOM",len)) {
	PROTOCCALLSFSUB3(EXEC_RGEOM,exec_rgeom,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RGEOM,exec_rgeom,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("RMPAD_TRACES")) && !strncasecmp(ctool,"RMPAD_TRACES",len)) {
	PROTOCCALLSFSUB3(EXEC_RMPAD_TRACES,exec_rmpad_traces,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RMPAD_TRACES,exec_rmpad_traces,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ROLL_CHECK")) && !strncasecmp(ctool,"ROLL_CHECK",len)) {
	PROTOCCALLSFSUB3(EXEC_ROLL_CHECK,exec_roll_check,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_ROLL_CHECK,exec_roll_check,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("RSTACK")) && !strncasecmp(ctool,"RSTACK",len)) {
	PROTOCCALLSFSUB3(EXEC_RSTACK,exec_rstack,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_RSTACK,exec_rstack,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP2")) && !strncasecmp(ctool,"SCAMP2",len)) {
	PROTOCCALLSFSUB3(EXEC_SCAMP2,exec_scamp2,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCAMP2,exec_scamp2,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP3")) && !strncasecmp(ctool,"SCAMP3",len)) {
	PROTOCCALLSFSUB3(EXEC_SCAMP3,exec_scamp3,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCAMP3,exec_scamp3,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECON")) && !strncasecmp(ctool,"SCDECON",len)) {
	PROTOCCALLSFSUB3(EXEC_SCDECON,exec_scdecon,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCDECON,exec_scdecon,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECON2")) && !strncasecmp(ctool,"SCDECON2",len)) {
	PROTOCCALLSFSUB3(EXEC_SCDECON2,exec_scdecon2,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SCDECON2,exec_scdecon2,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SC_AMP")) && !strncasecmp(ctool,"SC_AMP",len)) {
	PROTOCCALLSFSUB3(EXEC_SC_AMP,exec_sc_amp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SC_AMP,exec_sc_amp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SC_AMP1")) && !strncasecmp(ctool,"SC_AMP1",len)) {
	PROTOCCALLSFSUB3(EXEC_SC_AMP1,exec_sc_amp1,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SC_AMP1,exec_sc_amp1,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SEG_READ")) && !strncasecmp(ctool,"SEG_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_SEG_READ,exec_seg_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SEG_READ,exec_seg_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SHOT_CHECK")) && !strncasecmp(ctool,"SHOT_CHECK",len)) {
	PROTOCCALLSFSUB3(EXEC_SHOT_CHECK,exec_shot_check,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SHOT_CHECK,exec_shot_check,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SOCKET_TOOL")) && !strncasecmp(ctool,"SOCKET_TOOL",len)) {
	PROTOCCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SORTMERGE")) && !strncasecmp(ctool,"SORTMERGE",len)) {
	PROTOCCALLSFSUB3(EXEC_SORTMERGE,exec_sortmerge,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SORTMERGE,exec_sortmerge,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SPECT")) && !strncasecmp(ctool,"SPECT",len)) {
	PROTOCCALLSFSUB3(EXEC_SPECT,exec_spect,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SPECT,exec_spect,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SPIK2MED")) && !strncasecmp(ctool,"SPIK2MED",len)) {
	PROTOCCALLSFSUB3(EXEC_SPIK2MED,exec_spik2med,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SPIK2MED,exec_spik2med,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SSAA")) && !strncasecmp(ctool,"SSAA",len)) {
	PROTOCCALLSFSUB3(EXEC_SSAA,exec_ssaa,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SSAA,exec_ssaa,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("STACK")) && !strncasecmp(ctool,"STACK",len)) {
	PROTOCCALLSFSUB3(EXEC_STACK,exec_stack,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STACK,exec_stack,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("STAND_ALONE")) && !strncasecmp(ctool,"STAND_ALONE",len)) {
	PROTOCCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("STOLT3D")) && !strncasecmp(ctool,"STOLT3D",len)) {
	PROTOCCALLSFSUB3(EXEC_STOLT3D,exec_stolt3d,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STOLT3D,exec_stolt3d,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("ST_DMOMOD")) && !strncasecmp(ctool,"ST_DMOMOD",len)) {
	PROTOCCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SWEEP")) && !strncasecmp(ctool,"SWEEP",len)) {
	PROTOCCALLSFSUB3(EXEC_SWEEP,exec_sweep,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SWEEP,exec_sweep,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SWOPT")) && !strncasecmp(ctool,"SWOPT",len)) {
	PROTOCCALLSFSUB3(EXEC_SWOPT,exec_swopt,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SWOPT,exec_swopt,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("SYNTH")) && !strncasecmp(ctool,"SYNTH",len)) {
	PROTOCCALLSFSUB3(EXEC_SYNTH,exec_synth,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SYNTH,exec_synth,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SYN_CDP")) && !strncasecmp(ctool,"SYN_CDP",len)) {
	PROTOCCALLSFSUB3(EXEC_SYN_CDP,exec_syn_cdp,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SYN_CDP,exec_syn_cdp,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("TAPEREAD")) && !strncasecmp(ctool,"TAPEREAD",len)) {
	PROTOCCALLSFSUB3(EXEC_TAPEREAD,exec_taperead,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TAPEREAD,exec_taperead,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAPEREAD2")) && !strncasecmp(ctool,"TAPEREAD2",len)) {
	PROTOCCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAPE_INSERT")) && !strncasecmp(ctool,"TAPE_INSERT",len)) {
	PROTOCCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROMAX_READ,exec_promax_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAUP")) && !strncasecmp(ctool,"TAUP",len)) {
	PROTOCCALLSFSUB3(EXEC_TAUP,exec_taup,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TAUP,exec_taup,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TAUPIN")) && !strncasecmp(ctool,"TAUPIN",len)) {
	PROTOCCALLSFSUB3(EXEC_TAUPIN,exec_taupin,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TAUPIN,exec_taupin,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("TIME_LOG")) && !strncasecmp(ctool,"TIME_LOG",len)) {
	PROTOCCALLSFSUB3(EXEC_TIME_LOG,exec_time_log,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TIME_LOG,exec_time_log,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("TIME_SLICE")) && !strncasecmp(ctool,"TIME_SLICE",len)) {
	PROTOCCALLSFSUB3(EXEC_TIME_SLICE,exec_time_slice,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TIME_SLICE,exec_time_slice,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TRACEMATH")) && !strncasecmp(ctool,"TRACEMATH",len)) {
	PROTOCCALLSFSUB3(EXEC_TRACEMATH,exec_tracemath,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TRACEMATH,exec_tracemath,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TR_DISPLAY")) && !strncasecmp(ctool,"TR_DISPLAY",len)) {
	PROTOCCALLSFSUB3(EXEC_TR_DISPLAY,exec_tr_display,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TR_DISPLAY,exec_tr_display,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TR_SPLICE")) && !strncasecmp(ctool,"TR_SPLICE",len)) {
	PROTOCCALLSFSUB3(EXEC_TR_SPLICE,exec_tr_splice,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TR_SPLICE,exec_tr_splice,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TR_UNSPLICE")) && !strncasecmp(ctool,"TR_UNSPLICE",len)) {
	PROTOCCALLSFSUB3(EXEC_TR_UNSPLICE,exec_tr_unsplice,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TR_UNSPLICE,exec_tr_unsplice,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("TVG")) && !strncasecmp(ctool,"TVG",len)) {
	PROTOCCALLSFSUB3(EXEC_TVG,exec_tvg,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_TVG,exec_tvg,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("T_AND_B")) && !strncasecmp(ctool,"T_AND_B",len)) {
	PROTOCCALLSFSUB3(EXEC_T_AND_B,exec_t_and_b,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_T_AND_B,exec_t_and_b,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("T_TRANSFER")) && !strncasecmp(ctool,"T_TRANSFER",len)) {
	PROTOCCALLSFSUB3(EXEC_T_TRANSFER,exec_t_transfer,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_T_TRANSFER,exec_t_transfer,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("USP_PROGRAM")) && !strncasecmp(ctool,"USP_PROGRAM",len)) {
	PROTOCCALLSFSUB3(EXEC_USP_PROGRAM,exec_usp_program,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_USP_PROGRAM,exec_usp_program,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WAV_EXT1")) && !strncasecmp(ctool,"WAV_EXT1",len)) {
	PROTOCCALLSFSUB3(EXEC_WAV_EXT1,exec_wav_ext1,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WAV_EXT1,exec_wav_ext1,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WIN_ALIN")) && !strncasecmp(ctool,"WIN_ALIN",len)) {
	PROTOCCALLSFSUB3(EXEC_WIN_ALIN,exec_win_alin,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WIN_ALIN,exec_win_alin,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WP_AVE")) && !strncasecmp(ctool,"WP_AVE",len)) {
	PROTOCCALLSFSUB3(EXEC_WP_AVE,exec_wp_ave,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WP_AVE,exec_wp_ave,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("WP_WAV")) && !strncasecmp(ctool,"WP_WAV",len)) {
	PROTOCCALLSFSUB3(EXEC_WP_WAV,exec_wp_wav,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_WP_WAV,exec_wp_wav,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("W_ITRSELT")) && !strncasecmp(ctool,"W_ITRSELT",len)) {
	PROTOCCALLSFSUB3(EXEC_W_ITRSELT,exec_w_itrselt,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_W_ITRSELT,exec_w_itrselt,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("MASWEMR")) && !strncasecmp(ctool,"MASWEMR",len)) {
	PROTOCCALLSFSUB3(EXEC_MASWEMR,exec_maswemr,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_MASWEMR,exec_maswemr,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("PROWESS_STUB")) && !strncasecmp(ctool,"PROWESS_STUB",len)) {
	PROTOCCALLSFSUB3(EXEC_PROWESS_STUB,exec_prowess_stub,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_PROWESS_STUB,exec_prowess_stub,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SPLITZERO")) && !strncasecmp(ctool,"SPLITZERO",len)) {
	PROTOCCALLSFSUB3(EXEC_SPLITZERO,exec_splitzero,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SPLITZERO,exec_splitzero,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else if ((((size_t) len+1) == sizeof("SSP_READ")) && !strncasecmp(ctool,"SSP_READ",len)) {
	PROTOCCALLSFSUB3(EXEC_SSP_READ,exec_ssp_read,PFLOAT,PINT,PINT)
	CCALLSFSUB3(EXEC_SSP_READ,exec_ssp_read,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
/* RCS:   ProMAX $Id: cmplxcall.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else if (!strncmp(ctool,"ST_",3)) {
        PROTOCCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT)
        CCALLSFSUB3(EXEC_STAND_ALONE_MODULE,exec_stand_alone_module,PFLOAT,PINT,PINT,trace[0],ithdr[0],ithdr[0]);
    } else {
	ex_err_fatal_("tool not recognized in complex_toolcall", 40);
    }
}

/* RCS: ProMAX $Id: tcalli.hdr 37030 2005-05-20 21:48:46Z salevin $ $Revision: 37030 $ $Date: 2005-05-20 15:48:46 -0600 (Fri, 20 May 2005) $ */
#include <cpromaxf.h>
/*******************************************************************************
 *       init_toolcall
 *******************************************************************************
 *
 *       description:
 *               calls the initialization phase of a tool
 *
 *       input arguments:
 *               ctool   - the name of the tool that needs to be called
 *
 *       output arguments:
 *               len_sav - the length of the list of saved parameters (words)
 *               itype   - the tool type (see global.inc)
 *
 *       original code by d.e. diller, may 11, 1989
 *
 ******************************************************************************/

void init_toolcall( char *ctool, int *len_sav, int *itype );

FCALLSCSUB3(init_toolcall,INIT_TOOLCALL,init_toolcall,STRING,PINT,PINT)

void init_toolcall( char *ctool, int *len_sav, int *itype ) 
{
   /* ignore trailing whitespace that Fortran is passing around */
    int len = (int) strcspn(ctool," \t");

    if (0) {
    } else if ((((size_t) len+1) == sizeof("SUREAD")) && !strncasecmp(ctool,"SUREAD",len)) { 
        PROTOCCALLSFSUB2(INIT_SUREAD,init_suread,PINT,PINT)
        CCALLSFSUB2(INIT_SUREAD,init_suread,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SUWRITE")) && !strncasecmp(ctool,"SUWRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_SUWRITE,init_suwrite,PINT,PINT)
        CCALLSFSUB2(INIT_SUWRITE,init_suwrite,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("END_SPLIT")) && !strncasecmp(ctool,"END_SPLIT",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_ENDIF,init_flow_endif,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_ENDIF,init_flow_endif,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_ELSE")) && !strncasecmp(ctool,"FLOW_ELSE",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_ELSE,init_flow_else,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_ELSE,init_flow_else,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_ELSEIF")) && !strncasecmp(ctool,"FLOW_ELSEIF",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_ELSEIF,init_flow_elseif,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_ELSEIF,init_flow_elseif,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_ENDIF")) && !strncasecmp(ctool,"FLOW_ENDIF",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_ENDIF,init_flow_endif,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_ENDIF,init_flow_endif,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_IF")) && !strncasecmp(ctool,"FLOW_IF",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_IF,init_flow_if,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_IF,init_flow_if,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_STOP")) && !strncasecmp(ctool,"FLOW_STOP",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_STOP,init_flow_stop,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_STOP,init_flow_stop,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPLIT")) && !strncasecmp(ctool,"SPLIT",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_IF,init_flow_if,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_IF,init_flow_if,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ADD_NOISE")) && !strncasecmp(ctool,"ADD_NOISE",len)) { 
        PROTOCCALLSFSUB2(INIT_ADD_NOISE,init_add_noise,PINT,PINT)
        CCALLSFSUB2(INIT_ADD_NOISE,init_add_noise,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ARRAY_COMP")) && !strncasecmp(ctool,"ARRAY_COMP",len)) { 
        PROTOCCALLSFSUB2(INIT_ARRAY_COMP,init_array_comp,PINT,PINT)
        CCALLSFSUB2(INIT_ARRAY_COMP,init_array_comp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ASCII_ATTR_OUT")) && !strncasecmp(ctool,"ASCII_ATTR_OUT",len)) { 
        PROTOCCALLSFSUB2(INIT_ASCII_ATTR_OUT,init_ascii_attr_out,PINT,PINT)
        CCALLSFSUB2(INIT_ASCII_ATTR_OUT,init_ascii_attr_out,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AVO_GATHER")) && !strncasecmp(ctool,"AVO_GATHER",len)) { 
        PROTOCCALLSFSUB2(INIT_AVO_GATHER,init_avo_gather,PINT,PINT)
        CCALLSFSUB2(INIT_AVO_GATHER,init_avo_gather,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("A_CN3D")) && !strncasecmp(ctool,"A_CN3D",len)) { 
        PROTOCCALLSFSUB2(INIT_A_CN3D,init_a_cn3d,PINT,PINT)
        CCALLSFSUB2(INIT_A_CN3D,init_a_cn3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("A_FF3D")) && !strncasecmp(ctool,"A_FF3D",len)) { 
        PROTOCCALLSFSUB2(INIT_A_FF3D,init_a_ff3d,PINT,PINT)
        CCALLSFSUB2(INIT_A_FF3D,init_a_ff3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("COH_FILT")) && !strncasecmp(ctool,"COH_FILT",len)) { 
        PROTOCCALLSFSUB2(INIT_COH_FILT,init_coh_filt,PINT,PINT)
        CCALLSFSUB2(INIT_COH_FILT,init_coh_filt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DEBUG1")) && !strncasecmp(ctool,"DEBUG1",len)) { 
        PROTOCCALLSFSUB2(INIT_DEBUG1,init_debug1,PINT,PINT)
        CCALLSFSUB2(INIT_DEBUG1,init_debug1,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DESIG")) && !strncasecmp(ctool,"DESIG",len)) { 
        PROTOCCALLSFSUB2(INIT_DESIG,init_desig,PINT,PINT)
        CCALLSFSUB2(INIT_DESIG,init_desig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DIPVELS")) && !strncasecmp(ctool,"DIPVELS",len)) { 
        PROTOCCALLSFSUB2(INIT_DIPVELS,init_dipvels,PINT,PINT)
        CCALLSFSUB2(INIT_DIPVELS,init_dipvels,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOFK_PANEL")) && !strncasecmp(ctool,"DMOFK_PANEL",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOFK_PANEL,init_dmofk_panel,PINT,PINT)
        CCALLSFSUB2(INIT_DMOFK_PANEL,init_dmofk_panel,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOTX_PANEL")) && !strncasecmp(ctool,"DMOTX_PANEL",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOTX_PANEL,init_dmotx_panel,PINT,PINT)
        CCALLSFSUB2(INIT_DMOTX_PANEL,init_dmotx_panel,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EDITAPPLY")) && !strncasecmp(ctool,"EDITAPPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_EDITAPPLY,init_editapply,PINT,PINT)
        CCALLSFSUB2(INIT_EDITAPPLY,init_editapply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EDITTRAIN")) && !strncasecmp(ctool,"EDITTRAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_EDITTRAIN,init_edittrain,PINT,PINT)
        CCALLSFSUB2(INIT_EDITTRAIN,init_edittrain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EIGFILT")) && !strncasecmp(ctool,"EIGFILT",len)) { 
        PROTOCCALLSFSUB2(INIT_EIGFILT,init_eigfilt,PINT,PINT)
        CCALLSFSUB2(INIT_EIGFILT,init_eigfilt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_BALANCE")) && !strncasecmp(ctool,"ENS_BALANCE",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_BALANCE,init_ens_balance,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_BALANCE,init_ens_balance,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_DECON")) && !strncasecmp(ctool,"ENS_DECON",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_DECON,init_ens_decon,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_DECON,init_ens_decon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_SLICE")) && !strncasecmp(ctool,"ENS_SLICE",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_SLICE,init_ens_slice,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_SLICE,init_ens_slice,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_VALUE")) && !strncasecmp(ctool,"ENS_VALUE",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_VALUE,init_ens_value,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_VALUE,init_ens_value,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESSD_DEPHASE")) && !strncasecmp(ctool,"ESSD_DEPHASE",len)) { 
        PROTOCCALLSFSUB2(INIT_ESSD_DEPHASE,init_essd_dephase,PINT,PINT)
        CCALLSFSUB2(INIT_ESSD_DEPHASE,init_essd_dephase,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FBAPPLY")) && !strncasecmp(ctool,"FBAPPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_FBAPPLY,init_fbapply,PINT,PINT)
        CCALLSFSUB2(INIT_FBAPPLY,init_fbapply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FBTRAIN")) && !strncasecmp(ctool,"FBTRAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_FBTRAIN,init_fbtrain,PINT,PINT)
        CCALLSFSUB2(INIT_FBTRAIN,init_fbtrain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FB_PREDICT")) && !strncasecmp(ctool,"FB_PREDICT",len)) { 
        PROTOCCALLSFSUB2(INIT_FB_PREDICT,init_fb_predict,PINT,PINT)
        CCALLSFSUB2(INIT_FB_PREDICT,init_fb_predict,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FILT_2D")) && !strncasecmp(ctool,"FILT_2D",len)) { 
        PROTOCCALLSFSUB2(INIT_FILT_2D,init_filt_2d,PINT,PINT)
        CCALLSFSUB2(INIT_FILT_2D,init_filt_2d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FKFILT")) && !strncasecmp(ctool,"FKFILT",len)) { 
        PROTOCCALLSFSUB2(INIT_FKFILT,init_fkfilt,PINT,PINT)
        CCALLSFSUB2(INIT_FKFILT,init_fkfilt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FK_FILT")) && !strncasecmp(ctool,"FK_FILT",len)) { 
        PROTOCCALLSFSUB2(INIT_FK_FILT,init_fk_filt,PINT,PINT)
        CCALLSFSUB2(INIT_FK_FILT,init_fk_filt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FXDECON")) && !strncasecmp(ctool,"FXDECON",len)) { 
        PROTOCCALLSFSUB2(INIT_FXDECON,init_fxdecon,PINT,PINT)
        CCALLSFSUB2(INIT_FXDECON,init_fxdecon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("IMP2F2")) && !strncasecmp(ctool,"IMP2F2",len)) { 
        PROTOCCALLSFSUB2(INIT_IMP2F2,init_imp2f2,PINT,PINT)
        CCALLSFSUB2(INIT_IMP2F2,init_imp2f2,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("KLT_CANCL")) && !strncasecmp(ctool,"KLT_CANCL",len)) { 
        PROTOCCALLSFSUB2(INIT_KLT_CANCL,init_klt_cancl,PINT,PINT)
        CCALLSFSUB2(INIT_KLT_CANCL,init_klt_cancl,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("LFAF")) && !strncasecmp(ctool,"LFAF",len)) { 
        PROTOCCALLSFSUB2(INIT_LFAF,init_lfaf,PINT,PINT)
        CCALLSFSUB2(INIT_LFAF,init_lfaf,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MB_TRANS")) && !strncasecmp(ctool,"MB_TRANS",len)) { 
        PROTOCCALLSFSUB2(INIT_MB_TRANS,init_mb_trans,PINT,PINT)
        CCALLSFSUB2(INIT_MB_TRANS,init_mb_trans,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTK_PANEL")) && !strncasecmp(ctool,"MIGTK_PANEL",len)) { 
        PROTOCCALLSFSUB2(INIT_MIGTK_PANEL,init_migtk_panel,PINT,PINT)
        CCALLSFSUB2(INIT_MIGTK_PANEL,init_migtk_panel,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NAFLTR")) && !strncasecmp(ctool,"NAFLTR",len)) { 
        PROTOCCALLSFSUB2(INIT_NAFLTR,init_nafltr,PINT,PINT)
        CCALLSFSUB2(INIT_NAFLTR,init_nafltr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NEWSTOLT")) && !strncasecmp(ctool,"NEWSTOLT",len)) { 
        PROTOCCALLSFSUB2(INIT_NEWSTOLT,init_newstolt,PINT,PINT)
        CCALLSFSUB2(INIT_NEWSTOLT,init_newstolt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NMO_INFILL")) && !strncasecmp(ctool,"NMO_INFILL",len)) { 
        PROTOCCALLSFSUB2(INIT_NMO_INFILL,init_nmo_infill,PINT,PINT)
        CCALLSFSUB2(INIT_NMO_INFILL,init_nmo_infill,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NNHPTRAIN")) && !strncasecmp(ctool,"NNHPTRAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_NNHPTRAIN,init_nnhptrain,PINT,PINT)
        CCALLSFSUB2(INIT_NNHPTRAIN,init_nnhptrain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NOISE_EDIT")) && !strncasecmp(ctool,"NOISE_EDIT",len)) { 
        PROTOCCALLSFSUB2(INIT_NOISE_EDIT,init_noise_edit,PINT,PINT)
        CCALLSFSUB2(INIT_NOISE_EDIT,init_noise_edit,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PHASE")) && !strncasecmp(ctool,"PHASE",len)) { 
        PROTOCCALLSFSUB2(INIT_PHASE,init_phase,PINT,PINT)
        CCALLSFSUB2(INIT_PHASE,init_phase,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PRECOM70")) && !strncasecmp(ctool,"PRECOM70",len)) { 
        PROTOCCALLSFSUB2(INIT_PRECOM70,init_precom70,PINT,PINT)
        CCALLSFSUB2(INIT_PRECOM70,init_precom70,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("PSMIG")) && !strncasecmp(ctool,"PSMIG",len)) { 
        PROTOCCALLSFSUB2(INIT_PSMIG,init_psmig,PINT,PINT)
        CCALLSFSUB2(INIT_PSMIG,init_psmig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("REVAPPLY")) && !strncasecmp(ctool,"REVAPPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_REVAPPLY,init_revapply,PINT,PINT)
        CCALLSFSUB2(INIT_REVAPPLY,init_revapply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("REVTRAIN")) && !strncasecmp(ctool,"REVTRAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_REVTRAIN,init_revtrain,PINT,PINT)
        CCALLSFSUB2(INIT_REVTRAIN,init_revtrain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SG_CDP")) && !strncasecmp(ctool,"SG_CDP",len)) { 
        PROTOCCALLSFSUB2(INIT_SG_CDP,init_sg_cdp,PINT,PINT)
        CCALLSFSUB2(INIT_SG_CDP,init_sg_cdp,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SUPER2D")) && !strncasecmp(ctool,"SUPER2D",len)) { 
        PROTOCCALLSFSUB2(INIT_SUPER2D,init_super2d,PINT,PINT)
        CCALLSFSUB2(INIT_SUPER2D,init_super2d,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SUPER3D")) && !strncasecmp(ctool,"SUPER3D",len)) { 
        PROTOCCALLSFSUB2(INIT_SUPER3D,init_super3d,PINT,PINT)
        CCALLSFSUB2(INIT_SUPER3D,init_super3d,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("TX_SWTGAIN")) && !strncasecmp(ctool,"TX_SWTGAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_TX_SWTGAIN,init_tx_swtgain,PINT,PINT)
        CCALLSFSUB2(INIT_TX_SWTGAIN,init_tx_swtgain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("VABATCH")) && !strncasecmp(ctool,"VABATCH",len)) { 
        PROTOCCALLSFSUB2(INIT_VABATCH,init_vabatch,PINT,PINT)
        CCALLSFSUB2(INIT_VABATCH,init_vabatch,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VAPRECOM")) && !strncasecmp(ctool,"VAPRECOM",len)) { 
        PROTOCCALLSFSUB2(INIT_VAPRECOM,init_vaprecom,PINT,PINT)
        CCALLSFSUB2(INIT_VAPRECOM,init_vaprecom,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("VSPCDP")) && !strncasecmp(ctool,"VSPCDP",len)) { 
        PROTOCCALLSFSUB2(INIT_VSPCDP,init_vspcdp,PINT,PINT)
        CCALLSFSUB2(INIT_VSPCDP,init_vspcdp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WEMR")) && !strncasecmp(ctool,"WEMR",len)) { 
        PROTOCCALLSFSUB2(INIT_WEMR,init_wemr,PINT,PINT)
        CCALLSFSUB2(INIT_WEMR,init_wemr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("COMPARE")) && !strncasecmp(ctool,"COMPARE",len)) { 
        PROTOCCALLSFSUB2(INIT_COMPARE,init_compare,PINT,PINT)
        CCALLSFSUB2(INIT_COMPARE,init_compare,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("LEVEL_STATS")) && !strncasecmp(ctool,"LEVEL_STATS",len)) { 
        PROTOCCALLSFSUB2(INIT_LEVEL_STATS,init_level_stats,PINT,PINT)
        CCALLSFSUB2(INIT_LEVEL_STATS,init_level_stats,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ORNT_COMP")) && !strncasecmp(ctool,"ORNT_COMP",len)) { 
        PROTOCCALLSFSUB2(INIT_ORNT_COMP,init_ornt_comp,PINT,PINT)
        CCALLSFSUB2(INIT_ORNT_COMP,init_ornt_comp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PART_MOTION")) && !strncasecmp(ctool,"PART_MOTION",len)) { 
        PROTOCCALLSFSUB2(INIT_PART_MOTION,init_part_motion,PINT,PINT)
        CCALLSFSUB2(INIT_PART_MOTION,init_part_motion,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("POPSTAK")) && !strncasecmp(ctool,"POPSTAK",len)) { 
        PROTOCCALLSFSUB2(INIT_POPSTAK,init_popstak,PINT,PINT)
        CCALLSFSUB2(INIT_POPSTAK,init_popstak,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RE_ORNT")) && !strncasecmp(ctool,"RE_ORNT",len)) { 
        PROTOCCALLSFSUB2(INIT_RE_ORNT,init_re_ornt,PINT,PINT)
        CCALLSFSUB2(INIT_RE_ORNT,init_re_ornt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SEMBLANCE")) && !strncasecmp(ctool,"SEMBLANCE",len)) { 
        PROTOCCALLSFSUB2(INIT_SEMBLANCE,init_semblance,PINT,PINT)
        CCALLSFSUB2(INIT_SEMBLANCE,init_semblance,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPLC_DSET")) && !strncasecmp(ctool,"SPLC_DSET",len)) { 
        PROTOCCALLSFSUB2(INIT_SPLC_DSET,init_splc_dset,PINT,PINT)
        CCALLSFSUB2(INIT_SPLC_DSET,init_splc_dset,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRANS_3C")) && !strncasecmp(ctool,"TRANS_3C",len)) { 
        PROTOCCALLSFSUB2(INIT_TRANS_3C,init_trans_3c,PINT,PINT)
        CCALLSFSUB2(INIT_TRANS_3C,init_trans_3c,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_INTERP")) && !strncasecmp(ctool,"TRC_INTERP",len)) { 
        PROTOCCALLSFSUB2(INIT_TRC_INTERP,init_trc_interp,PINT,PINT)
        CCALLSFSUB2(INIT_TRC_INTERP,init_trc_interp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("COMPARE")) && !strncasecmp(ctool,"COMPARE",len)) { 
        PROTOCCALLSFSUB2(INIT_COMPARE,init_compare,PINT,PINT)
        CCALLSFSUB2(INIT_COMPARE,init_compare,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("LEVEL_STATS")) && !strncasecmp(ctool,"LEVEL_STATS",len)) { 
        PROTOCCALLSFSUB2(INIT_LEVEL_STATS,init_level_stats,PINT,PINT)
        CCALLSFSUB2(INIT_LEVEL_STATS,init_level_stats,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ORNT_COMP")) && !strncasecmp(ctool,"ORNT_COMP",len)) { 
        PROTOCCALLSFSUB2(INIT_ORNT_COMP,init_ornt_comp,PINT,PINT)
        CCALLSFSUB2(INIT_ORNT_COMP,init_ornt_comp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PART_MOTION")) && !strncasecmp(ctool,"PART_MOTION",len)) { 
        PROTOCCALLSFSUB2(INIT_PART_MOTION,init_part_motion,PINT,PINT)
        CCALLSFSUB2(INIT_PART_MOTION,init_part_motion,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("POPSTAK")) && !strncasecmp(ctool,"POPSTAK",len)) { 
        PROTOCCALLSFSUB2(INIT_POPSTAK,init_popstak,PINT,PINT)
        CCALLSFSUB2(INIT_POPSTAK,init_popstak,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RE_ORNT")) && !strncasecmp(ctool,"RE_ORNT",len)) { 
        PROTOCCALLSFSUB2(INIT_RE_ORNT,init_re_ornt,PINT,PINT)
        CCALLSFSUB2(INIT_RE_ORNT,init_re_ornt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRANS_3C")) && !strncasecmp(ctool,"TRANS_3C",len)) { 
        PROTOCCALLSFSUB2(INIT_TRANS_3C,init_trans_3c,PINT,PINT)
        CCALLSFSUB2(INIT_TRANS_3C,init_trans_3c,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SEMBLANCE")) && !strncasecmp(ctool,"SEMBLANCE",len)) { 
        PROTOCCALLSFSUB2(INIT_SEMBLANCE,init_semblance,PINT,PINT)
        CCALLSFSUB2(INIT_SEMBLANCE,init_semblance,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPLC_DSET")) && !strncasecmp(ctool,"SPLC_DSET",len)) { 
        PROTOCCALLSFSUB2(INIT_SPLC_DSET,init_splc_dset,PINT,PINT)
        CCALLSFSUB2(INIT_SPLC_DSET,init_splc_dset,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_INTERP")) && !strncasecmp(ctool,"TRC_INTERP",len)) { 
        PROTOCCALLSFSUB2(INIT_TRC_INTERP,init_trc_interp,PINT,PINT)
        CCALLSFSUB2(INIT_TRC_INTERP,init_trc_interp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ADAPT_DECON")) && !strncasecmp(ctool,"ADAPT_DECON",len)) { 
        PROTOCCALLSFSUB2(INIT_ADAPT_DECON,init_adapt_decon,PINT,PINT)
        CCALLSFSUB2(INIT_ADAPT_DECON,init_adapt_decon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AGC")) && !strncasecmp(ctool,"AGC",len)) { 
        PROTOCCALLSFSUB2(INIT_AGC,init_agc,PINT,PINT)
        CCALLSFSUB2(INIT_AGC,init_agc,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AIRBLAST")) && !strncasecmp(ctool,"AIRBLAST",len)) { 
        PROTOCCALLSFSUB2(INIT_AIRBLAST,init_airblast,PINT,PINT)
        CCALLSFSUB2(INIT_AIRBLAST,init_airblast,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AMPSCAN")) && !strncasecmp(ctool,"AMPSCAN",len)) { 
        PROTOCCALLSFSUB2(INIT_AMPSCAN,init_ampscan,PINT,PINT)
        CCALLSFSUB2(INIT_AMPSCAN,init_ampscan,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AMP_CLIP")) && !strncasecmp(ctool,"AMP_CLIP",len)) { 
        PROTOCCALLSFSUB2(INIT_AMP_CLIP,init_amp_clip,PINT,PINT)
        CCALLSFSUB2(INIT_AMP_CLIP,init_amp_clip,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ASCIISPREADSHEET")) && !strncasecmp(ctool,"ASCIISPREADSHEET",len)) { 
        PROTOCCALLSFSUB2(INIT_ASCIISPREADSHEET,init_asciispreadsheet,PINT,PINT)
        CCALLSFSUB2(INIT_ASCIISPREADSHEET,init_asciispreadsheet,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AUTO_CORR")) && !strncasecmp(ctool,"AUTO_CORR",len)) { 
        PROTOCCALLSFSUB2(INIT_AUTO_CORR,init_auto_corr,PINT,PINT)
        CCALLSFSUB2(INIT_AUTO_CORR,init_auto_corr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("BINNER")) && !strncasecmp(ctool,"BINNER",len)) { 
        PROTOCCALLSFSUB2(INIT_BINNER,init_binner,PINT,PINT)
        CCALLSFSUB2(INIT_BINNER,init_binner,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("BLEND_OPEN")) && !strncasecmp(ctool,"BLEND_OPEN",len)) { 
        PROTOCCALLSFSUB2(INIT_BLEND_OPEN,init_blend_open,PINT,PINT)
        CCALLSFSUB2(INIT_BLEND_OPEN,init_blend_open,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("CDP_TAPER")) && !strncasecmp(ctool,"CDP_TAPER",len)) { 
        PROTOCCALLSFSUB2(INIT_CDP_TAPER,init_cdp_taper,PINT,PINT)
        CCALLSFSUB2(INIT_CDP_TAPER,init_cdp_taper,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("CONVERT_MUTES")) && !strncasecmp(ctool,"CONVERT_MUTES",len)) { 
        PROTOCCALLSFSUB2(INIT_CONVERT_MUTES,init_convert_mutes,PINT,PINT)
        CCALLSFSUB2(INIT_CONVERT_MUTES,init_convert_mutes,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DATUM_STAT_APPLY")) && !strncasecmp(ctool,"DATUM_STAT_APPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_DATUM_STAT_APPLY,init_datum_stat_apply,PINT,PINT)
        CCALLSFSUB2(INIT_DATUM_STAT_APPLY,init_datum_stat_apply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DB_HDR_LOAD")) && !strncasecmp(ctool,"DB_HDR_LOAD",len)) { 
        PROTOCCALLSFSUB2(INIT_DB_HDR_LOAD,init_db_hdr_load,PINT,PINT)
        CCALLSFSUB2(INIT_DB_HDR_LOAD,init_db_hdr_load,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DEBIAS")) && !strncasecmp(ctool,"DEBIAS",len)) { 
        PROTOCCALLSFSUB2(INIT_DEBIAS,init_debias,PINT,PINT)
        CCALLSFSUB2(INIT_DEBIAS,init_debias,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DECON")) && !strncasecmp(ctool,"DECON",len)) { 
        PROTOCCALLSFSUB2(INIT_DECON,init_decon,PINT,PINT)
        CCALLSFSUB2(INIT_DECON,init_decon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DEITY")) && !strncasecmp(ctool,"DEITY",len)) { 
        PROTOCCALLSFSUB2(INIT_DEITY,init_deity,PINT,PINT)
        CCALLSFSUB2(INIT_DEITY,init_deity,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DEPTH")) && !strncasecmp(ctool,"DEPTH",len)) { 
        PROTOCCALLSFSUB2(INIT_DEPTH,init_depth,PINT,PINT)
        CCALLSFSUB2(INIT_DEPTH,init_depth,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DEPTH2")) && !strncasecmp(ctool,"DEPTH2",len)) { 
        PROTOCCALLSFSUB2(INIT_DEPTH2,init_depth2,PINT,PINT)
        CCALLSFSUB2(INIT_DEPTH2,init_depth2,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DISKWRITE")) && !strncasecmp(ctool,"DISKWRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_DISKWRITE,init_diskwrite,PINT,PINT)
        CCALLSFSUB2(INIT_DISKWRITE,init_diskwrite,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOBIN")) && !strncasecmp(ctool,"DMOBIN",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOBIN,init_dmobin,PINT,PINT)
        CCALLSFSUB2(INIT_DMOBIN,init_dmobin,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DS2ASCII")) && !strncasecmp(ctool,"DS2ASCII",len)) { 
        PROTOCCALLSFSUB2(INIT_DS2ASCII,init_ds2ascii,PINT,PINT)
        CCALLSFSUB2(INIT_DS2ASCII,init_ds2ascii,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ELEV_STAT")) && !strncasecmp(ctool,"ELEV_STAT",len)) { 
        PROTOCCALLSFSUB2(INIT_ELEV_STAT,init_elev_stat,PINT,PINT)
        CCALLSFSUB2(INIT_ELEV_STAT,init_elev_stat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_XC_SUM")) && !strncasecmp(ctool,"EMCA_XC_SUM",len)) { 
        PROTOCCALLSFSUB2(INIT_EMCA_XC_SUM,init_emca_xc_sum,PINT,PINT)
        CCALLSFSUB2(INIT_EMCA_XC_SUM,init_emca_xc_sum,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EM_XCOR")) && !strncasecmp(ctool,"EM_XCOR",len)) { 
        PROTOCCALLSFSUB2(INIT_EM_XCOR,init_em_xcor,PINT,PINT)
        CCALLSFSUB2(INIT_EM_XCOR,init_em_xcor,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EM_XCOR_STAT")) && !strncasecmp(ctool,"EM_XCOR_STAT",len)) { 
        PROTOCCALLSFSUB2(INIT_EM_XCOR_STAT,init_em_xcor_stat,PINT,PINT)
        CCALLSFSUB2(INIT_EM_XCOR_STAT,init_em_xcor_stat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENVN")) && !strncasecmp(ctool,"ENVN",len)) { 
        PROTOCCALLSFSUB2(INIT_ENVN,init_envn,PINT,PINT)
        CCALLSFSUB2(INIT_ENVN,init_envn,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_GAIN")) && !strncasecmp(ctool,"ESI_GAIN",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_GAIN,init_esi_gain,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_GAIN,init_esi_gain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_GAIN_CHECK")) && !strncasecmp(ctool,"ESI_GAIN_CHECK",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_GAIN,init_esi_gain,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_GAIN,init_esi_gain,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_WRITE")) && !strncasecmp(ctool,"ESI_WRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_WRITE,init_esi_write,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_WRITE,init_esi_write,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FBPICK")) && !strncasecmp(ctool,"FBPICK",len)) { 
        PROTOCCALLSFSUB2(INIT_FBPICK,init_fbpick,PINT,PINT)
        CCALLSFSUB2(INIT_FBPICK,init_fbpick,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FILTER")) && !strncasecmp(ctool,"FILTER",len)) { 
        PROTOCCALLSFSUB2(INIT_FILTER,init_filter,PINT,PINT)
        CCALLSFSUB2(INIT_FILTER,init_filter,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOW_COMMENT")) && !strncasecmp(ctool,"FLOW_COMMENT",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOW_COMMENT,init_flow_comment,PINT,PINT)
        CCALLSFSUB2(INIT_FLOW_COMMENT,init_flow_comment,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FRACSTAT")) && !strncasecmp(ctool,"FRACSTAT",len)) { 
        PROTOCCALLSFSUB2(INIT_FRACSTAT,init_fracstat,PINT,PINT)
        CCALLSFSUB2(INIT_FRACSTAT,init_fracstat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HANDSTAT")) && !strncasecmp(ctool,"HANDSTAT",len)) { 
        PROTOCCALLSFSUB2(INIT_HANDSTAT,init_handstat,PINT,PINT)
        CCALLSFSUB2(INIT_HANDSTAT,init_handstat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDR2HOR")) && !strncasecmp(ctool,"HDR2HOR",len)) { 
        PROTOCCALLSFSUB2(INIT_HDR2HOR,init_hdr2hor,PINT,PINT)
        CCALLSFSUB2(INIT_HDR2HOR,init_hdr2hor,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDR2KIL")) && !strncasecmp(ctool,"HDR2KIL",len)) { 
        PROTOCCALLSFSUB2(INIT_HDR2KIL,init_hdr2kil,PINT,PINT)
        CCALLSFSUB2(INIT_HDR2KIL,init_hdr2kil,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDRSTAT")) && !strncasecmp(ctool,"HDRSTAT",len)) { 
        PROTOCCALLSFSUB2(INIT_HDRSTAT,init_hdrstat,PINT,PINT)
        CCALLSFSUB2(INIT_HDRSTAT,init_hdrstat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDRWEIGHT")) && !strncasecmp(ctool,"HDRWEIGHT",len)) { 
        PROTOCCALLSFSUB2(INIT_HDRWEIGHT,init_hdrweight,PINT,PINT)
        CCALLSFSUB2(INIT_HDRWEIGHT,init_hdrweight,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDR_DELETE")) && !strncasecmp(ctool,"HDR_DELETE",len)) { 
        PROTOCCALLSFSUB2(INIT_HDR_DELETE,init_hdr_delete,PINT,PINT)
        CCALLSFSUB2(INIT_HDR_DELETE,init_hdr_delete,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HDR_RANGE")) && !strncasecmp(ctool,"HDR_RANGE",len)) { 
        PROTOCCALLSFSUB2(INIT_HDR_RANGE,init_hdr_range,PINT,PINT)
        CCALLSFSUB2(INIT_HDR_RANGE,init_hdr_range,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HEADER_RENUM")) && !strncasecmp(ctool,"HEADER_RENUM",len)) { 
        PROTOCCALLSFSUB2(INIT_HEADER_RENUM,init_header_renum,PINT,PINT)
        CCALLSFSUB2(INIT_HEADER_RENUM,init_header_renum,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HEADER_VALUES")) && !strncasecmp(ctool,"HEADER_VALUES",len)) { 
        PROTOCCALLSFSUB2(INIT_HEADER_VALUES,init_header_values,PINT,PINT)
        CCALLSFSUB2(INIT_HEADER_VALUES,init_header_values,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("HRZ_FLATTEN")) && !strncasecmp(ctool,"HRZ_FLATTEN",len)) { 
        PROTOCCALLSFSUB2(INIT_HRZ_FLATTEN,init_hrz_flatten,PINT,PINT)
        CCALLSFSUB2(INIT_HRZ_FLATTEN,init_hrz_flatten,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("IES_WRITE")) && !strncasecmp(ctool,"IES_WRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_IES_WRITE,init_ies_write,PINT,PINT)
        CCALLSFSUB2(INIT_IES_WRITE,init_ies_write,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("IMP")) && !strncasecmp(ctool,"IMP",len)) { 
        PROTOCCALLSFSUB2(INIT_IMP,init_imp,PINT,PINT)
        CCALLSFSUB2(INIT_IMP,init_imp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("INLINE_CDPBIN")) && !strncasecmp(ctool,"INLINE_CDPBIN",len)) { 
        PROTOCCALLSFSUB2(INIT_INLINE_CDPBIN,init_inline_cdpbin,PINT,PINT)
        CCALLSFSUB2(INIT_INLINE_CDPBIN,init_inline_cdpbin,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("INVERT")) && !strncasecmp(ctool,"INVERT",len)) { 
        PROTOCCALLSFSUB2(INIT_INVERT,init_invert,PINT,PINT)
        CCALLSFSUB2(INIT_INVERT,init_invert,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("JTOOL_TRC")) && !strncasecmp(ctool,"JTOOL_TRC",len)) { 
        PROTOCCALLSFSUB2(INIT_JTOOL_TRC,init_jtool_trc,PINT,PINT)
        CCALLSFSUB2(INIT_JTOOL_TRC,init_jtool_trc,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("LMO")) && !strncasecmp(ctool,"LMO",len)) { 
        PROTOCCALLSFSUB2(INIT_LMO,init_lmo,PINT,PINT)
        CCALLSFSUB2(INIT_LMO,init_lmo,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MON_SHIFT")) && !strncasecmp(ctool,"MON_SHIFT",len)) { 
        PROTOCCALLSFSUB2(INIT_MON_SHIFT,init_mon_shift,PINT,PINT)
        CCALLSFSUB2(INIT_MON_SHIFT,init_mon_shift,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MON_TBL_LOAD")) && !strncasecmp(ctool,"MON_TBL_LOAD",len)) { 
        PROTOCCALLSFSUB2(INIT_MON_TBL_LOAD,init_mon_tbl_load,PINT,PINT)
        CCALLSFSUB2(INIT_MON_TBL_LOAD,init_mon_tbl_load,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MUTE")) && !strncasecmp(ctool,"MUTE",len)) { 
        PROTOCCALLSFSUB2(INIT_MUTE,init_mute,PINT,PINT)
        CCALLSFSUB2(INIT_MUTE,init_mute,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NMO")) && !strncasecmp(ctool,"NMO",len)) { 
        PROTOCCALLSFSUB2(INIT_NMO,init_nmo,PINT,PINT)
        CCALLSFSUB2(INIT_NMO,init_nmo,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NOISE_MONITOR")) && !strncasecmp(ctool,"NOISE_MONITOR",len)) { 
        PROTOCCALLSFSUB2(INIT_NOISE_MONITOR,init_noise_monitor,PINT,PINT)
        CCALLSFSUB2(INIT_NOISE_MONITOR,init_noise_monitor,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("OPF_EXTRACT")) && !strncasecmp(ctool,"OPF_EXTRACT",len)) { 
        PROTOCCALLSFSUB2(INIT_OPF_EXTRACT,init_opf_extract,PINT,PINT)
        CCALLSFSUB2(INIT_OPF_EXTRACT,init_opf_extract,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PHFILTER")) && !strncasecmp(ctool,"PHFILTER",len)) { 
        PROTOCCALLSFSUB2(INIT_PHFILTER,init_phfilter,PINT,PINT)
        CCALLSFSUB2(INIT_PHFILTER,init_phfilter,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("QCOMP")) && !strncasecmp(ctool,"QCOMP",len)) { 
        PROTOCCALLSFSUB2(INIT_QCOMP,init_qcomp,PINT,PINT)
        CCALLSFSUB2(INIT_QCOMP,init_qcomp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("QPHS")) && !strncasecmp(ctool,"QPHS",len)) { 
        PROTOCCALLSFSUB2(INIT_QPHS,init_qphs,PINT,PINT)
        CCALLSFSUB2(INIT_QPHS,init_qphs,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("QSTL")) && !strncasecmp(ctool,"QSTL",len)) { 
        PROTOCCALLSFSUB2(INIT_QSTL,init_qstl,PINT,PINT)
        CCALLSFSUB2(INIT_QSTL,init_qstl,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("REFLSTAT3D")) && !strncasecmp(ctool,"REFLSTAT3D",len)) { 
        PROTOCCALLSFSUB2(INIT_REFLSTAT3D,init_reflstat3d,PINT,PINT)
        CCALLSFSUB2(INIT_REFLSTAT3D,init_reflstat3d,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("RESAMP")) && !strncasecmp(ctool,"RESAMP",len)) { 
        PROTOCCALLSFSUB2(INIT_RESAMP,init_resamp,PINT,PINT)
        CCALLSFSUB2(INIT_RESAMP,init_resamp,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("RESAMPLE_LOG")) && !strncasecmp(ctool,"RESAMPLE_LOG",len)) { 
        PROTOCCALLSFSUB2(INIT_RESAMPLE_LOG,init_resample_log,PINT,PINT)
        CCALLSFSUB2(INIT_RESAMPLE_LOG,init_resample_log,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("REVIVE_TRC")) && !strncasecmp(ctool,"REVIVE_TRC",len)) { 
        PROTOCCALLSFSUB2(INIT_REVIVE_TRC,init_revive_trc,PINT,PINT)
        CCALLSFSUB2(INIT_REVIVE_TRC,init_revive_trc,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ROTATE")) && !strncasecmp(ctool,"ROTATE",len)) { 
        PROTOCCALLSFSUB2(INIT_ROTATE,init_rotate,PINT,PINT)
        CCALLSFSUB2(INIT_ROTATE,init_rotate,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SAMPLE_VALUES")) && !strncasecmp(ctool,"SAMPLE_VALUES",len)) { 
        PROTOCCALLSFSUB2(INIT_SAMPLE_VALUES,init_sample_values,PINT,PINT)
        CCALLSFSUB2(INIT_SAMPLE_VALUES,init_sample_values,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP")) && !strncasecmp(ctool,"SCAMP",len)) { 
        PROTOCCALLSFSUB2(INIT_SCAMP,init_scamp,PINT,PINT)
        CCALLSFSUB2(INIT_SCAMP,init_scamp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECONM")) && !strncasecmp(ctool,"SCDECONM",len)) { 
        PROTOCCALLSFSUB2(INIT_SCDECONM,init_scdeconm,PINT,PINT)
        CCALLSFSUB2(INIT_SCDECONM,init_scdeconm,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SEGP1_LOAD")) && !strncasecmp(ctool,"SEGP1_LOAD",len)) { 
        PROTOCCALLSFSUB2(INIT_SEGP1_LOAD,init_segp1_load,PINT,PINT)
        CCALLSFSUB2(INIT_SEGP1_LOAD,init_segp1_load,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SEG_WRITE")) && !strncasecmp(ctool,"SEG_WRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_SEG_WRITE,init_seg_write,PINT,PINT)
        CCALLSFSUB2(INIT_SEG_WRITE,init_seg_write,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SLOC_ASSIGN")) && !strncasecmp(ctool,"SLOC_ASSIGN",len)) { 
        PROTOCCALLSFSUB2(INIT_SLOC_ASSIGN,init_sloc_assign,PINT,PINT)
        CCALLSFSUB2(INIT_SLOC_ASSIGN,init_sloc_assign,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SMPTOHDR")) && !strncasecmp(ctool,"SMPTOHDR",len)) { 
        PROTOCCALLSFSUB2(INIT_SMPTOHDR,init_smptohdr,PINT,PINT)
        CCALLSFSUB2(INIT_SMPTOHDR,init_smptohdr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPIKE")) && !strncasecmp(ctool,"SPIKE",len)) { 
        PROTOCCALLSFSUB2(INIT_SPIKE,init_spike,PINT,PINT)
        CCALLSFSUB2(INIT_SPIKE,init_spike,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SSD_DEPHASE")) && !strncasecmp(ctool,"SSD_DEPHASE",len)) { 
        PROTOCCALLSFSUB2(INIT_SSD_DEPHASE,init_ssd_dephase,PINT,PINT)
        CCALLSFSUB2(INIT_SSD_DEPHASE,init_ssd_dephase,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SYNLVXZ")) && !strncasecmp(ctool,"SYNLVXZ",len)) { 
        PROTOCCALLSFSUB2(INIT_SYNLVXZ,init_synlvxz,PINT,PINT)
        CCALLSFSUB2(INIT_SYNLVXZ,init_synlvxz,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAPEWRITE")) && !strncasecmp(ctool,"TAPEWRITE",len)) { 
        PROTOCCALLSFSUB2(INIT_TAPEWRITE,init_tapewrite,PINT,PINT)
        CCALLSFSUB2(INIT_TAPEWRITE,init_tapewrite,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAR")) && !strncasecmp(ctool,"TAR",len)) { 
        PROTOCCALLSFSUB2(INIT_TAR,init_tar,PINT,PINT)
        CCALLSFSUB2(INIT_TAR,init_tar,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TBL_HDR_LOAD")) && !strncasecmp(ctool,"TBL_HDR_LOAD",len)) { 
        PROTOCCALLSFSUB2(INIT_TBL_HDR_LOAD,init_tbl_hdr_load,PINT,PINT)
        CCALLSFSUB2(INIT_TBL_HDR_LOAD,init_tbl_hdr_load,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TE")) && !strncasecmp(ctool,"TE",len)) { 
        PROTOCCALLSFSUB2(INIT_TE,init_te,PINT,PINT)
        CCALLSFSUB2(INIT_TE,init_te,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TEQ")) && !strncasecmp(ctool,"TEQ",len)) { 
        PROTOCCALLSFSUB2(INIT_TEQ,init_teq,PINT,PINT)
        CCALLSFSUB2(INIT_TEQ,init_teq,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TEST_FAIL")) && !strncasecmp(ctool,"TEST_FAIL",len)) { 
        PROTOCCALLSFSUB2(INIT_TEST_FAIL,init_test_fail,PINT,PINT)
        CCALLSFSUB2(INIT_TEST_FAIL,init_test_fail,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("THDRMATH")) && !strncasecmp(ctool,"THDRMATH",len)) { 
        PROTOCCALLSFSUB2(INIT_THDRMATH,init_thdrmath,PINT,PINT)
        CCALLSFSUB2(INIT_THDRMATH,init_thdrmath,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("THRESH")) && !strncasecmp(ctool,"THRESH",len)) { 
        PROTOCCALLSFSUB2(INIT_THRESH,init_thresh,PINT,PINT)
        CCALLSFSUB2(INIT_THRESH,init_thresh,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_LEN")) && !strncasecmp(ctool,"TRACE_LEN",len)) { 
        PROTOCCALLSFSUB2(INIT_TRACE_LEN,init_trace_len,PINT,PINT)
        CCALLSFSUB2(INIT_TRACE_LEN,init_trace_len,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_STATS")) && !strncasecmp(ctool,"TRACE_STATS",len)) { 
        PROTOCCALLSFSUB2(INIT_TRACE_STATS,init_trace_stats,PINT,PINT)
        CCALLSFSUB2(INIT_TRACE_STATS,init_trace_stats,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRACE_STATS")) && !strncasecmp(ctool,"TRACE_STATS",len)) { 
        PROTOCCALLSFSUB2(INIT_TRACE_STATS,init_trace_stats,PINT,PINT)
        CCALLSFSUB2(INIT_TRACE_STATS,init_trace_stats,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRC_EDIT")) && !strncasecmp(ctool,"TRC_EDIT",len)) { 
        PROTOCCALLSFSUB2(INIT_TRC_EDIT,init_trc_edit,PINT,PINT)
        CCALLSFSUB2(INIT_TRC_EDIT,init_trc_edit,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TSMPMATH")) && !strncasecmp(ctool,"TSMPMATH",len)) { 
        PROTOCCALLSFSUB2(INIT_TSMPMATH,init_tsmpmath,PINT,PINT)
        CCALLSFSUB2(INIT_TSMPMATH,init_tsmpmath,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TT3HDMAP")) && !strncasecmp(ctool,"TT3HDMAP",len)) { 
        PROTOCCALLSFSUB2(INIT_TT3HDMAP,init_tt3hdmap,PINT,PINT)
        CCALLSFSUB2(INIT_TT3HDMAP,init_tt3hdmap,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TVS")) && !strncasecmp(ctool,"TVS",len)) { 
        PROTOCCALLSFSUB2(INIT_TVS,init_tvs,PINT,PINT)
        CCALLSFSUB2(INIT_TVS,init_tvs,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TVW")) && !strncasecmp(ctool,"TVW",len)) { 
        PROTOCCALLSFSUB2(INIT_TVW,init_tvw,PINT,PINT)
        CCALLSFSUB2(INIT_TVW,init_tvw,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("UPHOLE_CORR")) && !strncasecmp(ctool,"UPHOLE_CORR",len)) { 
        PROTOCCALLSFSUB2(INIT_UPHOLE_CORR,init_uphole_corr,PINT,PINT)
        CCALLSFSUB2(INIT_UPHOLE_CORR,init_uphole_corr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("UP_DCON")) && !strncasecmp(ctool,"UP_DCON",len)) { 
        PROTOCCALLSFSUB2(INIT_UP_DCON,init_up_dcon,PINT,PINT)
        CCALLSFSUB2(INIT_UP_DCON,init_up_dcon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("USR_FILTER")) && !strncasecmp(ctool,"USR_FILTER",len)) { 
        PROTOCCALLSFSUB2(INIT_USR_FILTER,init_usr_filter,PINT,PINT)
        CCALLSFSUB2(INIT_USR_FILTER,init_usr_filter,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VELOCITY_CORR")) && !strncasecmp(ctool,"VELOCITY_CORR",len)) { 
        PROTOCCALLSFSUB2(INIT_VELOCITY_CORR,init_velocity_corr,PINT,PINT)
        CCALLSFSUB2(INIT_VELOCITY_CORR,init_velocity_corr,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("VIBTEST")) && !strncasecmp(ctool,"VIBTEST",len)) { 
        PROTOCCALLSFSUB2(INIT_VIBTEST,init_vibtest,PINT,PINT)
        CCALLSFSUB2(INIT_VIBTEST,init_vibtest,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("VOID")) && !strncasecmp(ctool,"VOID",len)) { 
        PROTOCCALLSFSUB2(INIT_VOID,init_void,PINT,PINT)
        CCALLSFSUB2(INIT_VOID,init_void,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("V_TRANSFER")) && !strncasecmp(ctool,"V_TRANSFER",len)) { 
        PROTOCCALLSFSUB2(INIT_V_TRANSFER,init_v_transfer,PINT,PINT)
        CCALLSFSUB2(INIT_V_TRANSFER,init_v_transfer,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WHITESH")) && !strncasecmp(ctool,"WHITESH",len)) { 
        PROTOCCALLSFSUB2(INIT_WHITESH,init_whitesh,PINT,PINT)
        CCALLSFSUB2(INIT_WHITESH,init_whitesh,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WP_APPLY")) && !strncasecmp(ctool,"WP_APPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_WP_APPLY,init_wp_apply,PINT,PINT)
        CCALLSFSUB2(INIT_WP_APPLY,init_wp_apply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WP_FILT")) && !strncasecmp(ctool,"WP_FILT",len)) { 
        PROTOCCALLSFSUB2(INIT_WP_FILT,init_wp_filt,PINT,PINT)
        CCALLSFSUB2(INIT_WP_FILT,init_wp_filt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("W_HDRSTACK")) && !strncasecmp(ctool,"W_HDRSTACK",len)) { 
        PROTOCCALLSFSUB2(INIT_W_HDRSTACK,init_w_hdrstack,PINT,PINT)
        CCALLSFSUB2(INIT_W_HDRSTACK,init_w_hdrstack,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("W_IHDRHIST")) && !strncasecmp(ctool,"W_IHDRHIST",len)) { 
        PROTOCCALLSFSUB2(INIT_W_IHDRHIST,init_w_ihdrhist,PINT,PINT)
        CCALLSFSUB2(INIT_W_IHDRHIST,init_w_ihdrhist,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("W_PROCESS")) && !strncasecmp(ctool,"W_PROCESS",len)) { 
        PROTOCCALLSFSUB2(INIT_W_PROCESS,init_w_process,PINT,PINT)
        CCALLSFSUB2(INIT_W_PROCESS,init_w_process,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("XTAR")) && !strncasecmp(ctool,"XTAR",len)) { 
        PROTOCCALLSFSUB2(INIT_XTAR,init_xtar,PINT,PINT)
        CCALLSFSUB2(INIT_XTAR,init_xtar,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PROWESS_STUB")) && !strncasecmp(ctool,"PROWESS_STUB",len)) { 
        PROTOCCALLSFSUB2(INIT_PROWESS_STUB,init_prowess_stub,PINT,PINT)
        CCALLSFSUB2(INIT_PROWESS_STUB,init_prowess_stub,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ACOUSTIC_FD")) && !strncasecmp(ctool,"ACOUSTIC_FD",len)) { 
        PROTOCCALLSFSUB2(INIT_ACOUSTIC_FD,init_acoustic_fd,PINT,PINT)
        CCALLSFSUB2(INIT_ACOUSTIC_FD,init_acoustic_fd,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("ACOUSTIC_IMP")) && !strncasecmp(ctool,"ACOUSTIC_IMP",len)) { 
        PROTOCCALLSFSUB2(INIT_ACOUSTIC_IMP,init_acoustic_imp,PINT,PINT)
        CCALLSFSUB2(INIT_ACOUSTIC_IMP,init_acoustic_imp,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("AVO")) && !strncasecmp(ctool,"AVO",len)) { 
        PROTOCCALLSFSUB2(INIT_AVO,init_avo,PINT,PINT)
        CCALLSFSUB2(INIT_AVO,init_avo,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("AVO_ATTCOMP")) && !strncasecmp(ctool,"AVO_ATTCOMP",len)) { 
        PROTOCCALLSFSUB2(INIT_AVO_ATTCOMP,init_avo_attcomp,PINT,PINT)
        CCALLSFSUB2(INIT_AVO_ATTCOMP,init_avo_attcomp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("BLEND_CLOSE")) && !strncasecmp(ctool,"BLEND_CLOSE",len)) { 
        PROTOCCALLSFSUB2(INIT_BLEND_CLOSE,init_blend_close,PINT,PINT)
        CCALLSFSUB2(INIT_BLEND_CLOSE,init_blend_close,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("CHECK_SHOT")) && !strncasecmp(ctool,"CHECK_SHOT",len)) { 
        PROTOCCALLSFSUB2(INIT_CHECK_SHOT,init_check_shot,PINT,PINT)
        CCALLSFSUB2(INIT_CHECK_SHOT,init_check_shot,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("CHEV_HEADER")) && !strncasecmp(ctool,"CHEV_HEADER",len)) { 
        PROTOCCALLSFSUB2(INIT_CHEV_HEADER,init_chev_header,PINT,PINT)
        CCALLSFSUB2(INIT_CHEV_HEADER,init_chev_header,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("CROSS_CORR")) && !strncasecmp(ctool,"CROSS_CORR",len)) { 
        PROTOCCALLSFSUB2(INIT_CROSS_CORR,init_cross_corr,PINT,PINT)
        CCALLSFSUB2(INIT_CROSS_CORR,init_cross_corr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("CVS")) && !strncasecmp(ctool,"CVS",len)) { 
        PROTOCCALLSFSUB2(INIT_CVS,init_cvs,PINT,PINT)
        CCALLSFSUB2(INIT_CVS,init_cvs,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("DEPTH_TIME")) && !strncasecmp(ctool,"DEPTH_TIME",len)) { 
        PROTOCCALLSFSUB2(INIT_DEPTH_TIME,init_depth_time,PINT,PINT)
        CCALLSFSUB2(INIT_DEPTH_TIME,init_depth_time,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("DISKREAD")) && !strncasecmp(ctool,"DISKREAD",len)) { 
        PROTOCCALLSFSUB2(INIT_DISKREAD,init_diskread,PINT,PINT)
        CCALLSFSUB2(INIT_DISKREAD,init_diskread,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DISKREAD2")) && !strncasecmp(ctool,"DISKREAD2",len)) { 
        PROTOCCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT)
        CCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DISK_INSERT")) && !strncasecmp(ctool,"DISK_INSERT",len)) { 
        PROTOCCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT)
        CCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DISP_3D")) && !strncasecmp(ctool,"DISP_3D",len)) { 
        PROTOCCALLSFSUB2(INIT_DISP_3D,init_disp_3d,PINT,PINT)
        CCALLSFSUB2(INIT_DISP_3D,init_disp_3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOCOFF")) && !strncasecmp(ctool,"DMOCOFF",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOCOFF,init_dmocoff,PINT,PINT)
        CCALLSFSUB2(INIT_DMOCOFF,init_dmocoff,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOJ")) && !strncasecmp(ctool,"DMOJ",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOJ,init_dmoj,PINT,PINT)
        CCALLSFSUB2(INIT_DMOJ,init_dmoj,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DMOTX")) && !strncasecmp(ctool,"DMOTX",len)) { 
        PROTOCCALLSFSUB2(INIT_DMOTX,init_dmotx,PINT,PINT)
        CCALLSFSUB2(INIT_DMOTX,init_dmotx,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("DSMB")) && !strncasecmp(ctool,"DSMB",len)) { 
        PROTOCCALLSFSUB2(INIT_DSMB,init_dsmb,PINT,PINT)
        CCALLSFSUB2(INIT_DSMB,init_dsmb,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EIGEN_STACK")) && !strncasecmp(ctool,"EIGEN_STACK",len)) { 
        PROTOCCALLSFSUB2(INIT_EIGEN_STACK,init_eigen_stack,PINT,PINT)
        CCALLSFSUB2(INIT_EIGEN_STACK,init_eigen_stack,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_DB")) && !strncasecmp(ctool,"EMCA_DB",len)) { 
        PROTOCCALLSFSUB2(INIT_EMCA_DB,init_emca_db,PINT,PINT)
        CCALLSFSUB2(INIT_EMCA_DB,init_emca_db,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("EMCA_GS")) && !strncasecmp(ctool,"EMCA_GS",len)) { 
        PROTOCCALLSFSUB2(INIT_EMCA_GS,init_emca_gs,PINT,PINT)
        CCALLSFSUB2(INIT_EMCA_GS,init_emca_gs,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_COMBINE")) && !strncasecmp(ctool,"ENS_COMBINE",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_COMBINE,init_ens_combine,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_COMBINE,init_ens_combine,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_DEFINE")) && !strncasecmp(ctool,"ENS_DEFINE",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_DEFINE,init_ens_define,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_DEFINE,init_ens_define,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_SPLIT")) && !strncasecmp(ctool,"ENS_SPLIT",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_SPLIT,init_ens_split,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_SPLIT,init_ens_split,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ENS_STATISTICS")) && !strncasecmp(ctool,"ENS_STATISTICS",len)) { 
        PROTOCCALLSFSUB2(INIT_ENS_STATISTICS,init_ens_statistics,PINT,PINT)
        CCALLSFSUB2(INIT_ENS_STATISTICS,init_ens_statistics,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_INSERT")) && !strncasecmp(ctool,"ESI_INSERT",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_READ,init_esi_read,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_READ,init_esi_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_READ")) && !strncasecmp(ctool,"ESI_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_READ,init_esi_read,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_READ,init_esi_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ESI_TEST")) && !strncasecmp(ctool,"ESI_TEST",len)) { 
        PROTOCCALLSFSUB2(INIT_ESI_TEST,init_esi_test,PINT,PINT)
        CCALLSFSUB2(INIT_ESI_TEST,init_esi_test,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FDMIG")) && !strncasecmp(ctool,"FDMIG",len)) { 
        PROTOCCALLSFSUB2(INIT_FDMIG,init_fdmig,PINT,PINT)
        CCALLSFSUB2(INIT_FDMIG,init_fdmig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FD_DEPTH_MIG")) && !strncasecmp(ctool,"FD_DEPTH_MIG",len)) { 
        PROTOCCALLSFSUB2(INIT_FD_DEPTH_MIG,init_fd_depth_mig,PINT,PINT)
        CCALLSFSUB2(INIT_FD_DEPTH_MIG,init_fd_depth_mig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FFT_INTERP")) && !strncasecmp(ctool,"FFT_INTERP",len)) { 
        PROTOCCALLSFSUB2(INIT_FFT_INTERP,init_fft_interp,PINT,PINT)
        CCALLSFSUB2(INIT_FFT_INTERP,init_fft_interp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FKITER")) && !strncasecmp(ctool,"FKITER",len)) { 
        PROTOCCALLSFSUB2(INIT_FKITER,init_fkiter,PINT,PINT)
        CCALLSFSUB2(INIT_FKITER,init_fkiter,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FKMIG3D")) && !strncasecmp(ctool,"FKMIG3D",len)) { 
        PROTOCCALLSFSUB2(INIT_FKMIG3D,init_fkmig3d,PINT,PINT)
        CCALLSFSUB2(INIT_FKMIG3D,init_fkmig3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FK_GEN")) && !strncasecmp(ctool,"FK_GEN",len)) { 
        PROTOCCALLSFSUB2(INIT_FK_GEN,init_fk_gen,PINT,PINT)
        CCALLSFSUB2(INIT_FK_GEN,init_fk_gen,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FLOPPY_READ")) && !strncasecmp(ctool,"FLOPPY_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_FLOPPY_READ,init_floppy_read,PINT,PINT)
        CCALLSFSUB2(INIT_FLOPPY_READ,init_floppy_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FT_GEN")) && !strncasecmp(ctool,"FT_GEN",len)) { 
        PROTOCCALLSFSUB2(INIT_FT_GEN,init_ft_gen,PINT,PINT)
        CCALLSFSUB2(INIT_FT_GEN,init_ft_gen,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FXYDECON")) && !strncasecmp(ctool,"FXYDECON",len)) { 
        PROTOCCALLSFSUB2(INIT_FXYDECON,init_fxydecon,PINT,PINT)
        CCALLSFSUB2(INIT_FXYDECON,init_fxydecon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("FX_INTERP")) && !strncasecmp(ctool,"FX_INTERP",len)) { 
        PROTOCCALLSFSUB2(INIT_FX_INTERP,init_fx_interp,PINT,PINT)
        CCALLSFSUB2(INIT_FX_INTERP,init_fx_interp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("GEOM_LOAD")) && !strncasecmp(ctool,"GEOM_LOAD",len)) { 
        PROTOCCALLSFSUB2(INIT_GEOM_LOAD,init_geom_load,PINT,PINT)
        CCALLSFSUB2(INIT_GEOM_LOAD,init_geom_load,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("IES_READ")) && !strncasecmp(ctool,"IES_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_IES_READ,init_ies_read,PINT,PINT)
        CCALLSFSUB2(INIT_IES_READ,init_ies_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("INLINE_SORT")) && !strncasecmp(ctool,"INLINE_SORT",len)) { 
        PROTOCCALLSFSUB2(INIT_INLINE_SORT,init_inline_sort,PINT,PINT)
        CCALLSFSUB2(INIT_INLINE_SORT,init_inline_sort,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("JTOOL_READ")) && !strncasecmp(ctool,"JTOOL_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_JTOOL_READ,init_jtool_read,PINT,PINT)
        CCALLSFSUB2(INIT_JTOOL_READ,init_jtool_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("KIR_P_TOOL")) && !strncasecmp(ctool,"KIR_P_TOOL",len)) { 
        PROTOCCALLSFSUB2(INIT_KIR_P_TOOL,init_kir_p_tool,PINT,PINT)
        CCALLSFSUB2(INIT_KIR_P_TOOL,init_kir_p_tool,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LDISPLAY")) && !strncasecmp(ctool,"LDISPLAY",len)) { 
        PROTOCCALLSFSUB2(INIT_LDISPLAY,init_ldisplay,PINT,PINT)
        CCALLSFSUB2(INIT_LDISPLAY,init_ldisplay,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_BLOCK")) && !strncasecmp(ctool,"LOG_BLOCK",len)) { 
        PROTOCCALLSFSUB2(INIT_LOG_BLOCK,init_log_block,PINT,PINT)
        CCALLSFSUB2(INIT_LOG_BLOCK,init_log_block,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_MFILTER")) && !strncasecmp(ctool,"LOG_MFILTER",len)) { 
        PROTOCCALLSFSUB2(INIT_LOG_MFILTER,init_log_mfilter,PINT,PINT)
        CCALLSFSUB2(INIT_LOG_MFILTER,init_log_mfilter,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("LOG_READ")) && !strncasecmp(ctool,"LOG_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_LOG_READ,init_log_read,PINT,PINT)
        CCALLSFSUB2(INIT_LOG_READ,init_log_read,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("MARINE_QC")) && !strncasecmp(ctool,"MARINE_QC",len)) { 
        PROTOCCALLSFSUB2(INIT_MARINE_QC,init_marine_qc,PINT,PINT)
        CCALLSFSUB2(INIT_MARINE_QC,init_marine_qc,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MATCH")) && !strncasecmp(ctool,"MATCH",len)) { 
        PROTOCCALLSFSUB2(INIT_MATCH,init_match,PINT,PINT)
        CCALLSFSUB2(INIT_MATCH,init_match,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MATCH3D")) && !strncasecmp(ctool,"MATCH3D",len)) { 
        PROTOCCALLSFSUB2(INIT_MATCH3D,init_match3d,PINT,PINT)
        CCALLSFSUB2(INIT_MATCH3D,init_match3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTAPER")) && !strncasecmp(ctool,"MIGTAPER",len)) { 
        PROTOCCALLSFSUB2(INIT_MIGTAPER,init_migtaper,PINT,PINT)
        CCALLSFSUB2(INIT_MIGTAPER,init_migtaper,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MIGTK")) && !strncasecmp(ctool,"MIGTK",len)) { 
        PROTOCCALLSFSUB2(INIT_MIGTK,init_migtk,PINT,PINT)
        CCALLSFSUB2(INIT_MIGTK,init_migtk,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MTD")) && !strncasecmp(ctool,"MTD",len)) { 
        PROTOCCALLSFSUB2(INIT_MTD,init_mtd,PINT,PINT)
        CCALLSFSUB2(INIT_MTD,init_mtd,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MUTE_TEST")) && !strncasecmp(ctool,"MUTE_TEST",len)) { 
        PROTOCCALLSFSUB2(INIT_MUTE_TEST,init_mute_test,PINT,PINT)
        CCALLSFSUB2(INIT_MUTE_TEST,init_mute_test,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MWMATCH")) && !strncasecmp(ctool,"MWMATCH",len)) { 
        PROTOCCALLSFSUB2(INIT_MWMATCH,init_mwmatch,PINT,PINT)
        CCALLSFSUB2(INIT_MWMATCH,init_mwmatch,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("NNHPAPPLY")) && !strncasecmp(ctool,"NNHPAPPLY",len)) { 
        PROTOCCALLSFSUB2(INIT_NNHPAPPLY,init_nnhpapply,PINT,PINT)
        CCALLSFSUB2(INIT_NNHPAPPLY,init_nnhpapply,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PAD_TRACES")) && !strncasecmp(ctool,"PAD_TRACES",len)) { 
        PROTOCCALLSFSUB2(INIT_PAD_TRACES,init_pad_traces,PINT,PINT)
        CCALLSFSUB2(INIT_PAD_TRACES,init_pad_traces,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PARALLEL_TOOL")) && !strncasecmp(ctool,"PARALLEL_TOOL",len)) { 
        PROTOCCALLSFSUB2(INIT_PARALLEL_TOOL,init_parallel_tool,PINT,PINT)
        CCALLSFSUB2(INIT_PARALLEL_TOOL,init_parallel_tool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PM_HYBRID_TOOL")) && !strncasecmp(ctool,"PM_HYBRID_TOOL",len)) { 
        PROTOCCALLSFSUB2(INIT_PM_HYBRID_TOOL,init_pm_hybrid_tool,PINT,PINT)
        CCALLSFSUB2(INIT_PM_HYBRID_TOOL,init_pm_hybrid_tool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("POSTSTACK_3D")) && !strncasecmp(ctool,"POSTSTACK_3D",len)) { 
        PROTOCCALLSFSUB2(INIT_POSTSTACK_3D,init_poststack_3d,PINT,PINT)
        CCALLSFSUB2(INIT_POSTSTACK_3D,init_poststack_3d,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PSEUDO_DENSITY")) && !strncasecmp(ctool,"PSEUDO_DENSITY",len)) { 
        PROTOCCALLSFSUB2(INIT_PSEUDO_DENSITY,init_pseudo_density,PINT,PINT)
        CCALLSFSUB2(INIT_PSEUDO_DENSITY,init_pseudo_density,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("PSEUDO_SONIC")) && !strncasecmp(ctool,"PSEUDO_SONIC",len)) { 
        PROTOCCALLSFSUB2(INIT_PSEUDO_SONIC,init_pseudo_sonic,PINT,PINT)
        CCALLSFSUB2(INIT_PSEUDO_SONIC,init_pseudo_sonic,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("PSI2DN")) && !strncasecmp(ctool,"PSI2DN",len)) { 
        PROTOCCALLSFSUB2(INIT_PSI2DN,init_psi2dn,PINT,PINT)
        CCALLSFSUB2(INIT_PSI2DN,init_psi2dn,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PSI3D")) && !strncasecmp(ctool,"PSI3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PSI3D,init_psi3d,PINT,PINT)
        CCALLSFSUB2(INIT_PSI3D,init_psi3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PSMIG3D")) && !strncasecmp(ctool,"PSMIG3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PSMIG3D,init_psmig3d,PINT,PINT)
        CCALLSFSUB2(INIT_PSMIG3D,init_psmig3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_DMO3D")) && !strncasecmp(ctool,"PT_DMO3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT)
        CCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_DMO3DG")) && !strncasecmp(ctool,"PT_DMO3DG",len)) { 
        PROTOCCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT)
        CCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FKMIG3D")) && !strncasecmp(ctool,"PT_FKMIG3D",len)) { 
        PROTOCCALLSFSUB2(INIT_FKMIG3D,init_fkmig3d,PINT,PINT)
        CCALLSFSUB2(INIT_FKMIG3D,init_fkmig3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FXY3DMIG")) && !strncasecmp(ctool,"PT_FXY3DMIG",len)) { 
        PROTOCCALLSFSUB2(INIT_PT_FXY3DMIG,init_pt_fxy3dmig,PINT,PINT)
        CCALLSFSUB2(INIT_PT_FXY3DMIG,init_pt_fxy3dmig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_FXYDECON")) && !strncasecmp(ctool,"PT_FXYDECON",len)) { 
        PROTOCCALLSFSUB2(INIT_FXYDECON,init_fxydecon,PINT,PINT)
        CCALLSFSUB2(INIT_FXYDECON,init_fxydecon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_MPFXY3DMIG")) && !strncasecmp(ctool,"PT_MPFXY3DMIG",len)) { 
        PROTOCCALLSFSUB2(INIT_PT_MPFXY3DMIG,init_pt_mpfxy3dmig,PINT,PINT)
        CCALLSFSUB2(INIT_PT_MPFXY3DMIG,init_pt_mpfxy3dmig,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_PSMIG3D")) && !strncasecmp(ctool,"PT_PSMIG3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PSMIG3D,init_psmig3d,PINT,PINT)
        CCALLSFSUB2(INIT_PSMIG3D,init_psmig3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_PXBEGEND")) && !strncasecmp(ctool,"PT_PXBEGEND",len)) { 
        PROTOCCALLSFSUB2(INIT_PXBEGEND,init_pxbegend,PINT,PINT)
        CCALLSFSUB2(INIT_PXBEGEND,init_pxbegend,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STACK3D")) && !strncasecmp(ctool,"PT_STACK3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT)
        CCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STKMRG3D")) && !strncasecmp(ctool,"PT_STKMRG3D",len)) { 
        PROTOCCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT)
        CCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PT_STOLT3D")) && !strncasecmp(ctool,"PT_STOLT3D",len)) { 
        PROTOCCALLSFSUB2(INIT_STOLT3D,init_stolt3d,PINT,PINT)
        CCALLSFSUB2(INIT_STOLT3D,init_stolt3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PVMTOOL")) && !strncasecmp(ctool,"PVMTOOL",len)) { 
        PROTOCCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT)
        CCALLSFSUB2(INIT_PVMTOOL,init_pvmtool,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PXBEGEND")) && !strncasecmp(ctool,"PXBEGEND",len)) { 
        PROTOCCALLSFSUB2(INIT_PXBEGEND,init_pxbegend,PINT,PINT)
        CCALLSFSUB2(INIT_PXBEGEND,init_pxbegend,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PXIN")) && !strncasecmp(ctool,"PXIN",len)) { 
        PROTOCCALLSFSUB2(INIT_PXIN,init_pxin,PINT,PINT)
        CCALLSFSUB2(INIT_PXIN,init_pxin,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PXOUT")) && !strncasecmp(ctool,"PXOUT",len)) { 
        PROTOCCALLSFSUB2(INIT_PXOUT,init_pxout,PINT,PINT)
        CCALLSFSUB2(INIT_PXOUT,init_pxout,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RADON_FILTER")) && !strncasecmp(ctool,"RADON_FILTER",len)) { 
        PROTOCCALLSFSUB2(INIT_RADON_FILTER,init_radon_filter,PINT,PINT)
        CCALLSFSUB2(INIT_RADON_FILTER,init_radon_filter,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RADON_TRANS")) && !strncasecmp(ctool,"RADON_TRANS",len)) { 
        PROTOCCALLSFSUB2(INIT_RADON_TRANS,init_radon_trans,PINT,PINT)
        CCALLSFSUB2(INIT_RADON_TRANS,init_radon_trans,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("REFL_LOG")) && !strncasecmp(ctool,"REFL_LOG",len)) { 
        PROTOCCALLSFSUB2(INIT_REFL_LOG,init_refl_log,PINT,PINT)
        CCALLSFSUB2(INIT_REFL_LOG,init_refl_log,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("REPEAT")) && !strncasecmp(ctool,"REPEAT",len)) { 
        PROTOCCALLSFSUB2(INIT_REPEAT,init_repeat,PINT,PINT)
        CCALLSFSUB2(INIT_REPEAT,init_repeat,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RGEOM")) && !strncasecmp(ctool,"RGEOM",len)) { 
        PROTOCCALLSFSUB2(INIT_RGEOM,init_rgeom,PINT,PINT)
        CCALLSFSUB2(INIT_RGEOM,init_rgeom,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RMPAD_TRACES")) && !strncasecmp(ctool,"RMPAD_TRACES",len)) { 
        PROTOCCALLSFSUB2(INIT_RMPAD_TRACES,init_rmpad_traces,PINT,PINT)
        CCALLSFSUB2(INIT_RMPAD_TRACES,init_rmpad_traces,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ROLL_CHECK")) && !strncasecmp(ctool,"ROLL_CHECK",len)) { 
        PROTOCCALLSFSUB2(INIT_ROLL_CHECK,init_roll_check,PINT,PINT)
        CCALLSFSUB2(INIT_ROLL_CHECK,init_roll_check,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("RSTACK")) && !strncasecmp(ctool,"RSTACK",len)) { 
        PROTOCCALLSFSUB2(INIT_RSTACK,init_rstack,PINT,PINT)
        CCALLSFSUB2(INIT_RSTACK,init_rstack,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP2")) && !strncasecmp(ctool,"SCAMP2",len)) { 
        PROTOCCALLSFSUB2(INIT_SCAMP2,init_scamp2,PINT,PINT)
        CCALLSFSUB2(INIT_SCAMP2,init_scamp2,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCAMP3")) && !strncasecmp(ctool,"SCAMP3",len)) { 
        PROTOCCALLSFSUB2(INIT_SCAMP3,init_scamp3,PINT,PINT)
        CCALLSFSUB2(INIT_SCAMP3,init_scamp3,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECON")) && !strncasecmp(ctool,"SCDECON",len)) { 
        PROTOCCALLSFSUB2(INIT_SCDECON,init_scdecon,PINT,PINT)
        CCALLSFSUB2(INIT_SCDECON,init_scdecon,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SCDECON2")) && !strncasecmp(ctool,"SCDECON2",len)) { 
        PROTOCCALLSFSUB2(INIT_SCDECON2,init_scdecon2,PINT,PINT)
        CCALLSFSUB2(INIT_SCDECON2,init_scdecon2,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SC_AMP")) && !strncasecmp(ctool,"SC_AMP",len)) { 
        PROTOCCALLSFSUB2(INIT_SC_AMP,init_sc_amp,PINT,PINT)
        CCALLSFSUB2(INIT_SC_AMP,init_sc_amp,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SC_AMP1")) && !strncasecmp(ctool,"SC_AMP1",len)) { 
        PROTOCCALLSFSUB2(INIT_SC_AMP1,init_sc_amp1,PINT,PINT)
        CCALLSFSUB2(INIT_SC_AMP1,init_sc_amp1,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SEG_READ")) && !strncasecmp(ctool,"SEG_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_SEG_READ,init_seg_read,PINT,PINT)
        CCALLSFSUB2(INIT_SEG_READ,init_seg_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SHOT_CHECK")) && !strncasecmp(ctool,"SHOT_CHECK",len)) { 
        PROTOCCALLSFSUB2(INIT_SHOT_CHECK,init_shot_check,PINT,PINT)
        CCALLSFSUB2(INIT_SHOT_CHECK,init_shot_check,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SOCKET_TOOL")) && !strncasecmp(ctool,"SOCKET_TOOL",len)) { 
        PROTOCCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT)
        CCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SORTMERGE")) && !strncasecmp(ctool,"SORTMERGE",len)) { 
        PROTOCCALLSFSUB2(INIT_SORTMERGE,init_sortmerge,PINT,PINT)
        CCALLSFSUB2(INIT_SORTMERGE,init_sortmerge,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPECT")) && !strncasecmp(ctool,"SPECT",len)) { 
        PROTOCCALLSFSUB2(INIT_SPECT,init_spect,PINT,PINT)
        CCALLSFSUB2(INIT_SPECT,init_spect,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPIK2MED")) && !strncasecmp(ctool,"SPIK2MED",len)) { 
        PROTOCCALLSFSUB2(INIT_SPIK2MED,init_spik2med,PINT,PINT)
        CCALLSFSUB2(INIT_SPIK2MED,init_spik2med,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SSAA")) && !strncasecmp(ctool,"SSAA",len)) { 
        PROTOCCALLSFSUB2(INIT_SSAA,init_ssaa,PINT,PINT)
        CCALLSFSUB2(INIT_SSAA,init_ssaa,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("STACK")) && !strncasecmp(ctool,"STACK",len)) { 
        PROTOCCALLSFSUB2(INIT_STACK,init_stack,PINT,PINT)
        CCALLSFSUB2(INIT_STACK,init_stack,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("STAND_ALONE")) && !strncasecmp(ctool,"STAND_ALONE",len)) { 
        PROTOCCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT)
        CCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("STOLT3D")) && !strncasecmp(ctool,"STOLT3D",len)) { 
        PROTOCCALLSFSUB2(INIT_STOLT3D,init_stolt3d,PINT,PINT)
        CCALLSFSUB2(INIT_STOLT3D,init_stolt3d,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("ST_DMOMOD")) && !strncasecmp(ctool,"ST_DMOMOD",len)) { 
        PROTOCCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT)
        CCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SWEEP")) && !strncasecmp(ctool,"SWEEP",len)) { 
        PROTOCCALLSFSUB2(INIT_SWEEP,init_sweep,PINT,PINT)
        CCALLSFSUB2(INIT_SWEEP,init_sweep,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SWOPT")) && !strncasecmp(ctool,"SWOPT",len)) { 
        PROTOCCALLSFSUB2(INIT_SWOPT,init_swopt,PINT,PINT)
        CCALLSFSUB2(INIT_SWOPT,init_swopt,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("SYNTH")) && !strncasecmp(ctool,"SYNTH",len)) { 
        PROTOCCALLSFSUB2(INIT_SYNTH,init_synth,PINT,PINT)
        CCALLSFSUB2(INIT_SYNTH,init_synth,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("SYN_CDP")) && !strncasecmp(ctool,"SYN_CDP",len)) { 
        PROTOCCALLSFSUB2(INIT_SYN_CDP,init_syn_cdp,PINT,PINT)
        CCALLSFSUB2(INIT_SYN_CDP,init_syn_cdp,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("TAPEREAD")) && !strncasecmp(ctool,"TAPEREAD",len)) { 
        PROTOCCALLSFSUB2(INIT_TAPEREAD,init_taperead,PINT,PINT)
        CCALLSFSUB2(INIT_TAPEREAD,init_taperead,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAPEREAD2")) && !strncasecmp(ctool,"TAPEREAD2",len)) { 
        PROTOCCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT)
        CCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAPE_INSERT")) && !strncasecmp(ctool,"TAPE_INSERT",len)) { 
        PROTOCCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT)
        CCALLSFSUB2(INIT_PROMAX_READ,init_promax_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAUP")) && !strncasecmp(ctool,"TAUP",len)) { 
        PROTOCCALLSFSUB2(INIT_TAUP,init_taup,PINT,PINT)
        CCALLSFSUB2(INIT_TAUP,init_taup,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TAUPIN")) && !strncasecmp(ctool,"TAUPIN",len)) { 
        PROTOCCALLSFSUB2(INIT_TAUPIN,init_taupin,PINT,PINT)
        CCALLSFSUB2(INIT_TAUPIN,init_taupin,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("TIME_LOG")) && !strncasecmp(ctool,"TIME_LOG",len)) { 
        PROTOCCALLSFSUB2(INIT_TIME_LOG,init_time_log,PINT,PINT)
        CCALLSFSUB2(INIT_TIME_LOG,init_time_log,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("TIME_SLICE")) && !strncasecmp(ctool,"TIME_SLICE",len)) { 
        PROTOCCALLSFSUB2(INIT_TIME_SLICE,init_time_slice,PINT,PINT)
        CCALLSFSUB2(INIT_TIME_SLICE,init_time_slice,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TRACEMATH")) && !strncasecmp(ctool,"TRACEMATH",len)) { 
        PROTOCCALLSFSUB2(INIT_TRACEMATH,init_tracemath,PINT,PINT)
        CCALLSFSUB2(INIT_TRACEMATH,init_tracemath,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TR_DISPLAY")) && !strncasecmp(ctool,"TR_DISPLAY",len)) { 
        PROTOCCALLSFSUB2(INIT_TR_DISPLAY,init_tr_display,PINT,PINT)
        CCALLSFSUB2(INIT_TR_DISPLAY,init_tr_display,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TR_SPLICE")) && !strncasecmp(ctool,"TR_SPLICE",len)) { 
        PROTOCCALLSFSUB2(INIT_TR_SPLICE,init_tr_splice,PINT,PINT)
        CCALLSFSUB2(INIT_TR_SPLICE,init_tr_splice,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TR_UNSPLICE")) && !strncasecmp(ctool,"TR_UNSPLICE",len)) { 
        PROTOCCALLSFSUB2(INIT_TR_UNSPLICE,init_tr_unsplice,PINT,PINT)
        CCALLSFSUB2(INIT_TR_UNSPLICE,init_tr_unsplice,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("TVG")) && !strncasecmp(ctool,"TVG",len)) { 
        PROTOCCALLSFSUB2(INIT_TVG,init_tvg,PINT,PINT)
        CCALLSFSUB2(INIT_TVG,init_tvg,PINT,PINT,len_sav[0],itype[0]);

#if defined (CXXLINK)
    } else if ((((size_t) len+1) == sizeof("T_AND_B")) && !strncasecmp(ctool,"T_AND_B",len)) { 
        PROTOCCALLSFSUB2(INIT_T_AND_B,init_t_and_b,PINT,PINT)
        CCALLSFSUB2(INIT_T_AND_B,init_t_and_b,PINT,PINT,len_sav[0],itype[0]);
#endif /* defined (CXXLINK) */
    } else if ((((size_t) len+1) == sizeof("T_TRANSFER")) && !strncasecmp(ctool,"T_TRANSFER",len)) { 
        PROTOCCALLSFSUB2(INIT_T_TRANSFER,init_t_transfer,PINT,PINT)
        CCALLSFSUB2(INIT_T_TRANSFER,init_t_transfer,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("USP_PROGRAM")) && !strncasecmp(ctool,"USP_PROGRAM",len)) { 
        PROTOCCALLSFSUB2(INIT_USP_PROGRAM,init_usp_program,PINT,PINT)
        CCALLSFSUB2(INIT_USP_PROGRAM,init_usp_program,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WAV_EXT1")) && !strncasecmp(ctool,"WAV_EXT1",len)) { 
        PROTOCCALLSFSUB2(INIT_WAV_EXT1,init_wav_ext1,PINT,PINT)
        CCALLSFSUB2(INIT_WAV_EXT1,init_wav_ext1,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WIN_ALIN")) && !strncasecmp(ctool,"WIN_ALIN",len)) { 
        PROTOCCALLSFSUB2(INIT_WIN_ALIN,init_win_alin,PINT,PINT)
        CCALLSFSUB2(INIT_WIN_ALIN,init_win_alin,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WP_AVE")) && !strncasecmp(ctool,"WP_AVE",len)) { 
        PROTOCCALLSFSUB2(INIT_WP_AVE,init_wp_ave,PINT,PINT)
        CCALLSFSUB2(INIT_WP_AVE,init_wp_ave,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("WP_WAV")) && !strncasecmp(ctool,"WP_WAV",len)) { 
        PROTOCCALLSFSUB2(INIT_WP_WAV,init_wp_wav,PINT,PINT)
        CCALLSFSUB2(INIT_WP_WAV,init_wp_wav,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("W_ITRSELT")) && !strncasecmp(ctool,"W_ITRSELT",len)) { 
        PROTOCCALLSFSUB2(INIT_W_ITRSELT,init_w_itrselt,PINT,PINT)
        CCALLSFSUB2(INIT_W_ITRSELT,init_w_itrselt,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("MASWEMR")) && !strncasecmp(ctool,"MASWEMR",len)) { 
        PROTOCCALLSFSUB2(INIT_MASWEMR,init_maswemr,PINT,PINT)
        CCALLSFSUB2(INIT_MASWEMR,init_maswemr,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PROWESS_STUB")) && !strncasecmp(ctool,"PROWESS_STUB",len)) { 
        PROTOCCALLSFSUB2(INIT_PROWESS_STUB,init_prowess_stub,PINT,PINT)
        CCALLSFSUB2(INIT_PROWESS_STUB,init_prowess_stub,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SPLITZERO")) && !strncasecmp(ctool,"SPLITZERO",len)) { 
        PROTOCCALLSFSUB2(INIT_SPLITZERO,init_splitzero,PINT,PINT)
        CCALLSFSUB2(INIT_SPLITZERO,init_splitzero,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("SSP_READ")) && !strncasecmp(ctool,"SSP_READ",len)) { 
        PROTOCCALLSFSUB2(INIT_SSP_READ,init_ssp_read,PINT,PINT)
        CCALLSFSUB2(INIT_SSP_READ,init_ssp_read,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("BLEND")) && !strncasecmp(ctool,"BLEND",len)) {
	ex_err_fatal_( "Please re-parameterize the BLEND menu!", strlen( "Please re-parameterize the BLEND menu!"));
    } else if ((((size_t) len+1) == sizeof("SYNTHETIC")) && !strncasecmp(ctool,"SYNTHETIC",len)) {
	ex_err_fatal_( "SYNTHETIC is no longer supported!", strlen( "SYNTHETIC is no longer supported!"));
/* RCS: ProMAX $Id: tcalli.ftr 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */

    } else if (!strncasecmp(ctool,"ST_",3)) {
        PROTOCCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT)
        CCALLSFSUB2(INIT_STAND_ALONE_MODULE,init_stand_alone_module,PINT,PINT,len_sav[0],itype[0]);
    } else if ((((size_t) len+1) == sizeof("PANEL_OVERRIDE")) && !strncasecmp(ctool,"PANEL_OVERRIDE",len)) {
	/* ......... this is not really a processing tool */
        PROTOCCALLSFSUB2(PANEL_OVERRIDE,panel_override,PINT,PINT)
        CCALLSFSUB2(PANEL_OVERRIDE,panel_override,PINT,PINT,len_sav[0],itype[0]);
    } else {
	ex_err_fatal_("tool not recognized in init_toolcall", 36);
    }
}

/* RCS: ProMAX $Id: rollgate.stub 40897 2007-02-17 06:31:15Z crs $ $Revision: 40897 $ $Date: 2007-02-16 23:31:15 -0700 (Fri, 16 Feb 2007) $ */
#include <cpromaxf.h>
void rollgate_tcaller( char *ctool, float *traces, int *ithdrs, float *trace, int *ithdr);
FCALLSCSUB5(rollgate_tcaller,ROLLGATE_TCALLER,rollgate_tcaller,STRING,PFLOAT,PINT,PFLOAT,PINT)
/*ARGSUSED*/
void rollgate_tcaller( char *ctool, float *traces, int *ithdrs, float *trace, int *ithdr)
{

/* this was changed to a panel tool */
        ex_err_fatal_("Tool not recognized in ROLLGATE_TCALLER", 40);
}

