#!/bin/bash
if [[ $# -lt 3 ]]; then
   echo "Syntax: $0 executable extract_hdr lib_1 [ lib2 ... ]"
   exit 1
fi
declare temptar="tar$$"
declare thisdir="`pwd`"
declare exeout="$1"
shift
declare extracthdr="$1"
shift
declare exedir="`dirname ${exeout}`"
declare tarargs="-cf ${exedir}/${temptar}"
for ilib
  do
  tarargs="${tarargs} -C ${thisdir} -C `dirname ${ilib}`"
  tarargs="${tarargs} `basename ${ilib}`"
done
tar ${tarargs}
uuencode "${exedir}/${temptar}" execlibs.tar > "${exedir}/uu${temptar}"
rm -f "${exedir}/${temptar}" "${exeout}"
cat "${extracthdr}" "${exedir}/uu${temptar}" > "${exeout}"
rm -f "${exedir}/uu${temptar}"
chmod 755 "${exeout}"
exit 0